﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Common.Library
{
  /// <summary>
  /// Call this converter to change a DateTime to a DateTime.ToShortDate()
  /// </summary>
  public class DateToShortDateConverter : IValueConverter
  {
    /// <summary>
    /// Convert a DateTime to a Short Date String Format
    /// </summary>
    /// <param name="value">A DateTime value</param>
    /// <param name="targetType">The type of object</param>
    /// <param name="parameter">Any parameters passed via XAML</param>
    /// <param name="culture">The current culture</param>
    /// <returns>A Short Date</returns>
    public object Convert(object value, Type targetType,
                          object parameter, CultureInfo culture)
    {
      return ((DateTime)value).ToShortDateString();
    }

    /// <summary>
    /// NOT IMPLEMENTED
    /// </summary>
    /// <param name="value">A boolean value</param>
    /// <param name="targetType">The type of object</param>
    /// <param name="parameter">Any parameters passed via XAML</param>
    /// <param name="culture">The current culture</param>
    /// <returns>NOT IMPLEMENTED</returns>
    public object ConvertBack(object value, Type targetType,
                              object parameter, CultureInfo culture)
    {
      throw new NotImplementedException("DateToShortDateConverter ConvertBack Method Not Implemented");
    }
  }
}