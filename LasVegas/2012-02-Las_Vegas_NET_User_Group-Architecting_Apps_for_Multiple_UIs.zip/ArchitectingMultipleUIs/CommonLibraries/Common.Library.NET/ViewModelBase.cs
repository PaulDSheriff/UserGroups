﻿namespace Common.Library
{
  /// <summary>
  /// Class for all View Models to inherit from
	/// Provides common properties for UI such as "IsMessageVisible", "MessageToDisplay", "IsValidationAreaVisible", etc.
  /// This class inherits from CommonBase which implements the INotifyPropertyChanged event
  /// </summary>
  public abstract class ViewModelBase : CommonBase
  {
    #region Constructors
    public ViewModelBase()
    {
      Init();
    }

    public ViewModelBase(bool useAsync)
    {
      UseAsync = useAsync;

      Init();
    }
    #endregion

    #region Private Variables
    private bool _IsMessageVisible = true;
		private string _MessageToDisplay = "Please Wait While Loading...";
		private bool _IsNoRecordsVisible = false;
    private bool _IsValidationAreaVisible;
    private bool _RefreshGrid = false;
    private int _RowsFound = 0;
    private bool _UseAsync = true;
    #endregion

    #region Public Properties
    public bool IsMessageVisible
    {
      get { return _IsMessageVisible; }
      set
      {
        _IsMessageVisible = value;
        RaisePropertyChanged("IsMessageVisible");
      }
    }

		public string MessageToDisplay
		{
			get { return _MessageToDisplay; }
			set
			{
				_MessageToDisplay = value;
				RaisePropertyChanged("MessageToDisplay");
			}
		}

		public bool IsNoRecordsVisible
    {
      get { return _IsNoRecordsVisible; }
      set
      {
        _IsNoRecordsVisible = value;
        RaisePropertyChanged("IsNoRecordsVisible");
      }
    }

    public bool IsValidationAreaVisible
    {
      get { return _IsValidationAreaVisible; }
      set
      {
        _IsValidationAreaVisible = value;
        RaisePropertyChanged("IsValidationAreaVisible");
      }
    }

    public bool RefreshGrid
    {
      get { return _RefreshGrid; }
      set
      {
        _RefreshGrid = value;
        RaisePropertyChanged("RefreshGrid");
      }
    }

    public int RowsFound
    {
      get { return _RowsFound; }
      set
      {
        _RowsFound = value;
        RaisePropertyChanged("RowsFound");
      }
    }

    public bool UseAsync
    {
      get { return _UseAsync; }
      set
      {
        _UseAsync = value;
        RaisePropertyChanged("UseAsync");
      }
    }

    #endregion

    #region Init Method
    public virtual void Init()
    {
    }
    #endregion
  }
}
