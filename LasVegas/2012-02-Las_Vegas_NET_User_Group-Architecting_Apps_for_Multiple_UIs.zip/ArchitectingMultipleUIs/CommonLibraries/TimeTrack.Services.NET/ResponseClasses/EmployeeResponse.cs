using System.Runtime.Serialization;

using Common.Library;
using TimeTrack.DataClasses;
using TimeTrack.EntityClasses;

namespace TimeTrack.Services
{
  /// <summary>
  /// Class for sending data back to the client about the result of calling the WCF service
  /// </summary>
  [DataContract]
  public class EmployeeResponse : ResponseBase
  {
    [DataMember]
    public Employee DetailData { get; set; }

    [DataMember]
    public Employees DataCollection { get; set; }
  }
}

