﻿using System;
using System.Data;
using Common.Library;
using TimeTrack.EntityClasses;

namespace TimeTrack.DataClasses
{
  /// <summary>
  /// Class to read/write customer data
  /// </summary>
  public partial class CustomerData : DataClassBase
  {
    #region Public Properties
    public Customer Entity { get; set; }
    #endregion

    #region GetCustomer Method
    public Customer GetCustomer(Customer entity)
    {
      Customer ret = new Customer();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT CustomerId, CustomerName, URL FROM dbo.Customer WHERE CustomerId = @CustomerId";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Clear();
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@CustomerId", entity.CustomerId));

      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        if (dt.Rows.Count > 0)
          ret = DataRowToEntity(dt.Rows[0]);
      }

      return ret;
    }
    #endregion

    #region BuildCollection Method
    public Customers BuildCollection()
    {
      Customers ret = new Customers();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT CustomerId, CustomerName, URL FROM dbo.Customer ORDER BY CustomerName";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        foreach (DataRow dr in dt.Rows)
        {
          ret.Add(DataRowToEntity(dr));
        }
      }
   
      return ret;
    }
    #endregion

    #region DataRowToEntity Method
    public Customer DataRowToEntity(DataRow dr)
    {
      Customer ret = new Customer();

      ret.CustomerId = Convert.ToInt32(dr["CustomerId"]);
      ret.CustomerName = dr["CustomerName"].ToString();
      ret.URL = dr["URL"].ToString();

      return ret;
    }
    #endregion
  }
}
