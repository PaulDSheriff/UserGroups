﻿using System.Collections.ObjectModel;
using Common.Library;

using TimeTrack.EntityClasses;

#if WINDOWS_PHONE
using TimeTrack.ViewModels.WinPhone.TimeSheetServiceReference;
#endif
#if SILVERLIGHT && !WINDOWS_PHONE
using TimeTrack.ViewModels.Silverlight.TimeSheetServiceReference;
#endif
#if !WINDOWS_PHONE && !SILVERLIGHT
using TimeTrack.ViewModels.TimeSheetServiceReference;
#endif

namespace TimeTrack.ViewModels
{
  /// <summary>
  /// ViewModel class for display time sheets
  /// </summary>
  public class TimeSheetsDisplayViewModel : ViewModelBase
  {
    #region Constructors
    /// <summary>
    /// The Constructor automatically calls the Init() method
    /// </summary>
    public TimeSheetsDisplayViewModel() : base()
    {
    }

    public TimeSheetsDisplayViewModel(bool useAsync)
      : base(useAsync)
    {
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      _SelectedCustomer = new Customer();

      IsMessageVisible = false;
    }
    #endregion

    #region Private Variables
    // WCF Service Client
    TimeSheetServicesClient _Client = null;

    // Customer View Model Object
    CustomerViewModel customerViewModel = null;

    Customer _SelectedCustomer;

    private ObservableCollection<TimeSheet> _DataCollection;
    private ObservableCollection<Customer> _CustomerCollection;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the Selected Customer
    /// </summary>
    public Customer SelectedCustomer
    {
      get { return _SelectedCustomer; }
      set
      {
        _SelectedCustomer = value;
        RaisePropertyChanged("SelectedCustomer");
      }
    }

    /// <summary>
    /// Get/Set the collection of time sheet objects
    /// </summary>
    public ObservableCollection<TimeSheet> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    /// <summary>
    /// Get/Set the collection of Customer objects
    /// </summary>
    public ObservableCollection<Customer> CustomerCollection
    {
      get { return _CustomerCollection; }
      set
      {
        _CustomerCollection = value;
        RaisePropertyChanged("CustomerCollection");
      }
    }
    #endregion

    #region CreateServiceClient Method
    private TimeSheetServicesClient CreateServiceClient()
    {
      _Client = new TimeSheetServicesClient();

      // Set any additional properties here

      return _Client;
    }
    #endregion

    #region CloseServiceClient Method
    private void CloseServiceClient()
    {
#if WINDOWS_PHONE || SILVERLIGHT
      _Client.CloseAsync();
#else
      _Client.Close();
#endif
    }
    #endregion

    #region GetAllTimeSheets Method
    public void GetAllTimeSheets()
    {
      // Reset View Model Variables
      IsNoRecordsVisible = false;
      IsMessageVisible = true;
      MessageToDisplay = "Loading Time Sheets...";

      CreateServiceClient();

      if (UseAsync)
      {
        _Client.GetAllTimeSheetsCompleted += new System.EventHandler<GetAllTimeSheetsCompletedEventArgs>(client_GetAllTimeSheetsCompleted);
        _Client.GetAllTimeSheetsAsync();
      }
#if !WINDOWS_PHONE && !SILVERLIGHT
      else
        GetAllTimeSheetsCompleted(_Client.GetAllTimeSheets());
#endif
    }

    void client_GetAllTimeSheetsCompleted(object sender, GetAllTimeSheetsCompletedEventArgs e)
    {
      TimeSheetResponse response;

      response = (TimeSheetResponse)e.Result;

      GetAllTimeSheetsCompleted(response);
    }

    private void GetAllTimeSheetsCompleted(TimeSheetResponse response)
    {
      if (response.Status == OperationResult.Success)
      {
        DataCollection = response.DataCollection;
        IsMessageVisible = false;
      }
      else if (response.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No time sheets found.";
        IsNoRecordsVisible = true;
      }

      CloseServiceClient();
    }
    #endregion

    #region GetTimeSheetsByCustomer Method
    public void GetTimeSheetsByCustomer(int customerId)
    {
      Customer entity = new Customer();

      entity.CustomerId = customerId;

      GetTimeSheetsByCustomer(entity);
    }

    public void GetTimeSheetsByCustomer(Customer entity)
    {
      // Reset View Model Variables
      IsNoRecordsVisible = false;
      IsMessageVisible = true;
      MessageToDisplay = "Loading Customer Time Sheets...";

      CreateServiceClient();

      if (UseAsync)
      {
        _Client.GetTimeSheetsByCustomerCompleted += new System.EventHandler<GetTimeSheetsByCustomerCompletedEventArgs>(client_GetTimeSheetsByCustomerCompleted);
        _Client.GetTimeSheetsByCustomerAsync(entity);
      }
#if !WINDOWS_PHONE && !SILVERLIGHT
      else
        GetTimeSheetsByCustomerCompleted(_Client.GetTimeSheetsByCustomer(entity));
#endif
    }

    void client_GetTimeSheetsByCustomerCompleted(object sender, GetTimeSheetsByCustomerCompletedEventArgs e)
    {
      TimeSheetResponse response;

      response = (TimeSheetResponse)e.Result;

      GetTimeSheetsByCustomerCompleted(response);
    }

    private void GetTimeSheetsByCustomerCompleted(TimeSheetResponse response)
    {
      if (response.Status == OperationResult.Success)
      {
        DataCollection = response.DataCollection;
        IsMessageVisible = false;
      }
      else if (response.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No customer time sheets found.";
        IsNoRecordsVisible = true;
      }

      CloseServiceClient();
    }
    #endregion

    #region GetAllCustomers Method
    public void GetAllCustomers()
    {
      customerViewModel = new CustomerViewModel();

      // Reset View Model Variables
      IsNoRecordsVisible = false;
      IsMessageVisible = true;
      MessageToDisplay = "Loading Customers...";

      customerViewModel.UseAsync = UseAsync;
      customerViewModel.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(customerViewModel_PropertyChanged);
      customerViewModel.GetCustomers();
    }

    void customerViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "DataCollection")
      {
        CustomerCollection = customerViewModel.DataCollection;

        Customer cust = new Customer();
        cust.CustomerId = -1;            // A -1 means all customers
        cust.CustomerName = "<< All Customers >>";

        // Add blank customer
        CustomerCollection.Insert(0, cust);

        // Reset View Model Variables
        IsNoRecordsVisible = false;
        IsMessageVisible = true;

        MessageToDisplay = "Select a Customer to view Time Sheets";
      }
    }
    #endregion
  }
}
