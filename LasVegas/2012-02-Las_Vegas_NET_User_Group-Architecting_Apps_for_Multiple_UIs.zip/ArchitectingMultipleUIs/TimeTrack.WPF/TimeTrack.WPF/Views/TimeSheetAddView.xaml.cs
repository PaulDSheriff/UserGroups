﻿using System;
using System.Windows;
using System.Windows.Controls;

using TimeTrack.ViewModels;

namespace TimeTrack.WPF
{
  public partial class TimeSheetAddView : UserControl
  {
    public TimeSheetAddViewModel _ViewModel = null;

    #region Constructor
    public TimeSheetAddView()
    {
      InitializeComponent();

      // Ensure TimeSheet View Model object is valid
      (Application.Current as App).InitTimeSheetViewModel();

      // Get Application-Wide TimeSheetAddViewModel instance
      _ViewModel = (Application.Current as App).TimeSheetModel;

      // Set ViewModel object to Page's Data Context
      this.DataContext = _ViewModel;
    }
    #endregion

    #region Reset_Click Event Procedure
    private void Reset_Click(object sender, EventArgs e)
    {
      _ViewModel.Init();
    }
    #endregion

    #region Select Customer Event
    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      CustomerLookupView win = new CustomerLookupView();

      win.Owner = Window.GetWindow(this);
      win.ShowDialog();

      if ((Application.Current as App).TimeSheetModel.SelectedCustomer != null)
        _ViewModel.SelectedCustomer = (Application.Current as App).TimeSheetModel.SelectedCustomer;
    }
    #endregion

    #region Select Project Event
    private void btnProject_Click(object sender, RoutedEventArgs e)
    {
      if (_ViewModel.SelectedCustomer == null)
        MessageBox.Show("Select a Customer First", "Select Customer", MessageBoxButton.OK);
      else
      {
        ProjectLookupView win = new ProjectLookupView();

        win.Owner = Window.GetWindow(this);
        win.ShowDialog();
        
        if ((Application.Current as App).TimeSheetModel.SelectedProject != null)
          _ViewModel.SelectedProject = (Application.Current as App).TimeSheetModel.SelectedProject ;
      }
    }
    #endregion

    #region Select Employee Event
    private void btnEmployee_Click(object sender, RoutedEventArgs e)
    {
      EmployeeLookupView win = new EmployeeLookupView();

      win.Owner = Window.GetWindow(this);
      win.ShowDialog();

      if ((Application.Current as App).TimeSheetModel.SelectedEmployee != null)
        _ViewModel.SelectedEmployee = (Application.Current as App).TimeSheetModel.SelectedEmployee;
    }
    #endregion

    #region Save Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      // Insert new Time Sheet entry
      _ViewModel.Insert();
    }
    #endregion
  }
}
