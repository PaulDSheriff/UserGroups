﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;

using TimeTrack.ViewModels.WinPhone;

namespace TimeTrack.WinPhone
{
  public partial class DescriptionAddView : PhoneApplicationPage
  {
    public DescriptionAddView()
    {
      InitializeComponent();

      this.DataContext = (Application.Current as App).TimeSheetModel;
    }
    
    // Return the Textual Description back to first page
    protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
    {
      if (e.Content is TimeSheetAddView)
        (e.Content as TimeSheetAddView)._ViewModel.Description = txtDesc.Text;
      base.OnNavigatedFrom(e);
    }

    private void ApplicationBarIconButton_Click(object sender, EventArgs e)
    {
      NavigationService.GoBack();
    }
  }
}