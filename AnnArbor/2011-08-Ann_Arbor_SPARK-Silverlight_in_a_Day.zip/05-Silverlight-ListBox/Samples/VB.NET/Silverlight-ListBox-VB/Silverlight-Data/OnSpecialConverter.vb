﻿Imports System.Windows.Data
Imports System.Windows.Media.Imaging

Public Class OnSpecialConverter
  Implements IValueConverter

  Public Function Convert(ByVal value As Object, ByVal targetType As System.Type, ByVal parameter As Object, ByVal culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.Convert
    Dim img As New BitmapImage()

    If System.Convert.ToBoolean(value) Then
      img.UriSource = New Uri("../Images/OnSpecial.jpg", UriKind.Relative)
    Else
      img.UriSource = New Uri("../Images/Blank.jpg", UriKind.Relative)
    End If

    Return img
  End Function

  Public Function ConvertBack(ByVal value As Object, ByVal targetType As System.Type, ByVal parameter As Object, ByVal culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.ConvertBack
    Return Nothing
  End Function
End Class
