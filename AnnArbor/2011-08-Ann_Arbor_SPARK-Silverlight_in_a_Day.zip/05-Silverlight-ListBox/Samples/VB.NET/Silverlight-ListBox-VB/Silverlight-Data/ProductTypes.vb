﻿Imports System.Collections.Generic
Imports System.Collections.ObjectModel

Public Class ProductTypes
  Inherits List(Of ProductType)

  Public Property DataCollection As ObservableCollection(Of ProductType)

  Private Const IMG_PATH As String = "../Images/"

  Public Function BuildCollection() As ObservableCollection(Of ProductType)
    DataCollection = New ObservableCollection(Of ProductType)

    DataCollection.Add(New ProductType("Product"))
    DataCollection.Add(New ProductType("Book"))

    Return DataCollection
  End Function
End Class
