﻿Imports System.Collections.Generic
Imports System.Collections.ObjectModel

Public Class Products
  Inherits List(Of Product)

  Public Sub New()
    BuildCollection()
  End Sub

  Public Property DataCollection As ObservableCollection(Of Product)

  Private Const IMG_PATH As String = "../Images/"

  Public Function BuildCollection() As ObservableCollection(Of Product)
    DataCollection = New ObservableCollection(Of Product)

    DataCollection.Add(New Product(1, "Haystack Code Generator for .NET", "Product", 799, Convert.ToDateTime("6/30/2010"), IMG_PATH & "Haystack.jpg", True))
    DataCollection.Add(New Product(4, "Fundamentals of N-Tier eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("1/1/2007"), IMG_PATH & "FundNTier_100.jpg", False))
    DataCollection.Add(New Product(5, "Fundamentals of ASP.NET Security eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("6/1/2007"), IMG_PATH & "FundSecurity_100.jpg", False))
    DataCollection.Add(New Product(6, "Fundamentals of SQL Server eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("12/1/2007"), IMG_PATH & "FundSQL_100.jpg", False))
    DataCollection.Add(New Product(7, "Fundamentals of VB.NET eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("3/1/2008"), IMG_PATH & "FundVBNet_100.jpg", False))
    DataCollection.Add(New Product(8, "Fundamentals of .NET eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("7/1/2008"), IMG_PATH & "FundDotNet_100.jpg", False))
    DataCollection.Add(New Product(9, "Architecting ASP.NET eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("7/1/2008"), IMG_PATH & "ArchASPNET_100.jpg", False))
    DataCollection.Add(New Product(10, "PDSA .NET Productivity Framework", "Product", Convert.ToDecimal(2500), Convert.ToDateTime("6/1/2006"), IMG_PATH & "framework.jpg", True))

    Return DataCollection
  End Function

  Public Function BuildCollectionByType(ByVal typeName As String) As ObservableCollection(Of Product)
    Dim ret As New ObservableCollection(Of Product)

    If DataCollection Is Nothing Then
      BuildCollection()
    End If

    ret = New ObservableCollection(Of Product)(From prods In DataCollection Where prods.ProductType = typeName)

    Return ret
  End Function
End Class
