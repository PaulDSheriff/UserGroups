﻿Public Class ProductType
  Public Sub New()

  End Sub

  Public Sub New(ByVal typeName As String)
    Me.ProductTypeName = typeName
  End Sub

  Public Property ProductTypeName() As String
End Class