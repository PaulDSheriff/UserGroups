﻿Public Class Product
#Region "Constructors"
  Public Sub New()

  End Sub

  Public Sub New(ByVal id As Integer, ByVal name As String, ByVal type As String, ByVal price As Decimal, ByVal introDate As DateTime, ByVal image As String, ByVal onSpecial As Boolean)
    Me.ProductId = id
    Me.ProductName = name
    Me.ProductType = type
    Me.Price = price
    Me.IntroductionDate = introDate
    Me.Image = image
    Me.IsOnSpecial = onSpecial
  End Sub
#End Region

  Public Property ProductId() As Integer
  Public Property ProductName() As String
  Public Property ProductType() As String
  Public Property Price() As Decimal
  Public Property IntroductionDate() As DateTime
  Public Property Image() As String
  Public Property IsOnSpecial() As Boolean
End Class