﻿Partial Public Class MainPage
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub lstMenus_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)
    Dim item As ListBoxItem = DirectCast(DirectCast(sender, ListBox).SelectedItem, ListBoxItem)

    ' Get Tag from selected item. "Tag" has the name of the control to load in it
    If item.Tag IsNot Nothing Then
      If item.Tag.ToString() <> String.Empty Then
        LoadMenu(item.Tag.ToString())
      End If
    End If
  End Sub

  Private Sub LoadMenu(controlName As String)
    Dim ctl As UserControl = Nothing
    Dim typ As Type

    If controlName.ToLower() = "clear" Then
      contentArea.Children.Clear()
    Else
      ' Create a Type from the controlName parameter
      typ = Type.GetType(controlName)
      ' Create an instance of this control
      ctl = DirectCast(Activator.CreateInstance(typ), UserControl)
      ' Clear Content Area for next control
      contentArea.Children.Clear()
      contentArea.Children.Add(ctl)
    End If
  End Sub
End Class