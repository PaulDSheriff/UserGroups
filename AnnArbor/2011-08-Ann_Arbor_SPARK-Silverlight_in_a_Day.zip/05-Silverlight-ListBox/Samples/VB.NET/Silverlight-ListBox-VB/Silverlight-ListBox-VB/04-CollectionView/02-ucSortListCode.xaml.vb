﻿Imports Silverlight_Data
Imports System.ComponentModel
Imports System.Windows.Data
Imports System.Collections.Generic
Imports System.Windows.Controls
Imports System.Collections.ObjectModel

Partial Public Class ucSortListCode
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub SortTheData(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If lstData IsNot Nothing Then
      Dim dataView As ICollectionView

      dataView = CType(lstData.ItemsSource, ICollectionView)

      dataView.SortDescriptions.Clear()
      dataView.SortDescriptions.Add(New SortDescription(TryCast(sender, RadioButton).Tag.ToString(), ListSortDirection.Ascending))

      lstData.ItemsSource = dataView
    End If
  End Sub
End Class
