﻿Imports Silverlight_Data
Imports System.ComponentModel
Imports System.Windows.Data
Imports System.Collections.Generic
Imports System.Windows.Controls
Imports System.Collections.ObjectModel

Partial Public Class ucFilter
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnSearch.Click
    FilterData()
  End Sub

  Private Sub FilterData()
    If lstData IsNot Nothing Then
      Dim dataView As ICollectionView

      dataView = CType(lstData.ItemsSource, ICollectionView)

      dataView.Filter = Function(prod) _
          DirectCast(prod, Product).ProductName.ToLower(). _
          StartsWith(txtName.Text.ToLower())

      lstData.ItemsSource = dataView
    End If
  End Sub
End Class
