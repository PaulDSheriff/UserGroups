﻿Partial Public Class ucGroupListBox
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
