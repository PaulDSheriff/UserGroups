﻿Partial Public Class ucMainMenu
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub UserControl_Loaded(sender As System.Object, e As System.Windows.RoutedEventArgs)
    Me.DataContext = Me
  End Sub

#Region "Text Dependency Property"
  Public Property Text() As String
    Get
      Return DirectCast(GetValue(TextProperty), String)
    End Get
    Set(value As String)
      SetValue(TextProperty, value)
    End Set
  End Property

  ' Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
  Public Shared ReadOnly TextProperty As DependencyProperty = DependencyProperty.Register("Text", GetType(String), GetType(ucMainMenu), Nothing)
#End Region

End Class
