﻿Imports Silverlight_Data

Partial Public Class ucListBox2Template
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub btnMore_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnMore.Click
    Dim dt As DataTemplate

    dt = CType(Me.Resources("tmplMore"), DataTemplate)

    lstData.ItemTemplate = dt
  End Sub

  Private Sub btnLess_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles btnLess.Click
    Dim dt As DataTemplate

    dt = CType(Me.Resources("tmplLess"), DataTemplate)

    lstData.ItemTemplate = dt
  End Sub
End Class
