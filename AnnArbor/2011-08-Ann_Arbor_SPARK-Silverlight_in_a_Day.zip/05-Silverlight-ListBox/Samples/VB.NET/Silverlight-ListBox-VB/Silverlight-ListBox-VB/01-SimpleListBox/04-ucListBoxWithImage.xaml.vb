﻿Imports Silverlight_Data

Partial Public Class ucListBoxWithImage
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub
End Class
