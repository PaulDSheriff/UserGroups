﻿Partial Public Class ucHorizontal
    Inherits UserControl

    Public Sub New 
        InitializeComponent()
    End Sub

End Class
