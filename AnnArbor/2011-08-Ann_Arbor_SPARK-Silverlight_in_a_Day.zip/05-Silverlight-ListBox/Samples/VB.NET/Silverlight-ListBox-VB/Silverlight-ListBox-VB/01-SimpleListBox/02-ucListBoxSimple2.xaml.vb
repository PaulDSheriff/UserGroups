﻿Imports Silverlight_Data

Partial Public Class ucListBoxSimple2
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub
End Class
