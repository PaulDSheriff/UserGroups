﻿Imports Silverlight_Data

Partial Public Class ucListBoxSimple
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub UserControl_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
    Dim coll As New Products()

    lstData.DataContext = coll.BuildCollection()
  End Sub
End Class
