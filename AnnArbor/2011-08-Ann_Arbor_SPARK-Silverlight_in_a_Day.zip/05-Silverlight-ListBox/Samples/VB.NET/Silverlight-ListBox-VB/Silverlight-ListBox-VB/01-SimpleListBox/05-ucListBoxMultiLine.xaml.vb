﻿Imports Silverlight_Data

Partial Public Class ucListBoxMultiLine
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub
End Class
