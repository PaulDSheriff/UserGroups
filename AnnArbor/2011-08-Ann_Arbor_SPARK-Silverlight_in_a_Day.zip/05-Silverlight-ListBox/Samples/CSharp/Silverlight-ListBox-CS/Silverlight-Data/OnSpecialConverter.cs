﻿using System;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace Silverlight_Data
{
  public class OnSpecialConverter : IValueConverter
  {
    public object Convert(object value, Type targetType,
  object parameter, System.Globalization.CultureInfo culture)
    {
      BitmapImage img = new BitmapImage();
      string image;

      if (System.Convert.ToBoolean(value))
        image = "../Images/OnSpecial.jpg";
      else
        image = "../Images/Blank.jpg";

      img.UriSource = new Uri(image, UriKind.Relative);
      return img;
    }

    public object ConvertBack(object value, Type targetType, 
      object parameter, System.Globalization.CultureInfo culture)
    {
      return null;
    }
  }
}