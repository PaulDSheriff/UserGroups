﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Silverlight_Data
{
  public class Products : List<Product>
  {
    public Products()
    {
      BuildCollection();
    }

    public ObservableCollection<Product> DataCollection { get; set; }
    
    private const string IMG_PATH = "../Images/";

    public ObservableCollection<Product> BuildCollection()
    {
      DataCollection = new ObservableCollection<Product>();

      DataCollection.Add(new Product(1, "Haystack Code Generator for .NET", "Product", 799, Convert.ToDateTime("6/30/2010"), IMG_PATH + "Haystack.jpg", true));
      DataCollection.Add(new Product(4, "Fundamentals of N-Tier eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("1/1/2007"), IMG_PATH + "FundNTier_100.jpg", false));
      DataCollection.Add(new Product(5, "Fundamentals of ASP.NET Security eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("6/1/2007"), IMG_PATH + "FundSecurity_100.jpg", false));
      DataCollection.Add(new Product(6, "Fundamentals of SQL Server eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("12/1/2007"), IMG_PATH + "FundSQL_100.jpg", false));
      DataCollection.Add(new Product(7, "Fundamentals of VB.NET eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("3/1/2008"), IMG_PATH + "FundVBNet_100.jpg", false));
      DataCollection.Add(new Product(8, "Fundamentals of .NET eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("7/1/2008"), "", false));
      DataCollection.Add(new Product(9, "Architecting ASP.NET eBook", "Book", Convert.ToDecimal(19.95), Convert.ToDateTime("7/1/2008"), IMG_PATH + "ArchASPNET_100.jpg", false));
      DataCollection.Add(new Product(10, "PDSA .NET Productivity Framework", "Product", Convert.ToDecimal(2500), Convert.ToDateTime("6/1/2006"), IMG_PATH + "framework.jpg", true));
      DataCollection.Add(new Product(11, "PDSA .NET Performance Audit", "Service", Convert.ToDecimal(2500), Convert.ToDateTime("5/15/2009"), IMG_PATH + "PDSALogo.jpg", true));
      DataCollection.Add(new Product(12, "PDSA .NET Security Audit", "Service", Convert.ToDecimal(2500), Convert.ToDateTime("5/15/2009"), IMG_PATH + "PDSALogo.jpg", true));
      DataCollection.Add(new Product(13, "PDSA .NET SQL Server Audit", "Service", Convert.ToDecimal(2500), Convert.ToDateTime("5/15/2009"), IMG_PATH + "PDSALogo.jpg", true));
      DataCollection.Add(new Product(14, "Silverlight XAML for the Complete Novice - Part 1", "Video", Convert.ToDecimal(20), Convert.ToDateTime("8/12/2010"), IMG_PATH + "ComputerTraining.jpg", true));
      DataCollection.Add(new Product(15, "Silverlight XAML for the Complete Novice - Part 2", "Video", Convert.ToDecimal(20), Convert.ToDateTime("9/1/2010"), IMG_PATH + "ComputerTraining.jpg", true));
      DataCollection.Add(new Product(16, "Silverlight MVVM Made Easy", "Video", Convert.ToDecimal(20), Convert.ToDateTime("10/1/2010"), IMG_PATH + "ComputerTraining.jpg", true));
      DataCollection.Add(new Product(17, "Data Binding from A to Z in Silverlight", "Video", Convert.ToDecimal(20), Convert.ToDateTime("10/15/2010"), IMG_PATH + "ComputerTraining.jpg", true));
      DataCollection.Add(new Product(18, "Getting the Most out of the Silverlight List Box", "Video", Convert.ToDecimal(20), Convert.ToDateTime("11/15/2010"), IMG_PATH + "ComputerTraining.jpg", true));

      return DataCollection;
    }

    public ObservableCollection<Product> BuildCollectionByType(string typeName)
    {
      ObservableCollection<Product> ret = new ObservableCollection<Product>();

      if (DataCollection == null)
      {
        BuildCollection();
      }

      ret = new ObservableCollection<Product>(
        from prods in DataCollection 
        where prods.ProductType == typeName 
        select prods);

      return ret;
    }
  }
}