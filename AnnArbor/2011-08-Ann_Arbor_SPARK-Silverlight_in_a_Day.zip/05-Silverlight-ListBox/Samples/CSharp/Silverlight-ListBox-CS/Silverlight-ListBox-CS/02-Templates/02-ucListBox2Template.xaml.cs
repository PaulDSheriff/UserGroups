﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Silverlight_ListBox_CS
{
  public partial class ucListBox2Template : UserControl
  {
    public ucListBox2Template()
    {
      InitializeComponent();
    }

    private void btnMore_Click(object sender, RoutedEventArgs e)
    {
      DataTemplate dt;

      dt = (DataTemplate)this.Resources["tmplMore"];

      lstData.ItemTemplate = dt;
    }

    private void btnLess_Click(object sender, RoutedEventArgs e)
    {
      DataTemplate dt;

      dt = (DataTemplate)this.Resources["tmplLess"];

      lstData.ItemTemplate = dt;
    }
  }
}
