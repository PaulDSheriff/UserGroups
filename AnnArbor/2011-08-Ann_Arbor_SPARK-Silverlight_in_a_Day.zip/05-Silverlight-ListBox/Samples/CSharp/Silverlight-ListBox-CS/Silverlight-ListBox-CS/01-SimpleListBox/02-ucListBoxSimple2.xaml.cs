﻿using System.Windows.Controls;

namespace Silverlight_ListBox_CS
{
  public partial class ucListBoxSimple2 : UserControl
  {
    public ucListBoxSimple2()
    {
      InitializeComponent();
    }
  }
}
