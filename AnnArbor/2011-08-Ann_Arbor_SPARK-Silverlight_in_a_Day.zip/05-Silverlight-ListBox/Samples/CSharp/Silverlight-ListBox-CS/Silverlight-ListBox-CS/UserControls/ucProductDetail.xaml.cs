﻿using System.Windows.Controls;

namespace Silverlight_ListBox_CS
{
  public partial class ucProductDetail : UserControl
  {
    public ucProductDetail()
    {
      InitializeComponent();
    }
  }
}
