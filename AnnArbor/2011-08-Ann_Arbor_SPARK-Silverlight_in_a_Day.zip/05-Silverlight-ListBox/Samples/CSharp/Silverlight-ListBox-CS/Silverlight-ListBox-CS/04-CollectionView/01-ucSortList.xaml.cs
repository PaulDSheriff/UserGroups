﻿using System.Windows.Controls;

namespace Silverlight_ListBox_CS
{
  public partial class ucSortList : UserControl
  {
    public ucSortList()
    {
      InitializeComponent();
    }
  }
}
