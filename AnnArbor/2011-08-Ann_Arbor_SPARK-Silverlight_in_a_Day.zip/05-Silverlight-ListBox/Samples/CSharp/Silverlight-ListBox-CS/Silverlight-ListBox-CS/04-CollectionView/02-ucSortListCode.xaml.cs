﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace Silverlight_ListBox_CS
{
  public partial class ucSortListCode : UserControl
  {
    public ucSortListCode()
    {
      InitializeComponent();
    }

    private void SortTheData(object sender, RoutedEventArgs e)
    {
      if (lstData != null)
      {
        string sortField = (sender as RadioButton).Tag.ToString();

        lstData.ItemsSource = SortData(sortField,
          (ICollectionView)lstData.ItemsSource);
      }
    }

    private ICollectionView SortData(string sortField,
      ICollectionView dataView)
    {
      dataView.SortDescriptions.Clear();
      dataView.SortDescriptions.Add(new
        SortDescription(sortField, ListSortDirection.Ascending));

      return dataView;
    }
  }
}
