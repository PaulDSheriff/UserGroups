﻿using System.ComponentModel;
using System.Windows.Controls;
using Silverlight_Data;

namespace Silverlight_ListBox_CS
{
  public partial class ucFilter : UserControl
  {
    public ucFilter()
    {
      InitializeComponent();
    }

    private void btnSearch_Click(System.Object sender, System.Windows.RoutedEventArgs e)
    {
      FilterData(txtName.Text);
    }

    private void FilterData(string filter)
    {
      if (lstData != null)
      {
        ICollectionView dataView = default(ICollectionView);

        dataView = (ICollectionView)lstData.ItemsSource;

        dataView.Filter = 
          prod => ((Product)prod).ProductName.ToLower().StartsWith(filter.ToLower());

        lstData.ItemsSource = dataView;
      }
    }
  }
}
