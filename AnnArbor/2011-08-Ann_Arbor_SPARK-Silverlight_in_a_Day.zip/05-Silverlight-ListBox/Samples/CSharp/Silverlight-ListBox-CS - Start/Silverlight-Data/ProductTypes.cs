﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Silverlight_Data
{
  public class ProductTypes : List<ProductType>
  {
    public ObservableCollection<ProductType> DataCollection { get; set; }
    
    private const string IMG_PATH = "../Images/";

    public ObservableCollection<ProductType> BuildCollection()
    {
      DataCollection = new ObservableCollection<ProductType>();

      DataCollection.Add(new ProductType("Product"));
      DataCollection.Add(new ProductType("Book"));

      return DataCollection;
    }
  }
}