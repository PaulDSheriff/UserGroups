﻿
namespace Silverlight_Data
{
  public class ProductType
  {
    public ProductType()
    {
    }

    public ProductType(string typeName)
    {
      this.ProductTypeName = typeName;
    }

    public string ProductTypeName { get; set; }
  }
}