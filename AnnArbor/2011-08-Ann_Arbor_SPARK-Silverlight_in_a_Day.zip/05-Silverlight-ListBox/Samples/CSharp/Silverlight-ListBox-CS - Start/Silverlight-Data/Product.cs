﻿using System;

namespace Silverlight_Data
{
  public class Product
  {
    #region Constructors
    public Product()
    {
    }

    public Product(int id, string name, string type, decimal price, DateTime introDate, string image, bool onSpecial)
    {
      this.ProductId = id;
      this.ProductName = name;
      this.ProductType = type;
      this.Price = price;
      this.IntroductionDate = introDate;
      this.Image = image;
      this.IsOnSpecial = onSpecial;
    }
    #endregion

    public int ProductId { get; set; }
    public string ProductName { get; set; }
    public string ProductType { get; set; }
    public decimal Price { get; set; }
    public DateTime IntroductionDate { get; set; }
    public string Image { get; set; }
    public bool IsOnSpecial { get; set; }
  }
}