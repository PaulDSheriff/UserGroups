﻿using System;
using System.IO;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Markup;

namespace SilverlightStylesComponent
{
  public class SilverlightCommon
  {
    public static string GetCurrentUri(Application app)
    {
      string path = string.Empty;

      path = app.Host.Source.AbsoluteUri;
      if (path.ToLower().IndexOf(@"/bin") > 0)
        path = path.Substring(0, path.ToLower().LastIndexOf(@"/bin")) + "/"; 

      return path;
    }

    public static string GetCurrentWebHost()
    {
      string path;

      // Using HtmlPage works even if you are in a Class
      // NOTE: The Web Project must be the Startup Project
      path = System.Windows.Browser.HtmlPage.Document.DocumentUri.ToString();
      path = path.Substring(0, path.LastIndexOf("/"));

      return path;
    }

    public static void LoadResource(UserControl uc, string fileName)
    {
      ResourceDictionary dic = null;

      dic = (ResourceDictionary)XamlReader.Load(fileName);
      uc.Resources.MergedDictionaries.Add(dic);
    }
  }
}
