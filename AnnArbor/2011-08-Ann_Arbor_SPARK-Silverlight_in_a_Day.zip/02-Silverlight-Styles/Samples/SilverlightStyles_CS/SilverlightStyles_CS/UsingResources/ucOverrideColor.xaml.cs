﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

// Need to add reference to System.Xml.Linq.dll
// This is needed for XDocument
using System.Xml.Linq;
// This is needed for the XamlReader
using System.Windows.Markup;

namespace SilverlightStyles_CS
{
  public partial class ucOverrideColor : UserControl
  {
    public ucOverrideColor()
    {
      // NOTE: Load any resources that will be used  
      // on this page before you run InitializeComponent()
      this.Resources.MergedDictionaries.Add(LoadResourceDictionary());

      InitializeComponent();
    }

    private ResourceDictionary LoadResourceDictionary()
    {
      ResourceDictionary ret = new ResourceDictionary();

      // NOTE: Must set file's Build Action="Content"
      XDocument xaml = XDocument.Load("Resources/OverrideStyle.xaml");
      // Turn XAML into Resource Dictionary
      ret = XamlReader.Load(xaml.ToString()) as ResourceDictionary;

      return ret;
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Can also load resources here as long as you assign directly to an item
      //ResourceDictionary rd = LoadResourceDictionary();

      //LayoutRoot.Style = rd["Grid.BackgroundColor"] as Style;
    }
  }
}