﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

// Need to add reference to System.Xml.Linq.dll
// This is needed for XDocument
using System.Xml.Linq;
// This is needed for the XamlReader
using System.Windows.Markup;
// Needed for Stream
using System.IO;

using SilverlightStylesComponent;

namespace SilverlightStyles_CS
{
  public partial class ucOverrideFromWeb : UserControl
  {
    public ucOverrideFromWeb()
    {
      // Must load any resources that will be used on this page before
      // you run InitializeComponent()
      LoadResourceDictionaryFromWeb();

      InitializeComponent();
    }

    #region DownloadString Methods
    private void LoadResourceDictionaryFromWeb()
    {
      WebClient client = new WebClient();

      client.DownloadStringCompleted += new DownloadStringCompletedEventHandler(client_DownloadStringCompleted);
      client.DownloadStringAsync(new Uri(SilverlightCommon.GetCurrentWebHost() + "/OverrideStyleWeb.xaml", UriKind.RelativeOrAbsolute));
    }

    void client_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
    {
      ResourceDictionary rd = new ResourceDictionary();
     
      // Turn the XAML in e.Result into a Resource Dictionary
      rd = XamlReader.Load(e.Result) as ResourceDictionary;

      // The following DOES NOT work because InitializeComponent() 
      // has already been run before the Completed event fires
      //this.Resources.MergedDictionaries.Clear();
      //this.Resources.MergedDictionaries.Add(rd);

      // Can assign an individual style
      LayoutRoot.Style = rd["Grid.BackgroundColor"] as Style;
    }
    #endregion
  }
}