﻿using System;
using System.Windows.Controls;
using System.Windows;
// Need to add reference to System.Xml.Linq.dll
// This is needed for XDocument
using System.Xml.Linq;
// This is needed for the XamlReader
using System.Windows.Markup;
// Needed for Stream
using System.IO;
// Needed for WebClient
using System.Net;

namespace SLLoadStylesAtStart
{
  public class SilverlightCommon
  {
    public static string GetCurrentUri(Application app)
    {
      string path = string.Empty;

      path = app.Host.Source.AbsoluteUri;
      if (path.ToLower().IndexOf(@"/bin") > 0)
      {
        path = path.Substring(0, path.ToLower().LastIndexOf(@"/bin")) + "/"; 
      }

      return path;
    }

    public static string GetCurrentWebHost()
    {
      string path;

      // Using HtmlPage works even if you are a Class
      path = System.Windows.Browser.HtmlPage.Document.DocumentUri.ToString();
      path = path.Substring(0, path.LastIndexOf("/"));

      return path;
    }

    public static void LoadResource(UserControl uc, string fileName)
    {
      ResourceDictionary dic = null;

      dic = (ResourceDictionary)XamlReader.Load(fileName);
      uc.Resources.MergedDictionaries.Add(dic);
    }

    public static void LoadResourceDictionaryFromWeb(string resourceName)
    {
      WebClient client = new WebClient();

      client.OpenReadCompleted += new OpenReadCompletedEventHandler(client_OpenReadCompleted);
      client.OpenReadAsync(new Uri(SilverlightCommon.GetCurrentWebHost() + "/" + resourceName, UriKind.RelativeOrAbsolute));
    }

    static void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    {
      ResourceDictionary rd = new ResourceDictionary();

      // Get result as a Stream
      Stream st = e.Result;
      // Load stream into an XDocument object
      XDocument xaml = XDocument.Load(st);
      // Turn the XAML in XDocument object into a Resource Dictionary
      rd = XamlReader.Load(xaml.ToString()) as ResourceDictionary;
      // Close Stream
      st.Close();

      // Can remove just single style
      //App.Current.Resources.Remove("Grid.BackgroundColor");
      // Or can remove all styles
      App.Current.Resources.Clear();

      // Add to Application Dictionaries
      App.Current.Resources.MergedDictionaries.Add(rd);
    }
  }
}
