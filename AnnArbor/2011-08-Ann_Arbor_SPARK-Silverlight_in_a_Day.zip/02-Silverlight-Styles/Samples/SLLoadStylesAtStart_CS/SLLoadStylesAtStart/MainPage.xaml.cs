﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace SLLoadStylesAtStart
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    DispatcherTimer _Timer = new DispatcherTimer();

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      switch (txtUserName.Text.Trim().ToLower())
      {
        case "paul":
          SilverlightCommon.LoadResourceDictionaryFromWeb("Green.xaml");
          break;

        case "billy":
          SilverlightCommon.LoadResourceDictionaryFromWeb("Blue.xaml");
          break;
          
        case "russ":
          SilverlightCommon.LoadResourceDictionaryFromWeb("Red.xaml");
          break;
      }

      btnLogin.IsEnabled = false;
      tbMessage.Visibility = System.Windows.Visibility.Visible;
      _Timer.Interval = new TimeSpan(0, 0, 0, 1, 0);
      _Timer.Tick += new EventHandler(_Timer_Tick);
      _Timer.Start();     
    }

    void _Timer_Tick(object sender, EventArgs e)
    {
      this.Content = new Page2();
    }
  }
}
