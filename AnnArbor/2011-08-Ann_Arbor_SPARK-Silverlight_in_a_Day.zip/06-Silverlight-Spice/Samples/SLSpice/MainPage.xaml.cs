﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLSpice
{
  public partial class MainPage : UserControl
  {
    #region Constructor
    public MainPage()
    {
      InitializeComponent();
    }
    #endregion

    private void lstMenus_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ListBoxItem item = (ListBoxItem)((ListBox)sender).SelectedItem;

      // Get Tag from selected item. "Tag" has the name of the control to load in it
      if (item.Tag != null)
        if (item.Tag.ToString() != string.Empty)
          LoadMenu(item.Tag.ToString());
    }

    private void LoadMenu(string controlName)
    {
      UserControl ctl = null;
      Type typ;

      // Create a Type from the controlName parameter
      typ = Type.GetType(controlName);
      // Create an instance of this control
      ctl = (UserControl)Activator.CreateInstance(typ);
      // Clear Content Area for next control
      contentArea.Children.Clear();
      if (ctl != null)
        contentArea.Children.Add(ctl);
    }
  }
}
