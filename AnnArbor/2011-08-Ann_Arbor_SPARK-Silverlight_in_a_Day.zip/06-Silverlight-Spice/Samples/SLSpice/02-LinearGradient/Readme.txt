﻿0, 0, 0, 0.5 – Top (Dark) to Bottom (Light)
0.5, 0, 0, 1 – Right (Dark) to Left (Light)
0, 0, 0.5, 1 – Left (Dark) to Right (Light)
0, 0.5, 0, 0 – Bottom (Dark) to Top (Light)
