﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SLSpice
{
  public partial class ucMainMenu : UserControl
  {
    public ucMainMenu()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      this.DataContext = this;
    }

    public string Text
    {
      get { return (string)GetValue(TextProperty); }
      set { SetValue(TextProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty TextProperty =
        DependencyProperty.Register("Text", typeof(string), typeof(ucMainMenu), null);

    Storyboard sb;

    private void Border_MouseEnter(object sender, MouseEventArgs e)
    {
      sb = (Storyboard)this.Resources["ScaleUpStory"];
      sb.Stop();
      sb.Begin();
    }

    private void borMenu_MouseLeave(object sender, MouseEventArgs e)
    {
      sb = (Storyboard)this.Resources["ScaleDownStory"];
      sb.Stop();
      sb.Begin();
    }    
  }
}
