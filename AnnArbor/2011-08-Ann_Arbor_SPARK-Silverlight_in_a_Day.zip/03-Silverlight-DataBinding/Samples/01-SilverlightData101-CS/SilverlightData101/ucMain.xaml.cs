﻿using System.Windows;
using System.Windows.Controls;

namespace SilverlightData101
{
  public partial class ucMain : UserControl
  {
    public ucMain()
    {
      InitializeComponent();
    }

		#region Load User Control Method
		private void LoadUserControl(UserControl uc)
		{
			this.Content = uc;
		}
		#endregion

		private void btnTextBoxToLabel_Click(object sender, RoutedEventArgs e)
		{
			LoadUserControl(new ucTextBoxToTextBlock());
		}

		private void btnComboToTextBlock_Click(object sender, RoutedEventArgs e)
		{
			LoadUserControl(new ucComboToTextBlock());
		}

		private void btnComboUsingTag_Click(object sender, RoutedEventArgs e)
		{
			LoadUserControl(new ucComboUsingTag());
		}

		private void btnLocalData_Click(object sender, RoutedEventArgs e)
		{
			LoadUserControl(new ucLocalData());
		}

		private void btnLocalCollectionData_Click(object sender, RoutedEventArgs e)
		{
			LoadUserControl(new ucLocalCollectionData());
		}

		private void btnIsEnabled_Click(object sender, RoutedEventArgs e)
		{
			LoadUserControl(new ucEnabled());
		}
  }
}
