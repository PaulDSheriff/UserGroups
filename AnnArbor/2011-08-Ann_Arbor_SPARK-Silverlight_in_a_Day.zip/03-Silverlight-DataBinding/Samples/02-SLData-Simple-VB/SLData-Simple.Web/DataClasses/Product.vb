﻿Imports System.Runtime.Serialization

<DataContract()> _
Public Class Product
  Public Sub New(ByVal prodName As String)
    ProductName = prodName
  End Sub

  Private mProductName As String

  <DataMember()> _
  Public Property ProductName() As String
    Get
      Return mProductName
    End Get
    Set(ByVal value As String)
      mProductName = value
    End Set
  End Property
End Class

Public Class Products
  Inherits List(Of Product)
End Class