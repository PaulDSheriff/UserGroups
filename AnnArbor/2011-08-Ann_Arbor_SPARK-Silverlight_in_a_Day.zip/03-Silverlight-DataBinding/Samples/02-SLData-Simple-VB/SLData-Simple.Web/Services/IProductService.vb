﻿Imports System.ServiceModel

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IProductService" in both code and config file together.
<ServiceContract()>
Public Interface IProductService

  <OperationContract()>
  Function GetProducts() As Products

End Interface
