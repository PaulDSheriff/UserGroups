﻿using System;
using System.Windows;
using System.Windows.Controls;
using SLData_Simple.ProductServiceReference;

namespace SLData_Simple
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      ProductServiceClient client = new ProductServiceClient();

      client.GetProductsCompleted +=
       new EventHandler
         <GetProductsCompletedEventArgs>
          (client_GetProductsCompleted);
      client.GetProductsAsync();
      client.CloseAsync();
    }

    void client_GetProductsCompleted(
      object sender,
      GetProductsCompletedEventArgs e)
    {
      lstData.DataContext = e.Result;
    }
  }
}
