﻿using System;
using System.Runtime.Serialization;

namespace Sandbox.Services
{
[DataContract]
public class ProductResponse : ResponseBase
{
  [DataMember]
  public Product DetailData { get; set; }

  [DataMember]
  public Products DataCollection { get; set; }
}
}
