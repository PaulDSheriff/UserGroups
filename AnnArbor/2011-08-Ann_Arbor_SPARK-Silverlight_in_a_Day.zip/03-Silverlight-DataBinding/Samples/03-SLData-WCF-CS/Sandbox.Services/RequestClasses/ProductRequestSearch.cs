﻿using System;
using System.Runtime.Serialization;

namespace Sandbox.Services
{
  public enum ProductSearchName
  {
    NA,
    CostGreaterThan,
    PriceGreaterThan,
    LIKEProductName,
    Custom
  }

  [DataContract]
  public class ProductRequestSearch : RequestBase
  {
    public ProductRequestSearch()
    {
      SearchObject = new Product();
      ProductSearchName = Services.ProductSearchName.NA;
    }

    [DataMember]
    public Product SearchObject { get; set; }

    [DataMember]
    public ProductSearchName ProductSearchName { get; set; }
  }
}
