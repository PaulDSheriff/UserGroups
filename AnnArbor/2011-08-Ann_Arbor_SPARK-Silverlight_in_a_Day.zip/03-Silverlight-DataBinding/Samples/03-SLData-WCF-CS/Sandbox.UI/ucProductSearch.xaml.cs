﻿using System;
using System.Windows;
using System.Windows.Controls;

using Sandbox.UI.SandboxServicesHost;

namespace Sandbox.UI
{
  public partial class ucProductSearch : UserControl
  {
    private ProductRequestSearch mSearch;

    public ucProductSearch()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      InitSearchObject();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();

      lstData.DataContext = null;
      tbMessage.Text = string.Empty;
      if (mSearch.SearchObject.ProductName.Trim() != string.Empty)
        mSearch.ProductSearchName = ProductSearchName.LIKEProductName;
      else if (mSearch.SearchObject.Cost > 0)
        mSearch.ProductSearchName = ProductSearchName.CostGreaterThan;
      else if (mSearch.SearchObject.Price > 0)
        mSearch.ProductSearchName = ProductSearchName.PriceGreaterThan;

      client.ProductSearchCompleted += new EventHandler<ProductSearchCompletedEventArgs>(client_ProductSearchCompleted);
      client.ProductSearchAsync(mSearch);
      client.CloseAsync();
    }

    void client_ProductSearchCompleted(object sender, ProductSearchCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Success)
        lstData.DataContext = e.Result.DataCollection;
      else
        if (e.Result.ErrorMessage.Trim() != string.Empty)
          tbMessage.Text = e.Result.ErrorMessage;
        else
          tbMessage.Text = e.Result.FriendlyErrorMessage;
    }

    private void btnReset_Click(object sender, RoutedEventArgs e)
    {
      InitSearchObject();
    }

    private void InitSearchObject()
    {
      mSearch = new ProductRequestSearch();
      mSearch.SearchObject = new Product();
      mSearch.SearchObject.ProductName = string.Empty;
      ucSearch.DataContext = mSearch.SearchObject;
    }
  }
}
