﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Sandbox.UI.SandboxServicesHost;

namespace Sandbox.UI
{
  public partial class ucProductList : UserControl
  {
    public ucProductList()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();

      client.GetAllProductsCompleted += new EventHandler<GetAllProductsCompletedEventArgs>(client_GetAllProductsCompleted);
      client.GetAllProductsAsync();
      client.CloseAsync();
    }

    void client_GetAllProductsCompleted(object sender, GetAllProductsCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Success)
        lstData.DataContext = e.Result.DataCollection;
      else
        if (e.Result.ErrorMessage.Trim() != string.Empty)
          tbMessage.Text = e.Result.ErrorMessage;
        else
          tbMessage.Text = e.Result.FriendlyErrorMessage;
    }
  }
}
