﻿Public Class ViewModelBase
  Inherits CommonBase

  Private _MessageToDisplay As String = String.Empty
  Private _IsMessageVisible As Boolean = False

  Public Property MessageToDisplay() As String
    Get
      Return _MessageToDisplay
    End Get
    Set(ByVal value As String)
      _MessageToDisplay = value
      RaisePropertyChanged("MessageToDisplay")
    End Set
  End Property

  Public Property IsMessageVisible() As Boolean
    Get
      Return _IsMessageVisible
    End Get
    Set(ByVal value As Boolean)
      _IsMessageVisible = value
      RaisePropertyChanged("IsMessageVisible")
    End Set
  End Property

End Class
