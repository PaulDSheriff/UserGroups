﻿Public Class DataClassBase
  Inherits CommonBase

  Public Sub New()
    _BusinessRuleFailures = New BusinessRuleMessages()
  End Sub

  Private _BusinessRuleFailures As BusinessRuleMessages

  Public Property BusinessRuleFailures() As BusinessRuleMessages
    Get
      Return _BusinessRuleFailures
    End Get
    Set(ByVal value As BusinessRuleMessages)
      _BusinessRuleFailures = value
      RaisePropertyChanged("BusinessRuleFailures")
    End Set
  End Property
End Class
