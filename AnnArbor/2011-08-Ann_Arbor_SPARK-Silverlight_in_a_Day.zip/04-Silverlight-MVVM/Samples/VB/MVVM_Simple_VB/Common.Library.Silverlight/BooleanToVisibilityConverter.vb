﻿Imports System.Globalization
Imports System.Windows
Imports System.Windows.Data

''' <summary>
''' Call this converter to change a True value to Visible and a False value to Collapsed
''' </summary>
Public Class BooleanToVisibilityConverter
  Implements IValueConverter

  ''' <summary>
  ''' Convert a True/False value to Visibility.Visible/Visibility.Collapsed value
  ''' </summary>
  ''' <param name="value">A boolean value</param>
  ''' <param name="targetType">The type of object</param>
  ''' <param name="parameter">Any parameters passed via XAML</param>
  ''' <param name="culture">The current culture</param>
  ''' <returns>A Visibility Enumeration</returns>
  Public Function Convert(ByVal value As Object, ByVal targetType As Type, ByVal parameter As Object, ByVal culture As CultureInfo) As Object Implements IValueConverter.Convert
    If System.Convert.ToBoolean(value) Then
      Return Visibility.Visible
    Else
      Return Visibility.Collapsed
    End If
  End Function

  ''' <summary>
  ''' NOT IMPLEMENTED
  ''' </summary>
  ''' <param name="value">A boolean value</param>
  ''' <param name="targetType">The type of object</param>
  ''' <param name="parameter">Any parameters passed via XAML</param>
  ''' <param name="culture">The current culture</param>
  ''' <returns>NOT IMPLEMENTED</returns>
  Public Function ConvertBack(ByVal value As Object, ByVal targetType As Type, ByVal parameter As Object, ByVal culture As CultureInfo) As Object Implements IValueConverter.ConvertBack
    Throw New NotImplementedException("PDSABooleanToVisibility ConvertBack Method Not Implemented")
  End Function
End Class