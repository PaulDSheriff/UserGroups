﻿Imports System.Collections.ObjectModel
Imports System.Windows
Imports System.Windows.Controls
Imports MVVM_Simple.ProductServiceReference

Partial Public Class ucNoBinding
  Inherits UserControl

  Public Sub New()
    InitializeComponent()
  End Sub

  Private _IsAddMode As Boolean = False
  Private WithEvents _Client As New ProductServicesClient()

#Region "Loaded Event"
  Private Sub UserControl_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    _Client.GetProductsAsync()
    _Client.CloseAsync()
  End Sub

  Private Sub _Client_GetProductsCompleted(ByVal sender As Object, ByVal e As GetProductsCompletedEventArgs) Handles _Client.GetProductsCompleted
    lstData.DataContext = e.Result.DataCollection
  End Sub
#End Region

#Region "SelectionChanged Event"
  Private Sub lstData_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
    Dim entity As Product
    entity = DirectCast(lstData.SelectedItem, Product)

    txtProductId.Text = entity.ProductId.ToString()
    txtProductName.Text = entity.ProductName
    txtPrice.Text = entity.Price.ToString()
    txtIntroductionDate.Text = entity.IntroductionDate.ToShortDateString()
    chkIsDiscontinued.IsChecked = entity.IsDiscontinued
  End Sub
#End Region

#Region "Add Click Event"
  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Put UI into Add Mode
    _IsAddMode = True
    SetEditUIDisplay()

    ' Create empty input fields
    txtProductId.Text = "0"
    txtProductName.Text = String.Empty
    txtIntroductionDate.Text = DateTime.Now.ToShortDateString()
    txtPrice.Text = "0"
    chkIsDiscontinued.IsChecked = True
  End Sub
#End Region

#Region "Cancel Click Event"
  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Cancel the Edit
    SetNormalUIDisplay()

    ' TODO: Write code to undo changes

    lstData.SelectedIndex = 0
  End Sub
#End Region

#Region "Save Click Event"
  Private Sub btnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If _IsAddMode Then
      AddData()
    Else
      UpdateData()
    End If

    SetNormalUIDisplay()
  End Sub
#End Region

#Region "AddData Method"
  Private Sub AddData()
    Dim entity As New Product()
    _Client = New ProductServicesClient()

    entity.ProductId = Convert.ToInt32(txtProductId.Text)
    entity.ProductName = txtProductName.Text
    entity.Price = Convert.ToDecimal(txtPrice.Text)
    entity.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text)
    entity.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked)

    Dim coll As ObservableCollection(Of Product) = DirectCast(lstData.DataContext, ObservableCollection(Of Product))
    coll.Add(entity)

    ' Save Data
    _Client.InsertAsync(entity)
    _Client.CloseAsync()
  End Sub

  Private Sub _Client_InsertCompleted(ByVal sender As Object, ByVal e As InsertCompletedEventArgs) Handles _Client.InsertCompleted
    If e.Result.Status = OperationResult.Exception Then
      tbMessages.Text = e.Result.ErrorMessage
    Else
      tbMessages.Text = "Insert Successful"
    End If
  End Sub
#End Region

#Region "UpdateData Method"
  Private Sub UpdateData()
    Dim entity As Product = DirectCast(lstData.SelectedItem, Product)
    _Client = New ProductServicesClient()

    entity.ProductId = Convert.ToInt32(txtProductId.Text)
    entity.ProductName = txtProductName.Text
    entity.Price = Convert.ToDecimal(txtPrice.Text)
    entity.IntroductionDate = Convert.ToDateTime(txtIntroductionDate.Text)
    entity.IsDiscontinued = Convert.ToBoolean(chkIsDiscontinued.IsChecked)

    ' Save Data
    _Client.UpdateAsync(entity)
    _Client.CloseAsync()
  End Sub

  Private Sub _Client_UpdateCompleted(ByVal sender As Object, ByVal e As UpdateCompletedEventArgs) Handles _Client.UpdateCompleted
    If e.Result.Status = OperationResult.Exception Then
      tbMessages.Text = e.Result.ErrorMessage
    Else
      tbMessages.Text = "Update Successful"
    End If
  End Sub
#End Region

#Region "SetNormalUIDisplay Method"
  Private Sub SetNormalUIDisplay()
    _IsAddMode = False
    btnAdd.IsEnabled = True
    btnSave.IsEnabled = False
    btnCancel.IsEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Private Sub SetEditUIDisplay()
    btnAdd.IsEnabled = False
    btnSave.IsEnabled = True
    btnCancel.IsEnabled = True
  End Sub
#End Region
End Class
