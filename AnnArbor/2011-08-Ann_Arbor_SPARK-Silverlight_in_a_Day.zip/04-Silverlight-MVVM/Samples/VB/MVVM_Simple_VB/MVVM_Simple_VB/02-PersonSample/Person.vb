﻿Public Class Person
  Inherits DataClassBase

#Region "Constructor"
  Public Sub New()
    FirstName = String.Empty
    LastName = String.Empty
    BirthDate = DateTime.Now.AddYears(-20)
  End Sub
#End Region

#Region "Private Variables"
  Private _FirstName As String
  Private _LastName As String
  Private _BirthDate As DateTime
#End Region

#Region "Public Properties"
  Public Property FirstName() As String
    Get
      Return _FirstName
    End Get
    Set(ByVal value As String)
      _FirstName = value
      RaisePropertyChanged("FirstName")
    End Set
  End Property

  Public Property LastName() As String
    Get
      Return _LastName
    End Get
    Set(ByVal value As String)
      _LastName = value
      RaisePropertyChanged("LastName")
    End Set
  End Property

  Public Property BirthDate() As DateTime
    Get
      Return _BirthDate
    End Get
    Set(ByVal value As DateTime)
      _BirthDate = value
      RaisePropertyChanged("BirthDate")
    End Set
  End Property
#End Region

#Region "Validate Method"
  ''' <summary>
  ''' Validate Business Rules
  ''' </summary>
  ''' <returns>True if all rules pass, False otherwise</returns>
  Public Function Validate() As Boolean
    ' Clear Business Rule Failure Collection
    BusinessRuleFailures.Clear()

    If FirstName.Trim() = String.Empty Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("FirstName", "First Name Must Be Filled In."))
    ElseIf FirstName.Trim().Length < 2 Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("FirstName", "First Name Must Be More Than 1 Character."))
    End If

    If LastName.Trim() = String.Empty Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("LastName", "Last Name Must Be Filled In."))
    ElseIf LastName.Trim().Length < 2 Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("LastName", "Last Name Must Be More Than 1 Character."))
    End If

    ' Check Birth Date, assume no one is older than 110 years old!
    If BirthDate < DateTime.Now.AddYears(-110) Then
      BusinessRuleFailures.Add(New BusinessRuleMessage("BirthDate", "Birth Date Must Be Greater Than " & DateTime.Now.AddYears(-110).ToShortDateString()))
    End If

    Return (BusinessRuleFailures.Count = 0)
  End Function
#End Region
End Class