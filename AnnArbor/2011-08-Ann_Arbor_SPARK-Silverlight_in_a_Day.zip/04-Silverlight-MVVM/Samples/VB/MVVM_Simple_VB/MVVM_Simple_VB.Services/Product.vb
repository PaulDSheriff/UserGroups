﻿Imports System.Runtime.Serialization

<DataContract()> _
  Public Class Product
  Inherits CommonBase
#Region "Constructor"
  Public Sub New()
  End Sub
#End Region

#Region "Private Variables"
  Private _ProductId As Integer = 0
  Private _ProductName As String = String.Empty
  Private _IntroductionDate As DateTime
  Private _Cost As Decimal = 0
  Private _Price As Decimal = 0
  Private _IsDiscontinued As Boolean = False
#End Region

#Region "Public Properties"
  <DataMember()> _
  Public Property ProductId() As Integer
    Get
      Return _ProductId
    End Get
    Set(ByVal value As Integer)
      If _ProductId <> value Then
        _ProductId = value
        RaisePropertyChanged("ProductId")
      End If
    End Set
  End Property

  <DataMember()> _
  Public Property ProductName() As String
    Get
      Return _ProductName
    End Get
    Set(ByVal value As String)
      If _ProductName <> value Then
        _ProductName = value
        RaisePropertyChanged("ProductName")
      End If
    End Set
  End Property

  <DataMember()> _
  Public Property IntroductionDate() As DateTime
    Get
      Return _IntroductionDate
    End Get
    Set(ByVal value As DateTime)
      If _IntroductionDate <> value Then
        _IntroductionDate = value
        RaisePropertyChanged("IntroductionDate")
      End If
    End Set
  End Property

  <DataMember()> _
  Public Property Cost() As Decimal
    Get
      Return _Cost
    End Get
    Set(ByVal value As Decimal)
      If _Cost <> value Then
        _Cost = value
        RaisePropertyChanged("Cost")
      End If
    End Set
  End Property

  <DataMember()> _
  Public Property Price() As Decimal
    Get
      Return _Price
    End Get
    Set(ByVal value As Decimal)
      If _Price <> value Then
        _Price = value
        RaisePropertyChanged("Price")
      End If
    End Set
  End Property

  <DataMember()> _
  Public Property IsDiscontinued() As Boolean
    Get
      Return _IsDiscontinued
    End Get
    Set(ByVal value As Boolean)
      If _IsDiscontinued <> value Then
        _IsDiscontinued = value
        RaisePropertyChanged("IsDiscontinued")
      End If
    End Set
  End Property
#End Region
End Class