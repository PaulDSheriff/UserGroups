﻿Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Diagnostics

Public Class ProductServices
  Implements IProductServices

#Region "GetProducts Method"
  Public Function GetProducts() As ProductResponse Implements IProductServices.GetProducts
    Dim ret As New ProductResponse()
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim da As SqlDataAdapter = Nothing
    Dim ds As New DataSet()

    ret.Status = OperationResult.Unknown
    sql = "SELECT * "
    sql += " FROM Product "
    sql += " ORDER BY ProductName "
    Try
      cnn = New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectString").ConnectionString)
      cmd = New SqlCommand(sql, cnn)
      cnn.Open()

      da = New SqlDataAdapter(cmd)

      da.Fill(ds)

      ret.DataCollection = New Products()
      If ds.Tables.Count > 0 Then
        If ds.Tables(0).Rows.Count > 0 Then
          For Each dr As DataRow In ds.Tables(0).Rows
            Dim prod As New Product()

            prod.ProductId = Convert.ToInt32(dr("ProductId"))
            prod.ProductName = Convert.ToString(dr("ProductName"))
            prod.IntroductionDate = Convert.ToDateTime(dr("IntroductionDate"))
            prod.Cost = Convert.ToDecimal(dr("Cost"))
            prod.Price = Convert.ToDecimal(dr("Price"))
            prod.IsDiscontinued = Convert.ToBoolean(dr("IsDiscontinued"))

            ret.DataCollection.Add(prod)
          Next

          ret.Status = OperationResult.Success
          ret.FriendlyErrorMessage = "Data Retrieval was Successful"
        Else
          ret.Status = OperationResult.Failure
          ret.FriendlyErrorMessage = "No Products in Table"
        End If
      End If
    Catch ex As Exception
      ' Fill in Response Exception
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.ToString()
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region

#Region "GetProduct Method"
  Public Function GetProduct(ByVal productId As Integer) As ProductResponse Implements IProductServices.GetProduct
    Dim ret As New ProductResponse()
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim parm As SqlParameter = Nothing
    Dim da As SqlDataAdapter = Nothing
    Dim ds As New DataSet()
    Dim dr As DataRow

    ret.Status = OperationResult.Unknown
    sql = "SELECT * "
    sql += " FROM Product "
    sql += " WHERE ProductId = @ProductId"
    Try
      cnn = New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectString").ConnectionString)
      cmd = New SqlCommand(sql, cnn)
      parm = New SqlParameter("@ProductId", productId)
      cmd.Parameters.Add(parm)
      cnn.Open()

      da = New SqlDataAdapter(cmd)

      da.Fill(ds)

      If ds.Tables.Count > 0 Then
        If ds.Tables(0).Rows.Count > 0 Then
          dr = ds.Tables(0).Rows(0)

          ret.DetailData = New Product()
          ret.DetailData.ProductId = Convert.ToInt32(dr("ProductId"))
          ret.DetailData.ProductName = Convert.ToString(dr("ProductName"))
          ret.DetailData.IntroductionDate = Convert.ToDateTime(dr("IntroductionDate"))
          ret.DetailData.Cost = Convert.ToDecimal(dr("Cost"))
          ret.DetailData.Price = Convert.ToDecimal(dr("Price"))
          ret.DetailData.IsDiscontinued = Convert.ToBoolean(dr("IsDiscontinued"))

          ret.Status = OperationResult.Success
          ret.FriendlyErrorMessage = "Data Retrieval was Successful"
        Else
          ret.Status = OperationResult.Failure
          ret.FriendlyErrorMessage = "Can't Find Product: " & productId.ToString()
        End If
      End If
    Catch ex As Exception
      ' Fill in Response Exception
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.ToString()
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region

#Region "Update Method"
  Public Function Update(ByVal prod As Product) As ProductResponse Implements IProductServices.Update
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim parm As SqlParameter = Nothing
    Dim ret As New ProductResponse()

    ret.Status = OperationResult.Unknown
    sql = "UPDATE Product "
    sql += " SET "
    sql += " ProductName = @ProductName, "
    sql += " IntroductionDate = @IntroductionDate, "
    sql += " Cost = @Cost, "
    sql += " Price = @Price, "
    sql += " IsDiscontinued = @IsDiscontinued "
    sql += " WHERE ProductId = @ProductId "
    Try
      cnn = New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectString").ConnectionString)
      cmd = New SqlCommand(sql, cnn)
      parm = New SqlParameter("@ProductName", prod.ProductName)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IntroductionDate", prod.IntroductionDate)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Cost", prod.Cost)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Price", prod.Price)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IsDiscontinued", prod.IsDiscontinued)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@ProductId", prod.ProductId)
      cmd.Parameters.Add(parm)

      cnn.Open()

      cmd.ExecuteNonQuery()
      ret.Status = OperationResult.Success
      ret.FriendlyErrorMessage = "Update was Successful"
    Catch ex As Exception
      ' Publish exception here
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.Message
      ret.FriendlyErrorMessage = "The Update to the Product Table did not Work."
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region

#Region "Insert Method"
  Public Function Insert(ByVal prod As Product) As ProductResponse Implements IProductServices.Insert
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim parm As SqlParameter = Nothing
    Dim ret As New ProductResponse()

    ret.Status = OperationResult.Unknown
    sql = "INSERT INTO Product(ProductName, "
    sql += " IntroductionDate, Cost, Price, IsDiscontinued)"
    sql += " VALUES(@ProductName, @IntroductionDate, "
    sql += " @Cost, @Price, @IsDiscontinued)"
    Try
      cnn = New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectString").ConnectionString)
      cmd = New SqlCommand(sql, cnn)
      parm = New SqlParameter("@ProductName", prod.ProductName)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IntroductionDate", prod.IntroductionDate)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Cost", prod.Cost)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@Price", prod.Price)
      cmd.Parameters.Add(parm)
      parm = New SqlParameter("@IsDiscontinued", prod.IsDiscontinued)
      cmd.Parameters.Add(parm)

      cnn.Open()

      cmd.ExecuteNonQuery()

      ' Retrieve Product ID
      cmd.Parameters.Clear()
      cmd.CommandText = "SELECT @@IDENTITY"
      prod.ProductId = Convert.ToInt32(cmd.ExecuteScalar())

      ret.Status = OperationResult.Success
      ret.FriendlyErrorMessage = "Insert was Successful"
      ' Return entity class so the IDENTITY value can be retrieved
      ret.DetailData = prod
    Catch ex As Exception
      ' Publish exception here
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.Message
      ret.FriendlyErrorMessage = "The Insert to the Product Table did not Work."
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region

#Region "Delete Method"
  Public Function Delete(ByVal productId As Integer) As ProductResponse Implements IProductServices.Delete
    Dim sql As String = String.Empty
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing
    Dim parm As SqlParameter = Nothing
    Dim ret As New ProductResponse()

    ret.Status = OperationResult.Unknown
    sql = "DELETE FROM Product "
    sql += " WHERE ProductId = @ProductId "
    Try
      cnn = New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectString").ConnectionString)
      cmd = New SqlCommand(sql, cnn)
      parm = New SqlParameter("@ProductId", productId)
      cmd.Parameters.Add(parm)

      cnn.Open()

      cmd.ExecuteNonQuery()
      ret.Status = OperationResult.Success
      ret.FriendlyErrorMessage = "Delete was Successful"
    Catch ex As Exception
      ' Publish exception here
      ret.Status = OperationResult.Exception
      ret.ErrorMessage = ex.Message
      ret.FriendlyErrorMessage = "The Delete to the Product Table did not Work."
    Finally
      If cnn IsNot Nothing And cnn.State = ConnectionState.Open Then
        cnn.Close()
      End If
    End Try

    Return ret
  End Function
#End Region
End Class