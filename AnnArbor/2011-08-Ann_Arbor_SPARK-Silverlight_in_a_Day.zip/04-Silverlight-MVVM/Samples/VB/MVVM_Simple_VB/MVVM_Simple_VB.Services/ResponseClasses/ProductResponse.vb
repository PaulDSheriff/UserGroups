﻿Imports System.Runtime.Serialization

<DataContract()> _
  Public Class ProductResponse
  Inherits ResponseBase
  <DataMember()> _
  Public Property DetailData() As Product
    Get
      Return m_DetailData
    End Get
    Set(ByVal value As Product)
      m_DetailData = value
    End Set
  End Property
  Private m_DetailData As Product

  <DataMember()> _
  Public Property DataCollection() As Products
    Get
      Return m_DataCollection
    End Get
    Set(ByVal value As Products)
      m_DataCollection = value
    End Set
  End Property
  Private m_DataCollection As Products
End Class