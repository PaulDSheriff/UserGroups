﻿
namespace Common.Library
{
  public class ViewModelBase : CommonBase
  {
    private string _MessageToDisplay = string.Empty;
    private bool _IsMessageVisible = false;

    public string MessageToDisplay 
    {
      get { return _MessageToDisplay; }
      set
      {
        _MessageToDisplay = value;
        RaisePropertyChanged("MessageToDisplay");
      }
    }

    public bool IsMessageVisible
    {
      get { return _IsMessageVisible; }
      set
      {
        _IsMessageVisible = value;
        RaisePropertyChanged("IsMessageVisible");
      }
    }
  }
}
