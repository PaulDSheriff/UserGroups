﻿
namespace Common.Library
{
  public class BusinessRuleMessage
  {
    #region Constructors
    public BusinessRuleMessage()
    {
    }

    public BusinessRuleMessage(string propertyName, string message)
    {
      PropertyName = propertyName;
      Message = message;
    }
    #endregion

    #region Public Properties
    public string PropertyName { get; set; }
    public string Message { get; set; }
    #endregion
  }
}
