﻿using System;
using System.Runtime.Serialization;

namespace MVV_Simple_CS.Services
{
  public enum OperationResult
  {
    Unknown,
    Success,
    Exception,
    Failure
  }

  [DataContract]
  public class ResponseBase
  {
    public ResponseBase()
    {
      Status = OperationResult.Unknown;
      FriendlyErrorMessage = string.Empty;
      ErrorMessage = string.Empty;
    }

    [DataMember]
    public OperationResult Status { get; set; }

    [DataMember]
    public string FriendlyErrorMessage { get; set; }

    [DataMember]
    public string ErrorMessage { get; set; }
  }
}
