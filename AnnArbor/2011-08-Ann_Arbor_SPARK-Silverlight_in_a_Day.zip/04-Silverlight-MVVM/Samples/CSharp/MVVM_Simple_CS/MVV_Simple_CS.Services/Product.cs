﻿using System;

using System.Runtime.Serialization;
using Common.Library;

namespace MVV_Simple_CS.Services
{
  [DataContract]
  public class Product : CommonBase
  {
    #region Constructor
    public Product()
    {
    }
    #endregion

    #region Private Variables
    private int _ProductId = 0;
    private string _ProductName = string.Empty;
    private DateTime _IntroductionDate;
    private decimal _Cost = 0;
    private decimal _Price = 0;
    private bool _IsDiscontinued = false;
    #endregion

    #region Public Properties
    [DataMember]
    public int ProductId
    {
      get { return _ProductId; }
      set
      {
        if (_ProductId != value)
        {
          _ProductId = value;
          RaisePropertyChanged("ProductId");
        }
      }
    }

    [DataMember]
    public string ProductName
    {
      get { return _ProductName; }
      set
      {
        if (_ProductName != value)
        {
          _ProductName = value;
          RaisePropertyChanged("ProductName");
        }
      }
    }

    [DataMember]
    public DateTime IntroductionDate
    {
      get { return _IntroductionDate; }
      set
      {
        if (_IntroductionDate != value)
        {
          _IntroductionDate = value;
          RaisePropertyChanged("IntroductionDate");
        }
      }
    }

    [DataMember]
    public decimal Cost
    {
      get { return _Cost; }
      set
      {
        if (_Cost != value)
        {
          _Cost = value;
          RaisePropertyChanged("Cost");
        }
      }
    }

    [DataMember]
    public decimal Price
    {
      get { return _Price; }
      set
      {
        if (_Price != value)
        {
          _Price = value;
          RaisePropertyChanged("Price");
        }
      }
    }

    [DataMember]
    public bool IsDiscontinued
    {
      get { return _IsDiscontinued; }
      set
      {
        if (_IsDiscontinued != value)
        {
          _IsDiscontinued = value;
          RaisePropertyChanged("IsDiscontinued");
        }
      }
    }
    #endregion
  }
}
