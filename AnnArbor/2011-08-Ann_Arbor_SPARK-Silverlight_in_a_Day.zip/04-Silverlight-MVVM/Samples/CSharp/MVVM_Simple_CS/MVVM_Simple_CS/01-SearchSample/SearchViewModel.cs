﻿using System;
using Common.Library;

namespace MVVM_Simple
{
  public class SearchViewModel : ViewModelBase
  {
    #region Constructor
    public SearchViewModel()
    {
      StartDate = DateTime.Now;
      EndDate = DateTime.Now.AddDays(14);
    }
    #endregion

    #region Private Variables
    private DateTime _StartDate;
    private DateTime _EndDate;
    #endregion

    #region Public Properties
    public DateTime StartDate
    {
      get { return _StartDate; }
      set
      {
        _StartDate = value;
        RaisePropertyChanged("StartDate");
      }
    }

    public DateTime EndDate
    {
      get { return _EndDate; }
      set
      {
        _EndDate = value;
        RaisePropertyChanged("EndDate");
      }
    }
    #endregion

    #region Search Method
    public void Search()
    {
      if (Validate())
      {
        // Do something else
      }
    }
    #endregion

    #region Validate Method
    public bool Validate()
    {
      // Use this to determine if the validation succeeds or not.
      IsMessageVisible = false;
      // Reset Message to Display
      MessageToDisplay = string.Empty;

      // Check Start Date versus End Date
      if (StartDate > EndDate)
      {
        MessageToDisplay = "Start Date Must Be Less Than End Date";
        IsMessageVisible = true;
      }

      return !IsMessageVisible;
    }
    #endregion
  }
}
