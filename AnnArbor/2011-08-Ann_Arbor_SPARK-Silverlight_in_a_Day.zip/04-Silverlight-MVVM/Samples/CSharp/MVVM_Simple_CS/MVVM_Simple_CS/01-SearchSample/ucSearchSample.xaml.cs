﻿using System.Windows;
using System.Windows.Controls;

namespace MVVM_Simple
{
  public partial class ucSearchSample : UserControl
  {
    SearchViewModel _ViewModel;

    public ucSearchSample()
    {
      InitializeComponent();

      // Grab instance of View Model from XAML
      _ViewModel = (SearchViewModel)this.Resources["viewModel"];
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Search();
    }
  }
}
