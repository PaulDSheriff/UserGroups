﻿using System.Windows;
using System.Windows.Controls;

namespace MVVM_Simple
{
  public partial class ucPersonSample : UserControl
  {
    PersonViewModel _ViewModel;

    public ucPersonSample()
    {
      InitializeComponent();

      // Grab instance of View Model from XAML
      _ViewModel = (PersonViewModel)this.Resources["viewModel"];
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Validate();
    }
  }
}
