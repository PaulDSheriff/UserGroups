﻿using Common.Library;

namespace MVVM_Simple
{
  public class PersonViewModel : ViewModelBase
  {
    #region Constructor
    public PersonViewModel()
    {
      DetailData = new Person();
    }
    #endregion

    #region Private Variables
    private Person _DetailData;
    #endregion

    #region Public Properties
    public Person DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion
    
    #region Validate Method
    public bool Validate()
    {
      IsMessageVisible = false;
      MessageToDisplay = string.Empty;

      if (DetailData.Validate() == false)
      {
        IsMessageVisible = true;
        MessageToDisplay = DetailData.BusinessRuleFailures.ToString();
      }

      return !IsMessageVisible;
    }
    #endregion
  }
}
