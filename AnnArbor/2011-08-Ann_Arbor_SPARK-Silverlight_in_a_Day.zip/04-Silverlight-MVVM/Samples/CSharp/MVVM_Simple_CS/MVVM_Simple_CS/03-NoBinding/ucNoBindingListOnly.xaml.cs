﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using MVVM_Simple.ProductServiceReference;

namespace MVVM_Simple
{
  public partial class ucNoBindingListOnly : UserControl
  {
    public ucNoBindingListOnly()
    {
      InitializeComponent();
    }

    
    #region Loaded Event
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();

      client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
      client.GetProductsAsync();
      client.CloseAsync();
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      lstData.DataContext = e.Result.DataCollection;
    }    
    #endregion

  }
}
