﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using Common.Library;
using MVVM_Simple.ProductServiceReference;

namespace MVVM_Simple
{
  public class ProductViewModel : ViewModelBase
  {
    bool _IsAddMode = false;

    #region Private UI Variables
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    private bool _IsListEnabled = true;
    private bool _IsDetailEnabled = false;
    private int _SelectedListIndex = -1;
    private string _Messages = string.Empty;

    private ObservableCollection<Product> _DataCollection;
    private Product _DetailData;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }

    public bool IsListEnabled
    {
      get { return _IsListEnabled; }
      set
      {
        if (_IsListEnabled != value)
        {
          _IsListEnabled = value;
          RaisePropertyChanged("IsListEnabled");
        }
      }
    }

    public int SelectedListIndex
    {
      get { return _SelectedListIndex; }
      set
      {
        if (_SelectedListIndex != value)
        {
          _SelectedListIndex = value;
          RaisePropertyChanged("SelectedListIndex");
        }
      }
    }

    public bool IsDetailEnabled
    {
      get { return _IsDetailEnabled; }
      set
      {
        if (_IsDetailEnabled != value)
        {
          _IsDetailEnabled = value;
          RaisePropertyChanged("IsDetailEnabled");
        }
      }
    }

    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        if (_IsAddMode != value)
        {
          _IsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }

    public string Messages
    {
      get { return _Messages; }
      set
      {
        if (_Messages != value)
        {
          _Messages = value;
          RaisePropertyChanged("Messages");
        }
      }
    }
    #endregion

    #region DataCollection Property
    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    public Product DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region SetNormalUIDisplay Method
    public void SetNormalUIDisplay()
    {
      IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
      IsListEnabled = true;
      IsDetailEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    public void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
      IsListEnabled = false;
      IsDetailEnabled = true;
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      try
      {
        ProductServicesClient client = new ProductServicesClient();

        client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
        client.GetProductsAsync();
        client.CloseAsync();
      }
      catch
      {
        // Ignore exception in design time
      }
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Success)
      {
        DataCollection = e.Result.DataCollection;
        SelectedListIndex = 0;
      }
      else
        Messages = e.Result.ErrorMessage;
    }
    #endregion

    #region AddRecord Method
    public void AddRecord()
    {
      SetEditUIDisplay();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      DetailData = new Product();
      DetailData.IntroductionDate = DateTime.Now;
      DetailData.IsDiscontinued = false;
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      SetNormalUIDisplay();

      IsAddMode = false;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData()
    {
      if (IsAddMode)
        InsertData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region Insert Data
    public void InsertData()
    {
      ProductServicesClient client = new ProductServicesClient();

      DataCollection.Add(DetailData);

      client.InsertCompleted += new EventHandler<InsertCompletedEventArgs>(client_InsertCompleted);
      // Save Data
      client.InsertAsync(DetailData);
      client.CloseAsync();
    }

    void client_InsertCompleted(object sender, InsertCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Exception)
        Messages = e.Result.ErrorMessage;
      else
        Messages = "Insert Successful";
    }
    #endregion

    #region Update Data
    public void UpdateData()
    {
      ProductServicesClient client = new ProductServicesClient();

      // Save Data
      client.UpdateCompleted += new EventHandler<UpdateCompletedEventArgs>(client_UpdateCompleted);
      client.UpdateAsync(DetailData);
      client.CloseAsync();
    }

    void client_UpdateCompleted(object sender, UpdateCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Exception)
        Messages = e.Result.ErrorMessage;
      else
        Messages = "Update Successful";
    }
    #endregion
  }
}
