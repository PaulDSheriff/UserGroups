﻿using System.Windows;
using System.Windows.Controls;

using MVVM_Simple.ProductServiceReference;

namespace MVVM_Simple
{
  public partial class ucSimpleMVVMListOnly : UserControl
  {
    ProductViewModelListOnly _ViewModel;

    public ucSimpleMVVMListOnly()
    {
      InitializeComponent();

      // Initialize the Product View Model Object
      _ViewModel = (ProductViewModelListOnly)this.Resources["viewModel"];
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Load Products
      _ViewModel.LoadAll();
    }
  }
}
