﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

using MVVM_Simple.ProductServiceReference;
using System.ComponentModel;

namespace MVVM_Simple
{
  public partial class ucBasicDataBinding : UserControl, INotifyPropertyChanged
  {
    Product _Entity;
    bool _IsAddMode = false;

    public ucBasicDataBinding()
    {
      InitializeComponent();

      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
    }

    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler handler = this.PropertyChanged;
      if (handler != null)
      {
        PropertyChangedEventArgs args = new PropertyChangedEventArgs(propertyName);

        // Raise the PropertyChanged event.
        handler(this, args);
      }
    }
    #endregion   

    #region Private UI Variables
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }
    #endregion

    #region Loaded Event
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      ProductServicesClient client = new ProductServicesClient();

      client.GetProductsCompleted += new EventHandler<GetProductsCompletedEventArgs>(client_GetProductsCompleted);
      client.GetProductsAsync();
      client.CloseAsync();
    }

    void client_GetProductsCompleted(object sender, GetProductsCompletedEventArgs e)
    {
      lstData.DataContext = e.Result.DataCollection;
    }
    #endregion

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      _Entity = (Product)lstData.SelectedItem;

      grdDetail.DataContext = _Entity;
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Create blank Object and Put UI into Add Mode
      // Put UI into Add Mode
      _IsAddMode = true;
      SetEditUIDisplay();
      _Entity = new Product();
      _Entity.IntroductionDate = DateTime.Now;

      grdDetail.DataContext = _Entity;
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      SetNormalUIDisplay();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
        AddData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region AddData Method
    private void AddData()
    {
      ProductServicesClient client = new ProductServicesClient();

      _Entity = (Product)grdDetail.DataContext;

      ObservableCollection<Product> coll = (ObservableCollection<Product>)lstData.DataContext;
      coll.Add(_Entity);

      client.InsertCompleted += new EventHandler<InsertCompletedEventArgs>(client_InsertCompleted);
      // Save Data
      client.InsertAsync(_Entity);
      client.CloseAsync();
    }

    void client_InsertCompleted(object sender, InsertCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Exception)
        tbMessages.Text = e.Result.ErrorMessage;
      else
        tbMessages.Text = "Save Successful";
    }
    #endregion

    #region UpdateData Method
    private void UpdateData()
    {
      ProductServicesClient client = new ProductServicesClient();
      _Entity = (Product)lstData.SelectedItem;

      // Save Data
      client.UpdateCompleted += new EventHandler<UpdateCompletedEventArgs>(client_UpdateCompleted);
      client.UpdateAsync(_Entity);
      client.CloseAsync();
    }

    void client_UpdateCompleted(object sender, UpdateCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Exception)
        tbMessages.Text = e.Result.ErrorMessage;
      else
        tbMessages.Text = "Save Successful";
    }
    #endregion

    #region SetNormalUIDisplay Method
    private void SetNormalUIDisplay()
    {
      _IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    private void SetEditUIDisplay()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
    }
    #endregion
  }
}
