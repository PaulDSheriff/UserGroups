﻿using System.Collections.Generic;

namespace Silverlight101
{
  public class Customers : List<Customer>
  {
  }

  public class Customer
  {
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string FullName
    {
      get { return FirstName + " " + LastName; }
    }
  }
}
