﻿using System.Windows;
using System.Windows.Controls;
using WPF.ListControls.EntityClasses;

namespace WPF_MVVM
{
  public partial class ProductMainControl : UserControl
  {
    public ProductMainControl()
    {
      InitializeComponent();

      // Initialize the Product View Model Object
      _viewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private ProductViewModel _viewModel;

    #region Loaded Event
    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Load Products explicitly, not using a constructor
      _viewModel.LoadAll();
    }
    #endregion

    #region Edit Click Event
    private void EditButton_Click(object sender, RoutedEventArgs e)
    {
      // Get Data Context from Button
      // So you can update the List Box SelectedValue
      _viewModel.Entity = (Product)((Button)sender).DataContext;
      _viewModel.SetModifyMode();
    }
    #endregion

    #region Add Click Event
    private void AddButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.AddRecord();
    }
    #endregion

    #region Cancel Click Event
    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.CancelEdit();

      // TODO: Write code to undo changes
    }
    #endregion

    #region Save Click Event
    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SaveData();
    }
    #endregion
  }
}
