﻿To run this sample you must install the AdventureWorksLT sample database that comes with SQL Server

You might have to change the connection string in the App.config file to point to the correct server and database

I've created a starting WPF architecture you can learn about by reading the blog post entitled "An Architecture for WPF Applications" located at https://bit.ly/2BxpK0P.
That blog also became a Pluralsight.com course you may view at https://bit.ly/2SjwTeb.
