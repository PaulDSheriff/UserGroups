﻿using System.Windows.Controls;

namespace WPF_MVVM
{
  public partial class SimpleBindingViewModelControl : UserControl
  {
    public SimpleBindingViewModelControl()
    {
      InitializeComponent();
    }
  }
}
