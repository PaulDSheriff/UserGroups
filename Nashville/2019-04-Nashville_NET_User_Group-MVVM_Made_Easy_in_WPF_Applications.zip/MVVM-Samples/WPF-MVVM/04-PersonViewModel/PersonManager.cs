﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Common.Library;

namespace WPF_MVVM.PersonViewModelSample
{
  public class PersonManager
  {
    public List<ValidationMessage> ValidationMessages { get; set; }
    
    #region Validate Method
    /// <summary>
    /// Validate Business Rules
    /// </summary>
    /// <returns>True if all rules pass, False otherwise</returns>
    public bool Validate(Person entityToValidate)
    {
      string propName = string.Empty;
      ValidationMessages = new List<ValidationMessage>();

      if (entityToValidate != null) {
        ValidationContext context = new ValidationContext(entityToValidate, serviceProvider: null, items: null);
        List<ValidationResult> results = new List<ValidationResult>();

        if (!Validator.TryValidateObject(entityToValidate, context, results, true)) {
          foreach (ValidationResult item in results) {
            if (((string[])item.MemberNames).Length > 0) {
              propName = ((string[])item.MemberNames)[0];
            }
            ValidationMessages.Add(new ValidationMessage { Message = item.ErrorMessage, PropertyName = propName });
          }
        }

        // Add additional business rules here
        if (!string.IsNullOrEmpty(entityToValidate.FirstName) && entityToValidate.FirstName.Trim().Length < 2) {
          ValidationMessages.Add(new ValidationMessage { PropertyName = "FirstName", Message = "First Name Must Be More Than 1 Character" });
        }
        if (!string.IsNullOrEmpty(entityToValidate.LastName) && entityToValidate.LastName.Trim().Length < 2) {
          ValidationMessages.Add(new ValidationMessage { PropertyName = "LastName", Message = "Last Name Must Be More Than 1 Character" });
        }
        if (entityToValidate.BirthDate < DateTime.Now.AddYears(-110)) {
          ValidationMessages.Add(new ValidationMessage { PropertyName = "BirthDate", Message = "Birth Date Must Be Greater Than " + DateTime.Now.AddYears(-110).ToShortDateString() });
          }
      }

      return (ValidationMessages.Count == 0);
    }
    #endregion
  }
}
