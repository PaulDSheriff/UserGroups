﻿using Common.Library;

namespace WPF_MVVM.PersonViewModelSample
{
  public class PersonViewModel : ViewModelBase
  {
    #region Constructor
    public PersonViewModel() : base() {
      Entity = new Person();
    }
    #endregion

    #region Private Variables
    private Person _Entity;
    #endregion
       
    #region Public Properties   
    public Person Entity
    {
      get { return _Entity; }
      set
      {
        _Entity = value;
        RaisePropertyChanged("Entity");
      }
    }
    #endregion

    #region Validate Method
    public bool Validate() {
      IsMessageVisible = false;
      Message = string.Empty;
      PersonManager mgr = new PersonManager();

      if (mgr.Validate(Entity) == false) {
        IsMessageVisible = true;
        ValidationMessages = mgr.ValidationMessages;
      }

      return !IsMessageVisible;
    }
    #endregion
  }
}