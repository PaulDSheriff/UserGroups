﻿using System.Windows.Controls;

namespace WPF_MVVM.UserControls
{
  public partial class ProductDetailControl : UserControl
  {
    public ProductDetailControl()
    {
      InitializeComponent();
    }
  }
}
