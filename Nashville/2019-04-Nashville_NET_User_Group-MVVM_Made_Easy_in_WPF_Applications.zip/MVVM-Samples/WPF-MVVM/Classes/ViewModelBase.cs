﻿using System.Collections.Generic;

namespace Common.Library
{
  public class ViewModelBase : CommonBase
  {
    private string _Message = string.Empty;
    private bool _IsMessageVisible = false;
    private List<ValidationMessage> _ValidationMessages;

    public string Message
    {
      get { return _Message; }
      set
      {
        _Message = value;
        RaisePropertyChanged("Message");
      }
    }

    public bool IsMessageVisible
    {
      get { return _IsMessageVisible; }
      set
      {
        _IsMessageVisible = value;
        RaisePropertyChanged("IsMessageVisible");
      }
    }

    public List<ValidationMessage> ValidationMessages
    {
      get { return _ValidationMessages; }
      set {
        _ValidationMessages = value;
        RaisePropertyChanged("ValidationMessages");
      }
    }

    #region AddValidationMessage Method
    public ValidationMessage AddValidationMessage(string propertyName, string message)
    {
      ValidationMessage ret = new ValidationMessage { PropertyName = propertyName, Message = message };

      ValidationMessages.Add(ret);

      return ret;
    }
    #endregion
  }
}
