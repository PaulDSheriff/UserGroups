﻿using System.Data.Entity;
using WPF.ListControls.EntityClasses;

namespace WPF.ListControls.Models
{
  public partial class AdventureWorksLTDbContext : DbContext
  {
    public AdventureWorksLTDbContext() : base("name=AdventureWorksLT")
    {
    }

    public virtual DbSet<Product> Products { get; set; }
  }
}
