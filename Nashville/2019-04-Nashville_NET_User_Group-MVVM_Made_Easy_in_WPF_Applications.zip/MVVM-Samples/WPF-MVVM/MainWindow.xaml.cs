﻿using System.Windows;

namespace WPF_MVVM
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }

    private void SimpleBinding_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new SimpleBindingControl());
    }

    private void SimpleBindingViewModel_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new SimpleBindingViewModelControl());
    }

    private void Search_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new SearchSampleControl());
    }

    private void Person_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new PersonSampleControl());
    }

    private void SimpleViewModelList_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ProductListControl());
    }

    private void SimpleViewModel_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new SimpleViewModelControl());
    }

    private void SimpleBaseClass_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ProductMainControl());
    }
  }
}
