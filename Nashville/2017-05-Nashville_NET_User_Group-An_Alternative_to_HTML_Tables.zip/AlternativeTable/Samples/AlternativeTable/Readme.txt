﻿Alternative Table Sample Project
--------------------------------
The samples in this project illustrate different ways to express tables so they display better on a mobile device such as a SmartPhone.
All samples use Bootstrap for styling and responsive UI.


Table Samples (\Views\Tables folder)
---------------------------------------------------------------------------------
Sample01 - A HTML table using a product name as hyperlink, and a "delete" button.
Sample02 - Reduce table to 2 columns. Product data in the first column. The second column has the delete button.
Sample03 - A HTML table using a "edit" and a "delete" button.
Sample04 - Reduce table to 2 columns. Product data in the first column. The second column has the actions.
Sample05 - Reduce table to 2 columns. Product data in the first column. Different styling for the Product name, and the name is a hyperlink. The second column contains just the "delete" button.


Alternative to Table Samples (\Views\TablesAlternatives folder)
---------------------------------------------------------------------------------
Sample01 - Use Bootstrap panel control. The title contains the product name, the body contains the product data, and the footer contains the actions to perform.
Sample02 - Use Boostrap 'list-group'. Two bootstrap columns are used to separate "label" and "data".
Sample03 - Display the product name in a label with additional styling.