﻿using System.Web.Mvc;

namespace AlternativeTable.Controllers
{
  public class TablesController : Controller
  {
    public ActionResult Index() {
      return View();
    }
    public ActionResult Sample01() {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      vm.Get();

      return View(vm);
    }

    public ActionResult Sample02() {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      vm.Get();

      return View(vm);
    }

    public ActionResult Sample03() {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      vm.Get();

      return View(vm);
    }

    public ActionResult Sample04() {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      vm.Get();

      return View(vm);
    }

    public ActionResult Sample05()
    {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      vm.Get();

      return View(vm);
    }
  }
}