﻿using System.Web.Mvc;

namespace AlternativeTable.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index() {
      return View();
    }
  }
}