﻿using System.Collections.Generic;

namespace AlternativeTable
{
  public class TrainingProductViewModel
  {
    public List<TrainingProduct> Products { get; set; } = new List<TrainingProduct>();

    public void Get() {
      TrainingProductManager mgr = new TrainingProductManager();

      Products = mgr.Get();
    }
  }
}
