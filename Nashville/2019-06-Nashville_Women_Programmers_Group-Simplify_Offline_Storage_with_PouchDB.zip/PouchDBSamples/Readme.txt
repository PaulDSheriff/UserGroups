NOTE: If you are using Windows, you must install the Windows Build Tools using the following command.
npm install --global --production windows-build-tools
