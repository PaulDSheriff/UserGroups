﻿let common = (function () {
  //* Constants
  const MSG_AREA = "#messageArea";
  const MSG_TEXT = "#message";
  const JSON_AREA = "#jsonArea";
  const JSON_TEXT = "#json";

  //* Private Functions
  function displayMessage(msg) {
    $(MSG_AREA).removeClass("hidden");
    $(MSG_TEXT).text(msg);
    console.log(msg);
  }

  function displayJSON(data) {
    $(JSON_AREA).removeClass("hidden");
    $(JSON_TEXT).text(JSON.stringify(data, undefined, 2));
  }

  function hideMessageAreas() {
    $(MSG_AREA).addClass("hidden");
    $(MSG_TEXT).text("");
    $(JSON_AREA).addClass("hidden");
    $(JSON_TEXT).text("");
  }

  //* Public Functions
  return {
    displayMessage: displayMessage,
    displayJSON: displayJSON,
    hideMessageAreas: hideMessageAreas
  }
})();