﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.IO;
using System.Xml;

namespace SPACombine
{
  public class SPACombineViewModel : CommonBase
  {
    #region Private Variables
    private const string NODE_MODULES = "node_modules";

    private ObservableCollection<ValidationRule> _ValidationMessages = new ObservableCollection<ValidationRule>();
    private bool _ErrorOccurred;
    private string _ProjectFolder = string.Empty;
    private string _SourceFolder = "src";
    private string _DestinationFolder = string.Empty;
    private string _StartPageName = "index.html";
    private string _ScriptDestinationFolder = @"scripts";
    private string _CSSDestinationFolder = @"content";
    private string _DontCopyFilesFromFolderAsString = "node_modules";
    private string _InsertJSAfter = "<!-- *** BEGIN: COMPONENT JS FILES HERE *** -->";
    private string _InsertStylesAfter = "<!-- *** BEGIN: COMPONENT STYLESHEET FILES HERE *** -->";
    private string _FoldersToCreateAsString = "content,scripts,images,node_modules";
    private string _FilesToIgnoreAsString = "Web.config,Web.Debug.config,Web.Release.config";
    private string _FileExtensionsToIgnoreAsString = ".csproj,.vbproj,.user";
    private string _FoldersToIgnoreAsString = "bin,obj,.vs,backup,packages,Properties";
    private string _IndexPageFileName = string.Empty;
    private string _FirstHalf = string.Empty;
    private string _SecondHalf = string.Empty;
    //private string _ContentArea = string.Empty;
    private string _ContentStartTag = "<contentarea";
    private string _ContentEndTag = "</contentarea>";
    private string _ContentDataPageStart = "data-page-start=\"";
    private string _ContentDataPagePath = "data-page-path=\"";
    private string _PartialPageTemplate = "<div id=\"{{FILENAME}}\" class=\"component hidden\">{{CRLF}}{{CONTENT}}{{CRLF}}</div>";
    private string[] DontCopyFilesFromFolder;
    private string[] FoldersToCreate;
    private string[] FilesToIgnore;
    private string[] FileExtensionsToIgnore;
    private string[] FoldersToIgnore;
    private List<string> JavaScriptToPutIntoIndexHtml = new List<string>();
    private List<string> CSSToPutIntoIndexHtml = new List<string>();
    private List<string> NodeModuleFoldersToCopy = new List<string>();
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set Messages
    /// </summary>
    public ObservableCollection<ValidationRule> ValidationMessages
    {
      get { return _ValidationMessages; }
      set {
        if (_ValidationMessages != value) {
          _ValidationMessages = value;
          RaisePropertyChanged("ValidationMessages");
        }
      }
    }

    /// <summary>
    /// Get/Set ErrorOccurred
    /// </summary>
    public bool ErrorOccurred
    {
      get { return _ErrorOccurred; }
      set {
        if (_ErrorOccurred != value) {
          _ErrorOccurred = value;
          RaisePropertyChanged("ErrorOccurred");
        }
      }
    }

    /// <summary>
    /// Get/Set SourceFolder
    /// </summary>
    public string SourceFolder
    {
      get { return _SourceFolder; }
      set {
        if (_SourceFolder != value) {
          _SourceFolder = value;
          RaisePropertyChanged("SourceFolder");
        }
      }
    }

    /// <summary>
    /// Get/Set ProjectFolder
    /// </summary>
    public string ProjectFolder
    {
      get { return _ProjectFolder; }
      set {
        if (_ProjectFolder != value) {
          _ProjectFolder = value;
          RaisePropertyChanged("ProjectFolder");
        }
      }
    }

    /// <summary>
    /// Get/Set DestinationFolder
    /// </summary>
    public string DestinationFolder
    {
      get { return _DestinationFolder; }
      set {
        if (_DestinationFolder != value) {
          _DestinationFolder = value;
          RaisePropertyChanged("DestinationFolder");
        }
      }
    }

    /// <summary>
    /// Get/Set StartPageName
    /// </summary>
    public string StartPageName
    {
      get { return _StartPageName; }
      set {
        if (_StartPageName != value) {
          _StartPageName = value;
          RaisePropertyChanged("StartPageName");
        }
      }
    }

    /// <summary>
    /// Get/Set ScriptDestinationFolder
    /// </summary>
    public string ScriptDestinationFolder
    {
      get { return _ScriptDestinationFolder; }
      set {
        if (_ScriptDestinationFolder != value) {
          _ScriptDestinationFolder = value;
          RaisePropertyChanged("ScriptDestinationFolder");
        }
      }
    }

    /// <summary>
    /// Get/Set CSSDestinationFolder
    /// </summary>
    public string CSSDestinationFolder
    {
      get { return _CSSDestinationFolder; }
      set {
        if (_CSSDestinationFolder != value) {
          _CSSDestinationFolder = value;
          RaisePropertyChanged("CSSDestinationFolder");
        }
      }
    }

    /// <summary>
    /// Get/Set DontCopyFiles
    /// </summary>
    public string DontCopyFilesFromFolderAsString
    {
      get { return _DontCopyFilesFromFolderAsString; }
      set {
        if (_DontCopyFilesFromFolderAsString != value) {
          _DontCopyFilesFromFolderAsString = value;
          RaisePropertyChanged("DontCopyFilesFromFolderAsString");
        }
      }
    }

    /// <summary>
    /// Get/Set InsertJSAfter
    /// </summary>
    public string InsertJSAfter
    {
      get { return _InsertJSAfter; }
      set {
        if (_InsertJSAfter != value) {
          _InsertJSAfter = value;
          RaisePropertyChanged("InsertJSAfter");
        }
      }
    }

    /// <summary>
    /// Get/Set InsertStylesAfter
    /// </summary>
    public string InsertStylesAfter
    {
      get { return _InsertStylesAfter; }
      set {
        if (_InsertStylesAfter != value) {
          _InsertStylesAfter = value;
          RaisePropertyChanged("InsertStylesAfter");
        }
      }
    }

    /// <summary>
    /// Get/Set FoldersToCreateAsString
    /// </summary>
    public string FoldersToCreateAsString
    {
      get { return _FoldersToCreateAsString; }
      set {
        if (_FoldersToCreateAsString != value) {
          _FoldersToCreateAsString = value;
          RaisePropertyChanged("FoldersToCreateAsString");
        }
      }
    }

    /// <summary>
    /// Get/Set FilesToIgnoreAsString
    /// </summary>
    public string FilesToIgnoreAsString
    {
      get { return _FilesToIgnoreAsString; }
      set {
        if (_FilesToIgnoreAsString != value) {
          _FilesToIgnoreAsString = value;
          RaisePropertyChanged("FilesToIgnoreAsString");
        }
      }
    }

    /// <summary>
    /// Get/Set FileExtensionsToIgnoreAsString
    /// </summary>
    public string FileExtensionsToIgnoreAsString
    {
      get { return _FileExtensionsToIgnoreAsString; }
      set {
        if (_FileExtensionsToIgnoreAsString != value) {
          _FileExtensionsToIgnoreAsString = value;
          RaisePropertyChanged("FileExtensionsToIgnoreAsString");
        }
      }
    }

    /// <summary>
    /// Get/Set FoldersToIgnoreAsString
    /// </summary>
    public string FoldersToIgnoreAsString
    {
      get { return _FoldersToIgnoreAsString; }
      set {
        if (_FoldersToIgnoreAsString != value) {
          _FoldersToIgnoreAsString = value;
          RaisePropertyChanged("FoldersToIgnoreAsString");
        }
      }
    }

    /// <summary>
    /// Get/Set IndexPageFileName
    /// </summary>
    public string IndexPageFileName
    {
      get { return _IndexPageFileName; }
      set {
        if (_IndexPageFileName != value) {
          _IndexPageFileName = value;
          RaisePropertyChanged("IndexPageFileName");
        }
      }
    }

    /// <summary>
    /// Get/Set FirstHalf
    /// </summary>
    public string FirstHalf
    {
      get { return _FirstHalf; }
      set {
        if (_FirstHalf != value) {
          _FirstHalf = value;
          RaisePropertyChanged("FirstHalf");
        }
      }
    }

    /// <summary>
    /// Get/Set SecondHalf
    /// </summary>
    public string SecondHalf
    {
      get { return _SecondHalf; }
      set {
        if (_SecondHalf != value) {
          _SecondHalf = value;
          RaisePropertyChanged("SecondHalf");
        }
      }
    }

    /// <summary>
    /// Get/Set ContentArea
    /// </summary>
    //public string ContentArea
    //{
    //  get { return _ContentArea; }
    //  set {
    //    if (_ContentArea != value) {
    //      _ContentArea = value;
    //      RaisePropertyChanged("ContentArea");
    //    }
    //  }
    //}

    /// <summary>
    /// Get/Set ContentStartTag
    /// </summary>
    public string ContentStartTag
    {
      get { return _ContentStartTag; }
      set {
        if (_ContentStartTag != value) {
          _ContentStartTag = value;
          RaisePropertyChanged("ContentStartTag");
        }
      }
    }

    /// <summary>
    /// Get/Set ContentEndTag
    /// </summary>
    public string ContentEndTag
    {
      get { return _ContentEndTag; }
      set {
        if (_ContentEndTag != value) {
          _ContentEndTag = value;
          RaisePropertyChanged("ContentEndTag");
        }
      }
    }

    /// <summary>
    /// Get/Set ContentDataPageStart
    /// </summary>
    public string ContentDataPageStart
    {
      get { return _ContentDataPageStart; }
      set {
        if (_ContentDataPageStart != value) {
          _ContentDataPageStart = value;
          RaisePropertyChanged("ContentDataPageStart");
        }
      }
    }

    /// <summary>
    /// Get/Set ContentDataPagePath
    /// </summary>
    public string ContentDataPagePath
    {
      get { return _ContentDataPagePath; }
      set {
        if (_ContentDataPagePath != value) {
          _ContentDataPagePath = value;
          RaisePropertyChanged("ContentDataPagePath");
        }
      }
    }

    /// <summary>
    /// Get/Set PartialPageTemplate
    /// </summary>
    public string PartialPageTemplate
    {
      get { return _PartialPageTemplate; }
      set {
        if (_PartialPageTemplate != value) {
          _PartialPageTemplate = value;
          RaisePropertyChanged("PartialPageTemplate");
        }
      }
    }
    #endregion

    public bool Process()
    {
      bool ret = false;

      // Clear error boolean
      ErrorOccurred = false;
      // Clear JS script array
      JavaScriptToPutIntoIndexHtml.Clear();
      // Clear CSS script array
      CSSToPutIntoIndexHtml.Clear();
      // Clear node_modules folders to copy
      NodeModuleFoldersToCopy.Clear();

      // Validate input
      if (Validate()) {
        // Save last data input into Config file
        SaveSettings();

        // Create new folder
        CreateNewFolder();

        if (!ErrorOccurred) {
          // Copy over standard folders
          CopyStandardFolders();
        }

        if (!ErrorOccurred) {
          // Copy JS Files from all sub-folders into \scripts folder
          CopyJSFilesIntoScriptDestinationFolder();
        }

        if (!ErrorOccurred) {
          // Copy CSS Files from all sub-folders into \content folder
          CopyCSSFilesIntoCSSDestinationFolder();
        }

        if (!ErrorOccurred) {
          // Combine HTML into index.html
          CombineAllHTML();
        }

        // Copy over folders needed from 'node_modules' folder
        if (!ErrorOccurred) {
          if (NodeModuleFoldersToCopy.Count > 0) {
            CopyNodeModulesIntoDestinationFolder();
          }
        }

        ret = !ErrorOccurred;
      }

      return ret;
    }

    #region Validate Method
    private bool Validate()
    {
      bool ret = true;

      ValidationMessages.Clear();

      // Fix up inputs
      ProjectFolder = ProjectFolder.Trim();
      SourceFolder = SourceFolder.Trim();
      DestinationFolder = DestinationFolder.Trim();
      StartPageName = StartPageName.Trim();
      ScriptDestinationFolder = ScriptDestinationFolder.Trim();
      CSSDestinationFolder = CSSDestinationFolder.Trim();
      DontCopyFilesFromFolderAsString = DontCopyFilesFromFolderAsString.Trim();
      // Validate Inputs
      if (string.IsNullOrEmpty(ProjectFolder)) {
        AddMessage("ProjectFolder", "Project Folder Location must be filled in.");
      }
      else {
        if (!Directory.Exists(ProjectFolder)) {
          AddMessage("ProjectFolder", "Project Folder Location does not exist.");
        }
        else {
          if (!ProjectFolder.EndsWith(@"\")) {
            ProjectFolder = ProjectFolder + @"\";
          }
        }
      }
      if (string.IsNullOrEmpty(SourceFolder)) {
        AddMessage("SourceFolder", "'src' Folder Location must be filled in.");
      }
      else {
        if (!Directory.Exists(ProjectFolder + SourceFolder)) {
          AddMessage("SourceFolder", "'src' Folder Location does not exist.");
        }
      }
      if (string.IsNullOrEmpty(DestinationFolder)) {
        AddMessage("DestinationFolder", "Destination Folder must be filled in.");
      }
      else {
        if (!DestinationFolder.EndsWith(@"\")) {
          DestinationFolder = DestinationFolder + @"\";
        }
      }
      if (SourceFolder.ToLower() == DestinationFolder.ToLower()) {
        AddMessage("SourceFolder", "index.html Folder Location must be different from the Destination Folder.");
      }
      if (string.IsNullOrEmpty(StartPageName)) {
        AddMessage("StartPageName", "Start Page Name must be filled in.");
      }
      else {
        if (!string.IsNullOrEmpty(SourceFolder)) {
          if (!File.Exists(ProjectFolder + SourceFolder + @"\" + StartPageName)) {
            AddMessage("StartPageName", "Start Page Name does not exist.");
          }
        }
      }
      if (string.IsNullOrEmpty(ScriptDestinationFolder)) {
        AddMessage("ScriptDestinationFolder", "Scripts Folder Name must be filled in.");
      }
      if (string.IsNullOrEmpty(CSSDestinationFolder)) {
        AddMessage("CSSDestinationFolder", "CSS Folder Name must be filled in.");
      }
      if (string.IsNullOrEmpty(InsertJSAfter)) {
        AddMessage("InsertJSAfter", "Insert JS After... must be filled in.");
      }
      if (string.IsNullOrEmpty(ContentStartTag)) {
        AddMessage("ContentStartTag", "Content Start Tag must be filled in.");
      }
      if (string.IsNullOrEmpty(ContentEndTag)) {
        AddMessage("ContentEndTag", "Content End Tag must be filled in.");
      }
      if (string.IsNullOrEmpty(ContentDataPageStart)) {
        AddMessage("ContentDataPageStart", "Content Data Page Start Attribute must be filled in.");
      }
      if (string.IsNullOrEmpty(ContentDataPagePath)) {
        AddMessage("ContentDataPagePath", "Content Data Page Path Attribute must be filled in.");
      }
      if (string.IsNullOrEmpty(PartialPageTemplate)) {
        AddMessage("PartialPageTemplate", "Partial Page Template must be filled in.");
      }

      // Did the validation pass?
      ret = (ValidationMessages.Count == 0);

      // Convert Strings into Arrays
      DontCopyFilesFromFolder = DontCopyFilesFromFolderAsString.Trim().Replace(" ", "").Split(",".ToCharArray());
      FoldersToCreate = FoldersToCreateAsString.Trim().Replace(" ", "").Split(",".ToCharArray());
      FilesToIgnore = FilesToIgnoreAsString.Trim().Replace(" ", "").Split(",".ToCharArray());
      FileExtensionsToIgnore = FileExtensionsToIgnoreAsString.Trim().Replace(" ", "").Split(",".ToCharArray());
      FoldersToIgnore = FoldersToIgnoreAsString.Trim().Replace(" ", "").Split(",".ToCharArray());

      return ret;
    }
    #endregion

    #region Folder/File Methods
    private void CreateNewFolder()
    {
      try {
        if (Directory.Exists(DestinationFolder)) {
          DeleteDirectory(DestinationFolder);
        }
        Directory.CreateDirectory(DestinationFolder);
      }
      catch (Exception ex) {
        AddErrorMessage("Error attempting to create new folder: " + DestinationFolder, ex);
      }
    }

    private void CopyStandardFolders()
    {
      string pathToCreate;
      for (int i = 0; i < FoldersToCreate.Length; i++) {
        pathToCreate = FoldersToCreate[i];
        try {
          if (!Directory.Exists(DestinationFolder + pathToCreate)) {
            Directory.CreateDirectory(DestinationFolder + pathToCreate);
          }

          // Copy files for standard folders
          CopyFilesForStandardFolders(ProjectFolder + pathToCreate, DestinationFolder + pathToCreate + @"\");
        }
        catch (Exception ex) {
          AddErrorMessage("CopyStandardFolders(): Error attempting to create directory: " + pathToCreate, ex);
        }
      }
    }

    private void CopyFilesForStandardFolders(string sourceFolder, string destinationFolder)
    {
      if (IsValidFolderFilesToCopy(destinationFolder)) {
        try {
          if (Directory.Exists(sourceFolder)) {
            foreach (string name in Directory.GetFiles(sourceFolder, "*.*", SearchOption.AllDirectories)) {
              FileInfo fi = new FileInfo(name);
              try {
                File.Copy(name, destinationFolder + fi.Name);
              }
              catch (Exception ex) {
                AddErrorMessage("CopyFolder(): Error attempting to copy " + name + " to " + destinationFolder + fi.Name, ex);
              }
            }
          }
        }
        catch (Exception ex) {
          AddErrorMessage("CopyFolder(): Error attempting to get all files in " + sourceFolder, ex);
        }
      }
    }

    private void CopyJSFilesIntoScriptDestinationFolder()
    {
      try {
        foreach (string name in Directory.GetFiles(ProjectFolder + SourceFolder, "*.js", SearchOption.AllDirectories)) {
          FileInfo fi = new FileInfo(name);
          try {
            if (IsValidFolderToCopyFrom(fi.Directory.FullName) && IsValidFileToCopy(name)) {
              File.Copy(name, DestinationFolder + ScriptDestinationFolder + @"\" + fi.Name);
            }
          }
          catch (Exception ex) {
            AddErrorMessage("CopyJSFilesIntoScriptDestinationFolder(): Error attempting to copy " + name + " to " + DestinationFolder + ScriptDestinationFolder + @"\" + fi.Name, ex);
          }
        }
      }
      catch (Exception ex) {
        AddErrorMessage("CopyJSFilesIntoScriptDestinationFolder(): Error attempting to get *.js files in " + SourceFolder, ex);
      }
    }

    private void CopyCSSFilesIntoCSSDestinationFolder()
    {
      try {
        foreach (string name in Directory.GetFiles(ProjectFolder + SourceFolder, "*.css", SearchOption.AllDirectories)) {
          FileInfo fi = new FileInfo(name);
          try {
            if (IsValidFolderToCopyFrom(fi.Directory.FullName) && IsValidFileToCopy(name)) {
              File.Copy(name, DestinationFolder + CSSDestinationFolder + @"\" + fi.Name);
            }
          }
          catch (Exception ex) {
            AddErrorMessage("CopyCSSFilesIntoCSSDestinationFolder(): Error attempting to copy " + name + " to " + DestinationFolder + CSSDestinationFolder + @"\" + fi.Name, ex);
          }
        }
      }
      catch (Exception ex) {
        AddErrorMessage("CopyCSSFilesIntoCSSDestinationFolder(): Error attempting to get *.css files in " + SourceFolder, ex);
      }
    }

    private void CopyNodeModulesIntoDestinationFolder()
    {
      string source;
      string dest;

      try {
        foreach (string name in NodeModuleFoldersToCopy) {
          source = ProjectFolder + NODE_MODULES + @"\" + name;
          dest = DestinationFolder + NODE_MODULES + @"\" + name;
          source = source.Replace("/", @"\");
          dest = dest.Replace("/", @"\");
          if (Directory.Exists(source)) {
            //Copy all the files & Replaces any files with the same name
            foreach (string newPath in Directory.GetFiles(source, "*.*", SearchOption.AllDirectories)) {
              if (!Directory.Exists(Path.GetDirectoryName(newPath).Replace(source, dest))) {
                Directory.CreateDirectory(Path.GetDirectoryName(newPath).Replace(source, dest));
              }

              File.Copy(newPath, newPath.Replace(source, dest), true);
            }
          }
        }
      }
      catch (Exception ex) {
        AddErrorMessage("CopyJSFilesIntoScriptDestinationFolder(): Error attempting to get *.js files in " + SourceFolder, ex);
      }
    }

    // Copy any files we have not already copied over: .html, .js and .css
    //private void CopyOtherFiles()
    //{
    //  bool okToCopy = true;
    //  string destPath = string.Empty;
    //  string destFile = string.Empty;

    //  foreach (string directory in Directory.GetDirectories(ProjectFolder + SourceFolder)) {
    //    // Don't copy from any folders marked as not to copy from
    //    if (IsValidFolderToCopyFrom(directory)) {
    //      if (IsValidFolderFilesToCopy(directory)) {
    //        foreach (string name in Directory.GetFiles(directory, "*.*", SearchOption.AllDirectories)) {
    //          okToCopy = true;
    //          FileInfo fi = new FileInfo(name);
    //          switch (fi.Extension.ToLower()) {
    //            case ".html":               
    //              okToCopy = false;
    //              break;
    //          }


    //          // Don't copy file names marked as not to copy
    //          if (!IsValidFileToCopy(name)) {
    //            okToCopy = false;
    //          }

    //          // Don't copy file extensions marked as not to copy
    //          if (!IsValidFileExtensionToCopy(fi.Extension)) {
    //            okToCopy = false;
    //          }

    //          // Figure out destination path
    //          destPath = string.Empty;
    //          if (fi.Directory.FullName.Length > (ProjectFolder + SourceFolder).Length) {
    //            destPath = fi.Directory.FullName.Substring((ProjectFolder + SourceFolder).Length) + @"\";
    //          }
    //          destFile = DestinationFolder + destPath + fi.Name;

    //          // Don't copy any file that has already been copied over
    //          if (File.Exists(destFile)) {
    //            okToCopy = false;
    //          }

    //          if (okToCopy) {
    //            try {
    //              File.Copy(name, destFile);
    //            }
    //            catch (Exception ex) {
    //              AddErrorMessage("CopyOtherFiles(): Error attempting to copy " + name + " to " + destFile, ex);
    //            }
    //          }
    //        }
    //      }
    //    }
    //  }
    //}
    #endregion

    #region HTML Methods
    private void CombineAllHTML()
    {
      string temp = string.Empty;

      // Extract pieces of the home page
      ExtractMainIndexPagePieces(ProjectFolder + SourceFolder);

      // Get first start page and insert into first half of the content
      // page.AddPartialPage(page.FirstPageFileName, true);     

      // Loop through all partial pages
      foreach (string name in Directory.GetFiles(ProjectFolder + SourceFolder, "*.html", SearchOption.AllDirectories)) {
        FileInfo fi = new FileInfo(name);
        if (fi.FullName.ToLower() != (ProjectFolder + SourceFolder + @"\index.html").ToLower() &&
            IsValidFolderToCopyFrom(fi.Directory.FullName) &&
            IsValidFileToCopy(name)) {
          // Look for JS scripts to add to index.html page
          LookForScriptTagsToAddToIndex(fi.FullName);

          // Look for Style sheets to add to index.html page
          LookForStyleSheetTagsToAddToIndex(fi.FullName);

          // Open file and add to index.html
          AddPartialPageToMainPage(fi.FullName);
        }
      }

      // Add Style Tags
      int cssLength = InsertStylesAfter.Length;
      temp = string.Empty;
      foreach (string script in CSSToPutIntoIndexHtml) {
        temp += script + Environment.NewLine;
      }
      FirstHalf = FirstHalf.Substring(0, FirstHalf.IndexOf(InsertStylesAfter) + cssLength) + Environment.NewLine + temp + FirstHalf.Substring(FirstHalf.IndexOf(InsertStylesAfter) + cssLength + 1);

      // Add JS tags
      int jsLength = InsertJSAfter.Length;
      temp = string.Empty;
      foreach (string script in JavaScriptToPutIntoIndexHtml) {
        temp += script + Environment.NewLine;
      }
      SecondHalf = SecondHalf.Substring(0, SecondHalf.IndexOf(InsertJSAfter) + jsLength) + Environment.NewLine + temp + SecondHalf.Substring(SecondHalf.IndexOf(InsertJSAfter) + jsLength + 1);

      // Write out new index.html file
      File.WriteAllText(DestinationFolder + @"\index.html", FirstHalf + SecondHalf);

      // Rewrite all tag folder destinations
      RewriteTagLocations(DestinationFolder + @"\index.html");
    }

    private void RewriteTagLocations(string fileName)
    {
      string[] lines = File.ReadAllLines(fileName);
      string line;
      string originalPath;
      string newPath;
      string tagName = string.Empty;

      for (int i = 0; i < lines.Length; i++) {
        tagName = string.Empty;
        line = lines[i].Trim().ToLower();
        if (line.StartsWith("<script ") & line.IndexOf("src=") >= 0) {
          tagName = "script";
        }
        else if (line.StartsWith("<link ") & line.IndexOf("href=") >= 0) {
          tagName = "link";
        }

        if (!string.IsNullOrEmpty(tagName)) {
          // Check for node_modules folder
          if (line.Contains(NODE_MODULES)) {
            tagName = NODE_MODULES;
          }
          // Get line within quotes
          originalPath = ExtractWithinQuote(line);
          // Strip out all but the last part
          if (originalPath.LastIndexOf("/") >= 0) {
            newPath = originalPath.Substring(originalPath.LastIndexOf("/"));
          }
          else {
            newPath = originalPath;
          }

          switch (tagName) {
            case "script":
              if (newPath.Contains("spa-common.js")) {
                newPath = ScriptDestinationFolder + "/spa-common-consolidated.js";
              }
              else {
                newPath = ScriptDestinationFolder + newPath;
              }
              break;

            case "link":
              newPath = CSSDestinationFolder + newPath;
              break;

            case NODE_MODULES:
              line = line.Replace("../" + NODE_MODULES, NODE_MODULES).Replace("./" + NODE_MODULES, NODE_MODULES).Replace("/" + NODE_MODULES, NODE_MODULES);
              // Get node_modules path
              NodeModuleFoldersToCopy.Add(GetNodeModulesPath(line));
              break;
          }
          lines[i] = line.Replace(originalPath, newPath);
        }
      }

      File.WriteAllLines(fileName, lines);
    }

    private void LookForScriptTagsToAddToIndex(string fileName)
    {
      string jsFile;
      string[] lines = File.ReadAllLines(fileName);

      for (int i = 0; i < lines.Length; i++) {
        jsFile = lines[i].Trim().ToLower();
        if (jsFile.StartsWith("<script ") & jsFile.IndexOf("src=") >= 0 & jsFile.IndexOf(".js") > 0) {
          if (!JavaScriptToPutIntoIndexHtml.Exists(j => j == jsFile)) {
            JavaScriptToPutIntoIndexHtml.Add(jsFile);
          }
        }
      }
    }

    private void LookForStyleSheetTagsToAddToIndex(string fileName)
    {
      string cssFile;
      string[] lines = File.ReadAllLines(fileName);

      for (int i = 0; i < lines.Length; i++) {
        cssFile = lines[i].Trim().ToLower();
        if (cssFile.StartsWith("<link ") & cssFile.IndexOf("href=") >= 0 & cssFile.IndexOf(".css") > 0) {
          if (!CSSToPutIntoIndexHtml.Exists(j => j == cssFile)) {
            CSSToPutIntoIndexHtml.Add(cssFile);
          }
        }
      }
    }
    #endregion

    #region Methods for working with Index page
    public void ExtractMainIndexPagePieces(string sourceFolder)
    {
      string allContent = string.Empty;
      string path = string.Empty;
      //int startPos = 0;
      //int endPos = 0;

      IndexPageFileName = sourceFolder + @"\index.html";

      allContent = File.ReadAllText(IndexPageFileName);
      if (allContent.IndexOf(ContentStartTag) >= 0) {
        FirstHalf = allContent.Substring(0, allContent.IndexOf(ContentStartTag) - 1) + Environment.NewLine;
        if (allContent.IndexOf(ContentEndTag) >= 0) {
          SecondHalf = allContent.Substring(allContent.IndexOf(ContentEndTag) + 16);
        }
        else {
          AddErrorMessage("ExtractMainIndexPagePieces(): Can't find Content End Tag (" + ContentEndTag + ") in index.html page", null);
        }
      }
      else {
        AddErrorMessage("ExtractMainIndexPagePieces(): Can't find Content Start Tag (" + ContentStartTag + ") in index.html page", null);
      }

      //if (!ErrorOccurred) {
      //  startPos = allContent.IndexOf(ContentStartTag) - 1;
      //  endPos = allContent.IndexOf(ContentEndTag) + ContentEndTag.Length;
      //  ContentArea = allContent.Substring(startPos, endPos - startPos).Trim();
      //}
    }
    #endregion

    #region Methods for working with partial pages
    public void AddPartialPageToMainPage(string fileName)
    {
      string[] lines;
      string content = string.Empty;
      string insertInto = string.Empty;

      insertInto = PreProcessPartialPageTemplate(fileName);

      lines = File.ReadAllLines(fileName);
      // Remove <script> tags
      content = RemoveScriptTagsFromPartialPages(lines);
      // Remove <link> tags
      content = RemoveStyleTagsFromPartialPages(lines);

      FirstHalf = FirstHalf + insertInto.Replace("{{CONTENT}}", content) + Environment.NewLine;
    }

    private string RemoveScriptTagsFromPartialPages(string[] lines)
    {
      for (int i = 0; i < lines.Length; i++) {
        if (lines[i].Trim().ToLower().StartsWith("<script") && lines[i].IndexOf("src=") >= 0) {
          lines[i] = "";
        }
      }

      return string.Join(Environment.NewLine, lines);
    }

    private string RemoveStyleTagsFromPartialPages(string[] lines)
    {
      string cssFile;

      for (int i = 0; i < lines.Length; i++) {
        cssFile = lines[i].Trim().ToLower();
        if (cssFile.StartsWith("<link") && cssFile.IndexOf("href=") >= 0 && cssFile.IndexOf(".css") > 0) {
          lines[i] = "";
        }
      }

      return string.Join(Environment.NewLine, lines);
    }

    private string PreProcessPartialPageTemplate(string fileName)
    {
      string ret = string.Empty;

      ret = PartialPageTemplate.Replace("{{CRLF}}", Environment.NewLine);
      ret = ret.Replace("{{FILENAME}}", Path.GetFileNameWithoutExtension(fileName).Replace(".", "_").Replace("-", "_"));

      return ret;
    }
    #endregion

    #region Helper Methods
    private string ExtractWithinQuote(string value)
    {
      int startPos = -1;
      int endPos = -1;
      startPos = value.IndexOf("\"");

      if (startPos >= 0) {
        endPos = value.IndexOf("\"", startPos + 1);
        if (endPos >= 0) {
          value = value.Substring(startPos + 1, endPos - startPos - 1);
        }
      }

      return value;
    }

    private string GetNodeModulesPath(string value)
    {
      int startPos = -1;
      int endPos1 = -1;
      int endPos2 = -1;
      value = ExtractWithinQuote(value);

      // Get first and second part of 'node_modules/*'
      startPos = value.IndexOf(NODE_MODULES) + NODE_MODULES.Length;
      if (startPos >= 0) {
        endPos1 = value.IndexOf("/", startPos + 1);
        if (endPos1 >= 0) {
          endPos2 = value.IndexOf("/", endPos1 + 1);
          if (endPos2 >= 0) {
            value = value.Substring(startPos + 1, endPos2 - startPos - 1);
          }
        }
      }
      // Check to make sure there is another directory under node_modules
      // Example: 'node_modules/mustache/mustache.min.js'
      if (value.Contains(".js") || value.Contains(".css")) {
        value = value.Replace("node_modules/", "");
        if (value.Contains("/")) {
          value = value.Substring(0, value.IndexOf("/"));
        }
      }

      return value;
    }

    public void AddMessage(string propertyName, string message)
    {
      ValidationMessages.Add(new ValidationRule(propertyName, message));
    }

    public void AddErrorMessage(string message, Exception ex)
    {
      ErrorOccurred = true;
      ValidationMessages.Add(new ValidationRule("ERROR", "** ERROR ** " + message + " - " + ex.ToString()));
    }

    private bool IsValidFolderToCopyFrom(string folderName)
    {
      bool ret = true;

      folderName = GetLastFolderName(folderName.ToLower());

      for (int i = 0; i < FoldersToIgnore.Length; i++) {
        if (folderName == FoldersToIgnore[i]) {
          ret = false;
          break;
        }
      }

      return ret;
    }

    private string GetLastFolderName(string pathName)
    {
      pathName = pathName.Trim();
      if (pathName.Contains(@"\")) {
        if (pathName.EndsWith(@"\")) {
          pathName = pathName.Substring(0, pathName.Length - 1);
        }
        pathName = pathName.Substring(pathName.LastIndexOf(@"\") + 1);
      }

      return pathName;
    }

    private bool IsValidFileToCopy(string fileName)
    {
      bool ret = true;
      FileInfo fi = new FileInfo(fileName);

      for (int i = 0; i < FilesToIgnore.Length; i++) {
        if (fi.Name.ToLower() == FilesToIgnore[i].ToLower()) {
          ret = false;
          break;
        }
      }

      return ret;
    }

    private bool IsValidFileExtensionToCopy(string extension)
    {
      bool ret = true;

      for (int i = 0; i < FileExtensionsToIgnore.Length; i++) {
        if (extension.ToLower() == FileExtensionsToIgnore[i].ToLower()) {
          ret = false;
          break;
        }
      }

      return ret;
    }

    private bool IsValidFolderFilesToCopy(string pathName)
    {
      bool ret = true;

      pathName = GetLastFolderName(pathName);

      for (int i = 0; i < DontCopyFilesFromFolder.Length; i++) {
        if (pathName.ToLower() == DontCopyFilesFromFolder[i].ToLower()) {
          ret = false;
          break;
        }
      }

      return ret;
    }

    public void DeleteDirectory(string folder)
    {
      string[] files = new string[] { };
      string[] dirs = new string[] { };
      string currentFile = string.Empty;

      try {
        files = Directory.GetFiles(folder);
      }
      catch (Exception ex) {
        AddErrorMessage("DeleteDirectory(): Error retrieving all files from: " + folder, ex);
      }

      if (!ErrorOccurred) {
        try {
          dirs = Directory.GetDirectories(folder);
        }
        catch (Exception ex) {
          AddErrorMessage("DeleteDirectory(): Error retrieving all folders from: " + folder, ex);
        }
      }

      if (!ErrorOccurred) {
        try {
          foreach (string file in files) {
            currentFile = file;
            File.SetAttributes(file, FileAttributes.Normal);
            File.Delete(file);
          }
        }
        catch (Exception ex) {
          AddErrorMessage("DeleteDirectory(): Error setting file attribute or deleting file: " + currentFile, ex);
        }
      }

      if (!ErrorOccurred) {
        // Recursive call, no need for error handling
        foreach (string dir in dirs) {
          if (ErrorOccurred) {
            break;
          }
          else {
            DeleteDirectory(dir);
          }
        }
      }

      if (!ErrorOccurred) {
        try {
          Directory.Delete(folder, false);
        }
        catch (Exception ex) {
          AddErrorMessage("DeleteDirectory(): Error deleting folder: " + folder, ex);
        }
      }
    }

    public void ReadAppSettings()
    {
      ProjectFolder = GetValue("ProjectFolder");
      SourceFolder = GetValue("SourceFolder");
      DestinationFolder = GetValue("DestinationFolder");
      StartPageName = GetValue("StartPageName");
      ScriptDestinationFolder = GetValue("ScriptDestinationFolder");
      CSSDestinationFolder = GetValue("CSSDestinationFolder");
      DontCopyFilesFromFolderAsString = GetValue("DontCopyFilesFromFolderAsString");
      InsertJSAfter = GetValue("InsertJSAfter");
      InsertStylesAfter = GetValue("InsertStylesAfter");
      FoldersToCreateAsString = GetValue("FoldersToCreateAsString");
      FilesToIgnoreAsString = GetValue("FilesToIgnoreAsString");
      FileExtensionsToIgnoreAsString = GetValue("FileExtensionsToIgnoreAsString");
      FoldersToIgnoreAsString = GetValue("FoldersToIgnoreAsString");
      ContentStartTag = GetValue("ContentStartTag");
      ContentEndTag = GetValue("ContentEndTag");
      ContentDataPageStart = GetValue("ContentDataPageStart");
      ContentDataPagePath = GetValue("ContentDataPagePath");
      PartialPageTemplate = GetValue("PartialPageTemplate");
    }

    private string GetValue(string key)
    {
      string ret = string.Empty;

      ret = ConfigurationManager.AppSettings[key];
      ret = ret.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&quot;", "\"");

      return ret;
    }

    private void SaveSettings()
    {
      XmlDocument xd = null;
      string ret = string.Empty;

      try {
        xd = new XmlDocument();
        xd.Load(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);

        UpdateSetting(xd, "ProjectFolder", ProjectFolder);
        UpdateSetting(xd, "SourceFolder", SourceFolder);
        UpdateSetting(xd, "DestinationFolder", DestinationFolder);
        UpdateSetting(xd, "StartPageName", StartPageName);
        UpdateSetting(xd, "ScriptDestinationFolder", ScriptDestinationFolder);
        UpdateSetting(xd, "CSSDestinationFolder", CSSDestinationFolder);
        UpdateSetting(xd, "DontCopyFilesFromFolderAsString", DontCopyFilesFromFolderAsString);
        UpdateSetting(xd, "InsertJSAfter", InsertJSAfter);
        UpdateSetting(xd, "InsertStylesAfter", InsertStylesAfter);
        UpdateSetting(xd, "FoldersToCreateAsString", FoldersToCreateAsString);
        UpdateSetting(xd, "FilesToIgnoreAsString", FilesToIgnoreAsString);
        UpdateSetting(xd, "FileExtensionsToIgnoreAsString", FileExtensionsToIgnoreAsString);
        UpdateSetting(xd, "FoldersToIgnoreAsString", FoldersToIgnoreAsString);
        UpdateSetting(xd, "ContentStartTag", ContentStartTag);
        UpdateSetting(xd, "ContentEndTag", ContentEndTag);
        UpdateSetting(xd, "ContentDataPageStart", ContentDataPageStart);
        UpdateSetting(xd, "ContentDataPagePath", ContentDataPagePath);
        UpdateSetting(xd, "PartialPageTemplate", PartialPageTemplate);

        xd.Save(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
      }
      catch (Exception ex) {
        AddMessage("", "Error saving to Config file - " + ex.ToString());
      }
    }

    private void UpdateSetting(XmlDocument xd, string key, string value)
    {
      XmlNode xn = null;
      string query;

      query = string.Format("/configuration/appSettings/add[@key='{0}']", key);
      xn = xd.SelectSingleNode(query);
      xn.Attributes["value"].Value = value;
    }
    #endregion
  }
}
