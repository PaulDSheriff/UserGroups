﻿using System;
using System.Runtime.Serialization;

namespace SPACombine
{
  /// <summary>
  /// This class holds the business rule failure message for a specific property.
  /// </summary>
  public class ValidationRule
  {
    #region Constructors
    public ValidationRule()
    {
    }

    public ValidationRule(string propertyName, string message)
    {
      PropertyName = propertyName;
      Message = message;
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the property name
    /// </summary>
    public string PropertyName { get; set; }

    /// <summary>
    /// Get/Set the business rule failure message
    /// </summary>
    public string Message { get; set; }
    #endregion
  }
}