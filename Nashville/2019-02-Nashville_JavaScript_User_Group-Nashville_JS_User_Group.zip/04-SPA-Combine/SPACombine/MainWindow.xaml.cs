﻿using System.Windows;

namespace SPACombine
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      _ViewModel = (SPACombineViewModel)this.Resources["viewModel"];
      _ViewModel.ReadAppSettings();
    }

    private SPACombineViewModel _ViewModel = null;

    private void ProcessButton_Click(object sender, RoutedEventArgs e)
    {
      if(_ViewModel.Process()) {
        _ViewModel.AddMessage("", "Completed");
      }
      else {
        MessageBox.Show("An error occurred, check messages list");
      }
    }
  }
}
