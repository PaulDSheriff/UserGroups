Demo 2
------------------
Modified spa-common.js -> _changePage() method
    // Remove any trailing data after the slash
    if (pageName.lastIndexOf("/") >= 0) {
      pageName = pageName.substring(0, pageName.lastIndexOf("/"));
    }

Added customer-detail.html and customer-detail.js
  Ability to get a single customer
Modified customer-list.html
  Added an "Edit" button
  