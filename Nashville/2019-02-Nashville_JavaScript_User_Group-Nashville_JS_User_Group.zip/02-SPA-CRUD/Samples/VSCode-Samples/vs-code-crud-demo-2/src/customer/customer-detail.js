'use strict';

$(document).ready(function () {
  customerDetailComponent.get();
});

/**
 * Customer Detail Component
 */
var customerDetailComponent = (function () {
  /**
   * Private Variables
   */
  var _entity;

  /**
   * Private Functions
   */
  function _get() {
    // Assuming the following url: #detail/n
    var id = window.location.hash;
    if (id.lastIndexOf("/") >= 0) {
      // Extract the ID portion from the hash
      id = id.substring(id.lastIndexOf("/") + 1);
    }
    else {
      id = null;
    }

    if (id) {
      // Get entity to display
      _getEntity(id);
    }
  }

  function _getEntity(id) {
    // Call service to get data
    customerService.get(id, function (data) {
      // Assign data to object
      _entity = data;
      // Display fields in HTML inputs
      _displayEntity(_entity);
    });
  }

  function _displayEntity(customer) {
    $("#customerID").val(customer.customerID);
    $("#title").val(customer.title);
    $("#firstName").val(customer.firstName);
    $("#middleName").val(customer.middleName);
    $("#lastName").val(customer.lastName);
    $("#companyName").val(customer.companyName);
    $("#salesPerson").val(customer.salesPerson);
    $("#emailAddress").val(customer.emailAddress);
    $("#phone").val(customer.phone);
  }

  function _goBack() {
    window.history.back(-1);
  }

  /**
   * Public Functions
   */
  return {
    "get": _get,
    "cancel": _goBack
  };
})();