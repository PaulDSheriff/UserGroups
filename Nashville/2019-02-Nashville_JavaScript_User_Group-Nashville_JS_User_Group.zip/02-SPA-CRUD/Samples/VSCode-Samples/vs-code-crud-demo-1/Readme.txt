Demo 1
------------------
Display a list of customers