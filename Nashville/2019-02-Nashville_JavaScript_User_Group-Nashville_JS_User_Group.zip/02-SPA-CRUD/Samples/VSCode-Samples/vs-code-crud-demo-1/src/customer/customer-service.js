'use strict';

/**
 * Customer Service Component
 */
var customerService = (function () {
  /**
   * Private variables
   */
  const API_URL = "http://localhost:5000/api/customer/";

  /**
   * Private functions
   */
  function _getAll(success, failure) {
    // Get list of data
    $.ajax({
      url: API_URL,
      type: "GET",
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  /**
   * Public functions
   */
  return {
    "getAll": _getAll
  };
})();