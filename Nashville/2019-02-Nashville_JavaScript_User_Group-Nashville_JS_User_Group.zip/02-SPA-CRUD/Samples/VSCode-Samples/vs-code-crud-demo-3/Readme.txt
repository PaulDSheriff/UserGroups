Demo 3
------------------
Modified customer-detail.js
  Added ability to update a customer
