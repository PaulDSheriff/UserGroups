'use strict';

$(document).ready(function () {
  customerDetailComponent.get();
});

/**
 * Customer Detail Component
 */
var customerDetailComponent = (function () {
  /**
   * Private Variables
   */
  var _entity;

  /**
   * Private Functions
   */
  function _get() {
    // Assuming the following url: #detail/n
    var id = window.location.hash;
    if (id.lastIndexOf("/") >= 0) {
      // Extract the ID portion from the hash
      id = id.substring(id.lastIndexOf("/") + 1);
    }
    else {
      id = null;
    }

    if (id) {
      // Get entity to display
      _getEntity(id);
    }
  }

  function _getEntity(id) {
    // Call service to get data
    customerService.get(id, function (data) {
      // Assign data to object
      _entity = data;
      // Display fields in HTML inputs
      _displayEntity(_entity);
    });
  }
 
  function _save() {
    // Gather data from HTML inputs
    _entity = _getEntityFromInput();

    if (_entity.customerID && Number(_entity.customerID) >= 0) {
      // Update data
      _updateEntity();
    }
  }

  function _updateEntity() {
    // Get data from HTML
    _entity = _getEntityFromInput();
    // Call customerService to update customer
    customerService.updateEntity(_entity.customerID, _entity, function (data) {
      // Return to list page
      _goBack();
    });
  }

  function _getEntityFromInput() {
    return {
      "customerID": $("#customerID").val(),
      "title": $("#title").val(),
      "firstName": $("#firstName").val(),
      "middleName": $("#middleName").val(),
      "lastName": $("#lastName").val(),
      "companyName": $("#companyName").val(),
      "salesPerson": $("#salesPerson").val(),
      "emailAddress": $("#emailAddress").val(),
      "phone": $("#phone").val()
    }
  }
  
  function _displayEntity(customer) {
    $("#customerID").val(customer.customerID);
    $("#title").val(customer.title);
    $("#firstName").val(customer.firstName);
    $("#middleName").val(customer.middleName);
    $("#lastName").val(customer.lastName);
    $("#companyName").val(customer.companyName);
    $("#salesPerson").val(customer.salesPerson);
    $("#emailAddress").val(customer.emailAddress);
    $("#phone").val(customer.phone);
  }
  
  function _goBack() {
    window.history.back(-1);
  }

  /**
   * Public Functions
   */
  return {
    "get": _get,
    "save": _save,
    "cancel": _goBack
  };
})();