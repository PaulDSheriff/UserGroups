Demo 4
------------------
Modified customer-list.html
  Added "Add" button
Modified customer-detail.js
  Added ability add a customer
