'use strict';

$(document).ready(function () {
  customerListComponent.get();
});

/**
 * Customer List Component
 */
var customerListComponent = (function () {
  /**
   * Private Variables
   */
  var _dataList = [];

  /**
   * Private Functions
   */
  function _get() {
    // Call Service to get list of data
    customerService.getAll(function (data) {
      // Assign data to array
      _dataList = data;
      // Create HTML table
      _renderData("#dataTmpl", "#customers tbody");
    });
  }

  function _renderData(templateId, insertInto) {
    // Get template from script element
    var template = $(templateId).html();
    // Call Mustache passing in the template and the
    // object with collection of data to display
    var html = Mustache.to_html(template, customerListComponent);
    // Insert the rendered HTML into the DOM
    $(insertInto).html(html);
  }

  function _deleteEntity(id) {
    customerService.deleteEntity(id, function (data) {
      // Refresh the customer list
      _get();
    });
  }

  /**
  * Public Functions
  */
  return {
    "get": _get,
    "deleteEntity": function (id) {
      if (confirm("Delete this customer?")) {
        _deleteEntity(id);
      }
    },
    "dataList": function () {
      return _dataList;
    }
  };
})();
