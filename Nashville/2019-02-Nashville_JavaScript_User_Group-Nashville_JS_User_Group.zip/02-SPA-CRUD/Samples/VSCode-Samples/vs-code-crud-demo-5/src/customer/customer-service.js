'use strict';

/**
 * Customer Service Component
 */
var customerService = (function () {
  /**
   * Private variables
   */
  const API_URL = "http://localhost:5000/api/customer/";

  /**
   * Private functions
   */
  function _getAll(success, failure) {
    // Get list of data
    $.ajax({
      url: API_URL,
      type: "GET",
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  function _get(id, success, failure) {
    // Get a single row of data
    $.ajax({
      url: API_URL + id,
      type: "GET",
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  function _updateEntity(id, entity, success, failure) {
    // Update single row of data
    $.ajax({
      url: API_URL + id,
      type: "PUT",
      data: JSON.stringify(entity),
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  function _addEntity(entity, success, failure) {
    // Add a single row of data
    $.ajax({
      url: API_URL,
      type: "POST",
      data: JSON.stringify(entity),
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  function _deleteEntity(id, success, failure) {
    // Delete a single row of data
    $.ajax({
      url: API_URL + id,
      type: "DELETE",
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  /**
   * Public functions
   */
  return {
    "getAll": _getAll,
    "get": _get,
    "updateEntity": _updateEntity,
    "addEntity": _addEntity,
    "deleteEntity": _deleteEntity
  };
})();