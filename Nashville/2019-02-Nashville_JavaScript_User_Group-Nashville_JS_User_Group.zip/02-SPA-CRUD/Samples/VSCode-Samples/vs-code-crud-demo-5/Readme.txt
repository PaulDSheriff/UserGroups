Demo 5
------------------

Modified customer-detail.js
  Added ability delete a customer
