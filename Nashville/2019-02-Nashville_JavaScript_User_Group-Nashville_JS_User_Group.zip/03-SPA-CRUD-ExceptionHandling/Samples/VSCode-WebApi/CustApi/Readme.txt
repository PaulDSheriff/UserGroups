Added additional Validation Attributes to Customer.Customer
  [EmailAddress], [Phone]

Added a ValidateModelAttribute class to send a 400 if ModelState.IsValid = false
