﻿'use strict';

$(document).ready(function () {
  spaController.init();
});

/**
 * SPA Component
 */
var spaController = (function () {
  var _lastId = "";

  /**
   * Private functions
   */
  function _init() {
    // Is there any start page to load
    var start = "#home";

    // Load partial start page
    _changePage(start);

    // Setup event to respond to changes in hash
    window.onhashchange = function () {
      _changePage(window.location.hash);
    }
  }

  function _changePage(hashValue) {
    // Hide last page
    if (_lastId) {
      $(_lastId).addClass('hidden');
    }
    
    // Set last page
    _lastId = hashValue;

    // Remove # to create the div to unhide
    var div = hashValue.substr(1);

    // Remove any trailing data after the slash
    if (div.lastIndexOf("/") >= 0) {
      div = div.substring(0, div.lastIndexOf("/"));
    }

    // Make new page visible
    $(hashValue).removeClass('hidden');

    // Set document title
    window.document.title = $("a[href='" + hashValue + "']").attr("title");

    // Reset menu focus
    _resetMenu(hashValue);
  }

  function _resetMenu(hashValue) {
    // Set focus to menu that matches current page
    $("a[href='" + hashValue + "']").focus();
    // Remove outline around anchor when setting focus
    $("a[href='" + hashValue + "']").css("outline", "0");
  }

  /**
   * Public functions
   */
  return {
    "changePage": _changePage,
    "init": _init
  };
})();