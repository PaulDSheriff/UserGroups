Demo
------------------
Added common-component.js file
  Moved renderData into this component
  Create a callApi method for all Ajax() calls
Added error-message-service.js file
  Added handleException() method to handle all exceptions
customer-detail.js
  Added _errorObject variable
  Added _renderData function
  Added handleValidationErrors function
  Added error handling in addEntity() and updateEntity() functions
customer-detail.html
  Added <script> template for validation errors
  Added <div id="valErrorArea"> to display validation errors
Added contact.js and home.js in order to clear errors
index.html
	Added error HTML template