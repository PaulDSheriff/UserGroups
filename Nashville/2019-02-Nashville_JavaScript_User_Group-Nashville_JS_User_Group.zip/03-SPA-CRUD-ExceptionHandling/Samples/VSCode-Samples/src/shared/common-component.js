'use strict';

/**
 * Common Services Component
 */
var commonComponent = (function () {
  /**
   * Private variables
   */
  var _settings = {
    debug: true,
    apiUrl: 'http://localhost:5000/api/'
  };

  /**
   * Private functions
   */
  function _renderData(templateId, insertInto, component) {
    // Get template from script element
    var template = $(templateId).html();
    // Call Mustache passing in the template and the
    // object with collection of data to display
    var html = Mustache.to_html(template, component);
    // Insert the rendered HTML into the DOM
    $(insertInto).html(html);
  }

  function _callApi(url, type, data, success, failure) {
    // Update single row of data
    $.ajax({
      url: url,
      type: type,
      data: JSON.stringify(data),
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.error("Error Occurred: " + JSON.stringify(error));
        }
      });
  }

  function _getConfigSettings() {
    return _settings;
  }

  /**
   * Public functions
   */
  return {
    "renderData": _renderData,
    "callApi" : _callApi,
    "settings" : _getConfigSettings
  };
})();