'use strict';

$(document).ready(function () {
  customerListComponent.get();
});

/**
 * Customer List Component
 */
var customerListComponent = (function () {
  /**
   * Private Variables
   */
  var _dataList = [];
  var _errorObject = {};

  /**
   * Private Functions
   */
  function _get() {    
    // Call service to get list of data
    customerService.getAll(
      function (data) {
        // Hide error objects
        errorMessageService.hideErrorAreas();
        // Display HTML table
        $("#customerListArea").removeClass("hidden");
        // Assign data to array
        _dataList = data;
        // Create HTML table
        commonComponent.renderData("#dataTmpl", "#customers tbody", customerListComponent);
      },
      function (error) {
        // Try to get local data
        
        // Build error object
        _errorObject = errorMessageService.buildErrorObject(error);
        // Display error information
        errorMessageService.displayErrors(customerListComponent);
      }
    );
  }

  function _deleteEntity(id) {
    customerService.deleteEntity(id, 
      function (data) {
        // Hide error objects
        errorMessageService.hideErrorAreas();
        // Refresh the list
        _get();
      },
      function (error) {
        // Build error object
        _errorObject = errorMessageService.buildErrorObject(error);
        // Display error information
        errorMessageService.displayErrors(customerListComponent);
      }
    );
  }

  /**
  * Public Functions
  */
  return {
    "get": _get,
    "deleteEntity": function (id) {
      if (confirm("Delete this customer?")) {
        _deleteEntity(id);
      }
    },
    "salaryAsCurrency": function () {
      return new Number(this.salary)
        .toLocaleString('en-US', { style: 'currency', currency: 'USD' });
    },
    "dataList": function () {
      return _dataList;
    },
    "errorList": function () {
      return _errorObject.messages;
    }
  };
})();
