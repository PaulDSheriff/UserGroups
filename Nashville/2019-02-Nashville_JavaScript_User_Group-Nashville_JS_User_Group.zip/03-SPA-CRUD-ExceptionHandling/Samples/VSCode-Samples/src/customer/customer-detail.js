'use strict';

$(document).ready(function () {
  customerDetailComponent.get();
});

/**
 * Customer Detail Component
 */
var customerDetailComponent = (function () {
  /**
   * Private Variables
   */
  var _entity = {};
  var _errorObject = {};

  /**
   * Private Functions
   */
  function _get() {
    // Assuming the following url: #detail/n
    var id = window.location.hash;
    // Extract the ID portion from the hash
    id = id.lastIndexOf("/") >= 0 ? id.substring(id.lastIndexOf("/") + 1) : null;

    if (id) {
      // Get entity to display
      _getEntity(id);
    }
    else {
      // Create a blank entity for adding
      _newEntity();
    }
  }

  function _getEntity(id) {
    // Call service to get data
    customerService.get(id, function (data) {
      // Hide error objects
      errorMessageService.hideErrorAreas();
      // Display detail area
      $("#customerDetailArea").removeClass("hidden");
      // Assign data to object
      _entity = data;
      // Display fields in HTML inputs
      _displayEntity(_entity);
    },
      function (error) {
        _handleError(error);
      }
    );
  }

  function _newEntity() {
    // Display detail area
    $("#customerDetailArea").removeClass("hidden");

    // Create new entity and display on screen
    _displayEntity({
      "title": "",
      "firstName": "",
      "middleName": "",
      "lastName": "",
      "companyName": "",
      "salesPerson": "",
      "emailAddress": "@netinc.com",
      "phone": ""
    });
  }

  function _save() {
    // Hide error objects
    errorMessageService.hideErrorAreas();

    if (_entity.customerID) {
      // Get data from HTML
      _entity = _getEntityFromInput(true);

      // Update data
      _updateEntity();
    }
    else {
      // Get data from HTML
      _entity = _getEntityFromInput(false);

      // Add data
      _addEntity();
    }
  }

  function _updateEntity() {
    // Call service to update entity
    customerService.updateEntity(_entity.customerID, _entity,
      function (data) {
        // Return to list page
        _goBack();
      },
      function (error) {
        _handleError(error);
      }
    );
  }

  function _addEntity() {
    // Call service to add entity
    customerService.addEntity(_entity,
      function (data) {
        // Return to list page
        _goBack();
      },
      function (error) {
        _handleError(error);
      }
    );
  }

  function _handleError(error) {    
    // Build error object
    _errorObject = errorMessageService.buildErrorObject(error);
    //console.log(JSON.stringify(_errorObject));
    if (_errorObject.isValidationError) {
      // Display validation errors
      errorMessageService.displayValidationErrors(customerDetailComponent, customerDetailValArea, customerDetailValTmpl, customerDetailValErrors);
    }
    else {
      // Display error information
      errorMessageService.displayErrors(customerDetailComponent);
    }
  }

  function _getEntityFromInput(getPK) {
    var ret = {
      "title": $("#title").val(),
      "firstName": $("#firstName").val(),
      "middleName": $("#middleName").val(),
      "lastName": $("#lastName").val(),
      "companyName": $("#companyName").val(),
      "salesPerson": $("#salesPerson").val(),
      "emailAddress": $("#emailAddress").val(),
      "phone": $("#phone").val()
    }
    if (getPK) {
      // Only add PK when performing an update
      ret.customerID = $("#customerID").val();
    }

    return ret;
  }

  function _displayEntity(customer) {
    $("#customerID").val(customer.customerID);
    $("#title").val(customer.title);
    $("#firstName").val(customer.firstName);
    $("#middleName").val(customer.middleName);
    $("#lastName").val(customer.lastName);
    $("#companyName").val(customer.companyName);
    $("#salesPerson").val(customer.salesPerson);
    $("#emailAddress").val(customer.emailAddress);
    $("#phone").val(customer.phone);
  }

  function _goBack() {
    window.history.back(-1);
  }

  /**
   * Public Functions
   */
  return {
    "get": _get,
    "save": _save,
    "cancel": _goBack,
    "valErrorList": function () {
      return _errorObject.messages;
    },
    "errorList": function () {
      return _errorObject.messages;
    }
  };
})();