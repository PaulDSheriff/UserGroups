'use strict';

$(document).ready(function () {
  aboutComponent.hideErrorAreas();
});

/**
 * About Component
 */
var aboutComponent = (function () {
  /**
   * Private Functions
   */
  function _hideErrorAreas() {
    // Hide error objects
    errorMessageService.hideErrorAreas();
  }

  function _hello() {
    alert("Hello from About Page");
  }

  /**
  * Public Functions
  */
  return {
    "hideErrorAreas": _hideErrorAreas,
    "hello": _hello
  };
})();
