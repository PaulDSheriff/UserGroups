'use strict';

$(document).ready(function () {
  contactComponent.hideErrorAreas();
});

/**
 * Contact Component
 */
var contactComponent = (function () {
  /**
   * Private Functions
   */
  function _hideErrorAreas() {
        // Hide error objects
        errorMessageService.hideErrorAreas();
  }

  /**
  * Public Functions
  */
  return {
    "hideErrorAreas": _hideErrorAreas
  };
})();
