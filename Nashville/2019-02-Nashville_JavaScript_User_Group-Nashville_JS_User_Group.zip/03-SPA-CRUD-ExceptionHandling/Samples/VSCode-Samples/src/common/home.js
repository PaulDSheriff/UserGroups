'use strict';

$(document).ready(function () {
  homeComponent.hideErrorAreas();
});

/**
 * Home Component
 */
var homeComponent = (function () {
  /**
   * Private Functions
   */
  function _hideErrorAreas() {
        // Hide error objects
        errorMessageService.hideErrorAreas();
  }

  /**
  * Public Functions
  */
  return {
    "hideErrorAreas": _hideErrorAreas
  };
})();
