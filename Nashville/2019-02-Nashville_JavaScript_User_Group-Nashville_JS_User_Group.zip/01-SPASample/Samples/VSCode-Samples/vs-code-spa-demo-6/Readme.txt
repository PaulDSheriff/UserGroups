Move pages to different folder
Add data- attribute to document the folder name