This sample adds custom CSS and JS to a single page
