This sample shows how to move from one page to another by changing the location.hash
