'use strict';

$(document).ready(function () {
  // Trigger home page
  window.location.replace("#home");

  // Respond to changes in hash
  window.onhashchange = function () {
    if (window.location.hash) {
      // Remove # to create the page file name
      let pageName = window.location.hash.substr(1);
  
      // Use jQuery to retrieve partial page
      $("contentarea").load(pageName + ".html",
        function (response, status, xhr) {
          if (status == "error") {
            console.error("Can't retrieve partial page: '"
              + pageName + ".html' - " + JSON.stringify(xhr));
          }
        }
      );
    }
  }
});