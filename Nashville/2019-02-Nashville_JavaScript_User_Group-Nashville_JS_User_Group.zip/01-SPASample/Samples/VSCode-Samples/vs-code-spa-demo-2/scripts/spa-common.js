'use strict';

$(document).ready(function () {
  // Trigger home page
  changePage("contentarea", "#home");

  // Respond to changes in hash
  window.onhashchange = function () {
    changePage("contentarea", window.location.hash);
  }
});

function loadPage(contentArea, pageName) {
  // Use jQuery to retrieve partial page
  $(contentArea).load(pageName + ".html", function (response, status, xhr) {
    if (status == "error") {
      console.error("Can't retrieve partial page: '"
        + pageName + ".html' - " + JSON.stringify(xhr));
    }
  });
}

function changePage(contentArea, hashValue) {
  // Remove # to create the page file name
  let pageName = hashValue.substr(1);
  // Load the partial HTML page
  loadPage(contentArea, pageName);
}
