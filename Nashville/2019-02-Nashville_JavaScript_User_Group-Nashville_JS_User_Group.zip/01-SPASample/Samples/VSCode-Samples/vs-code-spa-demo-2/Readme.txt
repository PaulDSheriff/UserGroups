This sample refactors the spa-common.js to break functionality into separate functions
