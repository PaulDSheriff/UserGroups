Create a closure around the SPA functions
