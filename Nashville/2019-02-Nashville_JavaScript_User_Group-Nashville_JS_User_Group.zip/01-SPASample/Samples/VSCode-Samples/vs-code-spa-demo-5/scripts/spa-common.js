'use strict';

$(document).ready(function () {
  // Trigger home page
  spaController.changePage("contentarea", "#home");

  // Respond to changes in hash
  window.onhashchange = function () {
    spaController.changePage("contentarea", window.location.hash);
  }
});

/**
 * SPA Component
 */
let spaController = (function () {
  /**
   * Private functions
   */
  function _loadPage(contentArea, pageName) {
    // Use jQuery to retrieve partial page
    $(contentArea).load(pageName + ".html", function (response, status, xhr) {
      if (status == "error") {
        console.error("Can't retrieve partial page: '"
          + pageName + ".html' - " + JSON.stringify(xhr));
      }
    });
  }

  function _changePage(contentArea, hashValue) {
    // Remove # to create the page file name
    let pageName = hashValue.substr(1);
    // Load the partial HTML page
    _loadPage(contentArea, pageName);

    // Set document title
    window.document.title = $("a[href='" + hashValue + "']").attr("title");
  }

  /**
   * Public functions
   */
  return {
    "loadPage": _loadPage,
    "changePage": _changePage
  };
})();