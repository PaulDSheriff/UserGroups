﻿using System.IO;
using System.Web;
using System.Web.Mvc;
using FileUploadSamples.Models;

namespace FileUploadSamples
{
  public class AppController : Controller
  {
    public void SetFileUploadInfo(HttpPostedFileBase fileToUpload, FileUpload file)
    {
      if (fileToUpload != null && fileToUpload.ContentLength > 0) {
        // Get the uploaded file
        using (MemoryStream ms = new MemoryStream()) {
          fileToUpload.InputStream.CopyTo(ms);
          file.OriginalDocument = ms.ToArray();
        }

        // Fill in other file information
        file.ContentLength = fileToUpload.ContentLength;
        file.ContentType = fileToUpload.ContentType;
        file.FilePath = Path.GetDirectoryName(fileToUpload.FileName);
        file.FileName = Path.GetFileName(fileToUpload.FileName);
      }
    }
  }
}