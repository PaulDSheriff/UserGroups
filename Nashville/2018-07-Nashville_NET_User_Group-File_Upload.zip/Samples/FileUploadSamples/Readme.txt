﻿Before Using This Sample
------------------------
Open the Web.config file and modify the path to the .mdf file located in the App_Data folder in this project.
Or, create a SQL Server database and use the .sql file located in the \SqlScripts folder and modify the connection string


Samples
------------------------
UploadSamples\Sample01.cshmtl - Normal File Upload
UploadSamples\Sample02.cshmtl - Apply styling to file upload control
UploadSamples\Sample03.cshmtl - Use a view model, use method to gather file info properties
UploadSamples\Sample04.cshmtl - Create a thumbnail

FileUpload\FileUploadList.cshtml - Display list of files from SQL Server
FileUpload\FileUploadDetail.cshtml
  - Insert file data into SQL Server
  - Create a thumbnail of an image
  - Display image retrieved from SQL Server


Notes
--------------------------
'name' attribute must be set on file upload input
  The 'name' attribute must match the parameter name on the controller method
Must add the attribute to the form when uploading input
  enctype="multipart/form-data"
