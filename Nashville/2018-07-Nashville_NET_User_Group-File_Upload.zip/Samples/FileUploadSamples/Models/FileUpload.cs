using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FileUploadSamples.Models
{
  [Table("FileUpload")]
  public partial class FileUpload
  {
    [Key]
    public int DocumentId { get; set; }

    [Required]
    [StringLength(100)]
    public string DocTitle { get; set; }

    [StringLength(500)]
    public string DocDescription { get; set; }

    [StringLength(500)]
    public string FilePath { get; set; }

    [StringLength(100)]
    public string FileName { get; set; }

    public byte[] OriginalDocument { get; set; }

    public byte[] Thumbnail { get; set; }

    public int? ContentLength { get; set; }

    [StringLength(100)]
    public string ContentType { get; set; }

    [NotMapped]
    public object ThumbUrl
    {
      get {
        if (Thumbnail != null) {
          return "data:image/jpg;base64," + Convert.ToBase64String((byte[])Thumbnail);
        }
        else {
          return null;
        }
      }
      set { var tmp = value; }
    }
  }
}
