using System.Data.Entity;

namespace FileUploadSamples.Models
{
  public partial class DocumentDB : DbContext
  {
    public DocumentDB() : base("name=DocumentDB") { }

    public virtual DbSet<FileUpload> FileUploads { get; set; }
  }
}
