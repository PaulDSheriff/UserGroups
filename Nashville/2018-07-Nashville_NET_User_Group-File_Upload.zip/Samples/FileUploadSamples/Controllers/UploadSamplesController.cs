﻿using System.IO;
using System.Web;
using System.Web.Mvc;
using FileUploadSamples.Models;
using FileUploadSamples.ViewModels;

namespace FileUploadSamples.Controllers
{
  public class UploadSamplesController : AppController
  {
    public ActionResult Sample01()
    {
      return View();
    }

    [HttpPost]
    public ActionResult Sample01(HttpPostedFileBase fileToUpload)  // NOTE: the parameter name must match the 'id' in the HTML
    {
      byte[] doc;
      string filePath;
      string fileName;
      int contentLength;
      string contentType;

      if (fileToUpload != null && fileToUpload.ContentLength > 0) {
        // Get the uploaded file
        using (MemoryStream ms = new MemoryStream()) {
          fileToUpload.InputStream.CopyTo(ms);
          doc = ms.ToArray();
        }

        // Fill in other file information
        contentLength = fileToUpload.ContentLength;
        contentType = fileToUpload.ContentType;
        filePath = Path.GetDirectoryName(fileToUpload.FileName);
        fileName = Path.GetFileName(fileToUpload.FileName);

        // Look at all properties
        System.Diagnostics.Debugger.Break();
      }

      return View();
    }

    public ActionResult Sample02()
    {
      return View();
    }

    [HttpPost]
    public ActionResult Sample02(HttpPostedFileBase fileToUpload)
    {
      // Use a class for file properties
      FileUpload file = new FileUpload();

      if (fileToUpload != null && fileToUpload.ContentLength > 0) {
        // Get the uploaded file
        using (MemoryStream ms = new MemoryStream()) {
          fileToUpload.InputStream.CopyTo(ms);
          file.OriginalDocument = ms.ToArray();
        }

        // Fill in other file information
        file.ContentLength = fileToUpload.ContentLength;
        file.ContentType = fileToUpload.ContentType;
        file.FilePath = Path.GetDirectoryName(fileToUpload.FileName);
        file.FileName = Path.GetFileName(fileToUpload.FileName);

        // Look at all properties
        System.Diagnostics.Debugger.Break();

        // TODO: Do something with the file data
      }

      return View();
    }

    public ActionResult Sample03()
    {
      Sample03ViewModel vm = new Sample03ViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Sample03(Sample03ViewModel vm)
    {
      // Set file info using base class
      base.SetFileUploadInfo(vm.FileToUpload, vm.FileUploadInfo);
      
      // Look at properties of View Model
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }

    public ActionResult Sample04()
    {
      Sample04ViewModel vm = new Sample04ViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Sample04(Sample04ViewModel vm)
    {
      // Set file info using base class
      base.SetFileUploadInfo(vm.FileToUpload, vm.FileUploadInfo);

      // Create thumbnail
      vm.CreateThumbnail();

      // Look at properties of View Model
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }
  }
}