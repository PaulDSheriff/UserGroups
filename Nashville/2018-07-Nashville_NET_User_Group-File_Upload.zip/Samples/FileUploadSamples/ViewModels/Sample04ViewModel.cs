﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Web;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class Sample04ViewModel : ViewModelBase
  {
    #region Constructor
    public Sample04ViewModel()
    {
      FileUploadInfo = new FileUpload();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set file upload information
    /// </summary>
    public FileUpload FileUploadInfo { get; set; }

    /// <summary>
    /// Get/Set HTTP File Input Object
    /// </summary>
    [Description("File to Upload")]
    [DataType(DataType.Upload)]
    public HttpPostedFileBase FileToUpload { get; set; }
    #endregion

    #region CreateThumbnail Method
    public void CreateThumbnail()
    {
      // Create thumbnail
      if (CanConvertToThumbnail(FileUploadInfo.ContentType)) {
        FileUploadInfo.Thumbnail = ConvertToThumbnail(FileUploadInfo.OriginalDocument);
      }
      else {
        FileUploadInfo.Thumbnail = File.ReadAllBytes(NoPreviewFileName);
      }
    }
    #endregion
  }
}