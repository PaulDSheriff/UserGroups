﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class Sample03ViewModel
  {
    #region Constructor
    public Sample03ViewModel()
    {
      FileUploadInfo = new FileUpload();
    }
    #endregion

    /// <summary>
    /// Get/Set file upload information
    /// </summary>
    public FileUpload FileUploadInfo { get; set; }

    /// <summary>
    /// Get/Set HTTP File Input Object
    /// </summary>
    [Description("File to Upload")]
    [DataType(DataType.Upload)]
    public HttpPostedFileBase FileToUpload { get; set; }
  }
}