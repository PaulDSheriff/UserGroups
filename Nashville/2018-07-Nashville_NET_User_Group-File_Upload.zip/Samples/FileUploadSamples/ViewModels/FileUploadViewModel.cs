﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Web;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class FileUploadViewModel : ViewModelBase
  {
    #region Constructor
    public FileUploadViewModel()
    {
      Init();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the list of file uploads
    /// </summary>
    public List<FileUpload> FileUploadList { get; set; }

    /// <summary>
    /// Get/Set file upload information
    /// </summary>
    public FileUpload FileUploadInfo { get; set; }

    /// <summary>
    /// Get/Set HTTP File Input Object
    /// </summary>
    [Description("File to Upload")]
    [DataType(DataType.Upload)]
    public HttpPostedFileBase FileToUpload { get; set; }
    #endregion

    #region Init Method
    public void Init()
    {
      FileUploadList = new List<FileUpload>();
      FileUploadInfo = new FileUpload();
    }
    #endregion

    #region LoadFileUploads Method
    public void LoadFileUploads()
    {
      DocumentDB db = null;

      Init();

      using (db = new DocumentDB()) {        
        FileUploadList = db.FileUploads.ToList();
      }
    }
    #endregion
    
    #region Load Method
    public void Load(int id)
    {
      DocumentDB db = null;

      Init();

      using (db = new DocumentDB()) {
        FileUploadInfo = db.FileUploads.Find(id);
      }
    }
    #endregion

    #region Save Method
    public bool Save()
    {
      bool ret = false;
      DocumentDB db = null;

      try {
        // Create thumbnail
        if (CanConvertToThumbnail(FileUploadInfo.ContentType)) {
          FileUploadInfo.Thumbnail = ConvertToThumbnail(FileUploadInfo.OriginalDocument);
        }
        else {
          FileUploadInfo.Thumbnail = File.ReadAllBytes(NoPreviewFileName);
        }

        // Save file upload data
        using (db = new DocumentDB()) {
          if (FileUploadInfo.DocumentId == -1) {
            db.FileUploads.Add(FileUploadInfo);
          }
          else {
            db.Entry(FileUploadInfo).State = EntityState.Modified;
          }
          db.SaveChanges();
        }
        ret = true;
      }
      catch (DbEntityValidationException ex) {
        // TODO: Do something with Validation Errors
        Console.Write(ex.ToString());
      }

      return ret;
    }
    #endregion
  }
}