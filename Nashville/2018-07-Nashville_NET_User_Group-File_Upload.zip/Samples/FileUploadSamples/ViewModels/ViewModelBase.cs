﻿using System;
using System.Configuration;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace FileUploadSamples.ViewModels
{
  public class ViewModelBase
  {
    #region Constructor
    public ViewModelBase()
    {
      NoPreviewFileName = "~/Images/NoPreview.png";
      ImageTypes = "bmp,gif,img,jpeg,jpg,png";
      ThumbWidth = 100;
      ThumbHeight = 100;
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the name of the file to use when no preview image is available
    /// </summary>
    public string NoPreviewFileName { get; set; }
    /// <summary>
    /// Get/Set the list of valid image types for which we can create a thumbnail
    /// Example: bmp,gif,img,jpeg,jpg,png
    /// </summary>
    public string ImageTypes { get; set; }
    /// <summary>
    /// Get/Set the thumbnail default width
    /// </summary>
    public int ThumbWidth { get; set; }
    /// <summary>
    /// Get/Set the thumbnail default height
    /// </summary>
    public int ThumbHeight { get; set; }
    #endregion

    #region CanConvertToThumbnail Method
    protected bool CanConvertToThumbnail(string type)
    {
      bool ret = false;
      
      if (type.Contains("/")) {
        type = type.Substring(type.LastIndexOf("/") + 1);
      }

      // Get image types from configuration file, or use default ones
      ImageTypes = GetValueFromConfigurationFile("imageTypes", ImageTypes);
      // See if the image type is in the list of valid types
      if (ImageTypes.Split(',').Contains(type)) {
        ret = true;
      }

      return ret;
    }
    #endregion

    #region ConvertToThumbnail Method
    protected byte[] ConvertToThumbnail(byte[] fullImage)
    {
      Image img = default(Image);
      ImageConverter converter = new ImageConverter();
      byte[] ret = null;

      // Get thumbnail width/height, or use default ones
      ThumbWidth = Convert.ToInt32(GetValueFromConfigurationFile("thumbWidth", ThumbWidth.ToString()));
      ThumbHeight = Convert.ToInt32(GetValueFromConfigurationFile("thumbHeight", ThumbHeight.ToString()));
      // Convert image to Image data type
      using (MemoryStream ms = new MemoryStream((byte[])fullImage)) {
        img = Image.FromStream(ms);
      }

      // Resize image
      var newImg = ResizeImage(img, ThumbWidth, ThumbHeight);
      // Convert to byte array
      ret = (byte[])converter.ConvertTo(newImg, typeof(byte[]));

      return ret;
    }
    #endregion

    #region ResizeImage Method
    /// <summary>
    /// Resize an image to the specified width and height.
    /// </summary>
    /// <param name="image">The image to resize.</param>
    /// <param name="width">The width to resize to.</param>
    /// <param name="height">The height to resize to.</param>
    /// <returns>The resized image.</returns>
    protected static Bitmap ResizeImage(Image image, int width, int height)
    {
      Rectangle rect = new Rectangle(0, 0, width, height);
      Bitmap ret = new Bitmap(width, height);

      if (image != null) {
        ret.SetResolution(image.HorizontalResolution, image.VerticalResolution);

        using (Graphics newGraphic = Graphics.FromImage(ret)) {
          newGraphic.CompositingMode = CompositingMode.SourceCopy;
          newGraphic.CompositingQuality = CompositingQuality.HighQuality;
          newGraphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
          newGraphic.SmoothingMode = SmoothingMode.HighQuality;
          newGraphic.PixelOffsetMode = PixelOffsetMode.HighQuality;

          using (ImageAttributes imgAttr = new ImageAttributes()) {
            imgAttr.SetWrapMode(WrapMode.TileFlipXY);
            newGraphic.DrawImage(image, rect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, imgAttr);
          }
        }
      }

      return ret;
    }
    #endregion

    #region GetValueFromConfigurationFile Method
    protected virtual string GetValueFromConfigurationFile(string keyName, string defaultValue)
    {
      string ret;

      ret = ConfigurationManager.AppSettings[keyName];
      if (string.IsNullOrEmpty(ret)) {
        ret = defaultValue;
      }

      return ret;
    }
    #endregion
  }
}