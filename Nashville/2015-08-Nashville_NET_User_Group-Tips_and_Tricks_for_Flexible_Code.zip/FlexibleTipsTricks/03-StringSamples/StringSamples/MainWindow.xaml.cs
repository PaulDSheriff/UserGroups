﻿using System.Diagnostics;
using System.Text;
using System.Windows;

namespace StringSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnStringBuilder_Click(object sender, RoutedEventArgs e)
    {
      StringBuilder sb = new StringBuilder(1024);

      sb.Append("Adding a new String without a line break.");
      sb.AppendLine("Adding onto the previous line and adding a line break");
      sb.AppendFormat("Hello {0}", "Tom");

      tbResult.Text = sb.ToString();
    }

    private void btnStringFormat_Click(object sender, RoutedEventArgs e)
    {
      string value;

      value = string.Format("Hello {0}, you have just won {1}", "Tom", 20.ToString("c"));

      tbResult.Text = value;
    }

    private void btnStringIsNullOrEmpty_Click(object sender, RoutedEventArgs e)
    {
      string value;


      // The following does not work because 'value' is unassigned
      //Debug.WriteLine(string.IsNullOrEmpty(value));

      value = null;
      Debug.WriteLine(string.IsNullOrEmpty(value));

      value = "";
      Debug.WriteLine(string.IsNullOrEmpty(value));

      value = " ";
      Debug.WriteLine(string.IsNullOrEmpty(value));

      value = "Some Text";
      Debug.WriteLine(string.IsNullOrEmpty(value));

      // Open the Output Window
      Debugger.Break();
    }

    private void btnStringIsNullOrWhiteSpace_Click(object sender, RoutedEventArgs e)
    {
      string value = null;
      Debug.WriteLine(string.IsNullOrWhiteSpace(value));

      value = "";
      Debug.WriteLine(string.IsNullOrWhiteSpace(value));

      value = " ";
      Debug.WriteLine(string.IsNullOrWhiteSpace(value));

      value = "    ";
      Debug.WriteLine(string.IsNullOrWhiteSpace(value));

      // Open the Output Window
      Debugger.Break();
    }
  }
}
