﻿
using MessageLayer;
using CommonLibrary;

namespace MessageLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Message Manager
      InitializeMessageManager();
    }

    protected void InitializeMessageManager()
    {
      // Create Message Manager and Default to 'Resource' Provider
      PDSAMessageManager.Instance = new PDSAMessageManager(new PDSAMessageResource());

      // You can also pass in the Resource name
      //PDSAMessageManager.Instance = new PDSAMessageManager(new PDSAMessageResource("MessageLayerSample.Properties.Resources"));

      //**************************************************************
      // Create Message Manager and Default to 'XML' Provider
      //PDSAMessageManager.Instance = new PDSAMessageManager(new PDSAMessageXml(FileCommon.GetCurrentDirectory() + @"\Xml\Messages.xml"));
    }
  }
}
