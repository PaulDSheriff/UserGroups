﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace MessageLayer
{
  public class PDSAMessageXml : PDSAMessageBase
  {
    #region Constructors
    public PDSAMessageXml()
      : base()
    {
    }

    public PDSAMessageXml(string location)
      : base(location)
    {
    }
    #endregion

    public override string GetMessage(string key, string defaultMessage)
    {
      string ret = string.Empty;

      XElement doc = XElement.Load(BaseLocationName);

      XElement elem = (from node in doc.Elements("Message")
                       where node.Element("Key").Value == key
                       select node).SingleOrDefault();

      if (elem != null)
        ret = elem.Element("Value").Value;
      else
        ret = defaultMessage;

      return ret;
    }
  }
}
