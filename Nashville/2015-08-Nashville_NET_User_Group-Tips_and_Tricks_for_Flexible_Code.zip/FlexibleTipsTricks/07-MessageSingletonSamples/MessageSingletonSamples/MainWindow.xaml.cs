﻿using System.Windows;

using CommonLibrary;

namespace MessageSingletonSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
    
    private void btnGetMessage_Click(object sender, RoutedEventArgs e)
    {
      MessageManager mgr = new MessageManager();

      tbResult.Text = mgr.GetMessage(txtKey.Text, txtDefaultMsg.Text);
    }

    #region Singleton Pattern
    private void btnGetMessageSingleton_Click(object sender, RoutedEventArgs e)
    {
      tbResult.Text = MessageManager.Instance.GetMessage(txtKey.Text, txtDefaultMsg.Text);
    }
    #endregion
  }
}
