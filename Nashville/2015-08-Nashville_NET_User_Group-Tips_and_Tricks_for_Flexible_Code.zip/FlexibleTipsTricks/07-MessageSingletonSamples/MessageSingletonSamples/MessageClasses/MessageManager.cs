﻿using System;
using System.Reflection;
using System.Resources;

namespace CommonLibrary
{
  /// <summary>
  /// Class to retrieve messages from a data store
  /// This class uses the Singleton pattern
  /// </summary>
  public class MessageManager
  {
    #region Instance Property
    private static MessageManager _Instance = null;

    /// <summary>
    /// Get/Set an Instance of the PDSAMessage class
    /// </summary>
    public static MessageManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new MessageManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    /// <summary>
    /// Get/Set the Base Location Name
    /// This is typically in the format YourApplicationName.Properties.Resources
    /// </summary>
    public string BaseLocationName { get; set; }

    /// <summary>
    /// Return a message for the specified key passed in
    /// </summary>
    /// <param name="key">The identifier of the messages</param>
    /// <returns>A message</returns>
    public string GetMessage(string key)
    {
      return GetMessage(key, string.Format("Resource {0} Not Found.", key));
    }

    /// <summary>
    /// Return a message for the specified key passed in
    /// </summary>
    /// <param name="key">The identifier of the messages</param>
    /// <param name="defaultMessage">The default message to return if the identifier is not found</param>
    /// <returns>A message</returns>
    public string GetMessage(string key, string defaultMessage)
    {
      string ret = string.Empty;

      // NOTE: You should replace this code with a Dependency Injected Provider
      Assembly assm = Assembly.GetEntryAssembly();
      if (string.IsNullOrEmpty(BaseLocationName))
      {
        BaseLocationName = assm.GetName().Name + ".Properties.Resources";
      }

      ResourceManager resourceManager = new ResourceManager(BaseLocationName, assm);
      try
      {
        ret = resourceManager.GetString(key);
      }
      catch (Exception ex)
      {
        System.Diagnostics.Debug.Write(ex.Message);
        ret = defaultMessage;
      }

      return ret;
    }
  }
}
