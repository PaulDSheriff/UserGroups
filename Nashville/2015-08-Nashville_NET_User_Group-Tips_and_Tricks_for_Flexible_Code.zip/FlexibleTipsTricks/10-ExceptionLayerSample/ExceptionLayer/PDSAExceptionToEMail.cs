using System;
using System.Net.Mail;

namespace ExceptionLayer
{
  public class PDSAExceptionToEMail : PDSAExceptionPublisherBase
  {
    #region Constructors
    /// <summary>
    /// Create an instance of an email exception publisher
    /// </summary>
    /// <param name="settings">An instance of PDSAEmailSettings</param>
    public PDSAExceptionToEMail(PDSAEmailSettings settings)
    {
      _Settings = settings;
    }
    #endregion

    #region Private Properties
    private PDSAEmailSettings _Settings = null;
    #endregion

    #region PublishSpecial Method
    protected override void PublishSpecial()
    {
      SmtpClient smtp = null;

      _Settings.ToEmail = _Settings.ToEmail.Replace(";", ",");
      try
      {
        smtp = new SmtpClient();

        //  Send Exception via Email
        smtp.Host = _Settings.SMTPServer;
        smtp.Send(_Settings.FromEmail, _Settings.ToEmail, _Settings.Subject, ExceptionInfo.ToString());
        smtp.Dispose();
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Error in PDSAExceptionToEmail", ex);
      }
    }
    #endregion
  }
}