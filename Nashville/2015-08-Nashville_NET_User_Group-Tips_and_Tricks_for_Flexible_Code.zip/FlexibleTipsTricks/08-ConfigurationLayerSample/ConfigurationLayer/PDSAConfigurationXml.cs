using System.Xml;

namespace ConfigurationLayer
{
  public class PDSAConfigurationXml : PDSAConfigurationBase
  {
    #region Constructors
    public PDSAConfigurationXml(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Methods
    public override string GetSetting(string key)
    {
      return GetSetting(key, null);
    }

    public override string GetSetting(string key, string defaultValue)
    {
      XmlDocument xd = null;
      XmlNode xn = null;
      string xPathQuery = null;
      string ret = string.Empty;

      xd = new XmlDocument();
      xd.Load(base.Location);

      xPathQuery = string.Format("/configuration/appSettings/add[@key='{0}']", key);

      xn = xd.SelectSingleNode(xPathQuery);

      if (xn == null)
      {
        ret = defaultValue;
      }
      else
      {
        ret = xn.Attributes["value"].Value;
      }

      return ret;
    }
    #endregion
  }
}