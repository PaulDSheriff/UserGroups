using Microsoft.Win32;

namespace ConfigurationLayer
{
  public class PDSAConfigurationRegistry : PDSAConfigurationBase
  {
    #region Constructors  
    public PDSAConfigurationRegistry(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Methods

    public override string GetSetting(string key, string defaultValue)
    {
      RegistryKey rk = null;
      string ret = string.Empty;

      rk = Registry.LocalMachine.OpenSubKey(base.Location, true);

      if (rk == null)
      {
        ret = defaultValue;
      }
      else
      {
        ret = rk.GetValue(key, defaultValue).ToString();
        rk.Close();
      }

      return ret;
    }
    #endregion
  }
}