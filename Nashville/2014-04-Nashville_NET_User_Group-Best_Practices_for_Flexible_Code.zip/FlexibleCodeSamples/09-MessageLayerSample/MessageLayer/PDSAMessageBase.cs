﻿using System;

namespace MessageLayer
{
  public abstract class PDSAMessageBase
  {
    #region Constructors
    public PDSAMessageBase()
    {
      BaseLocationName = string.Empty;
    }

    public PDSAMessageBase(string location)
    {
      BaseLocationName = location;
    }
    #endregion

    public string BaseLocationName { get; set; }

    public virtual string GetMessage(string key)
    {
      return GetMessage(key, string.Format("Message {0} Not Found.", key));
    }

    public abstract string GetMessage(string key, string defaultMessage);
  }
}
