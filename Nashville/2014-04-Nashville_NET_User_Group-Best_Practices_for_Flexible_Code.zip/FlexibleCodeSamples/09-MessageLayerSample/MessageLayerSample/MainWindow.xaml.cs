﻿using System.Windows;

using MessageLayer;

namespace MessageLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnGetMessage_Click(object sender, RoutedEventArgs e)
    {
      txtValue.Text = PDSAMessageManager.Instance.GetMessage(txtKey.Text);
    }

    private void btnGetMessageDefault_Click(object sender, RoutedEventArgs e)
    {
      txtValue.Text = PDSAMessageManager.Instance.GetMessage(txtKey.Text, txtDefault.Text);
    }
  }
}
