﻿using System;
using System.Reflection;
using System.Windows;

namespace ReflectionSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region InvokeMember Method to Set a Property
    private void btnInvokeMember_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();
      typeof(Product).InvokeMember("ProductName",
        BindingFlags.SetProperty,
          Type.DefaultBinder, entity,
           new Object[] { "PDSA .NET Productivity Framework" });

      MessageBox.Show(entity.ProductName);
    }
    #endregion

    #region SetValue Method
    private void btnSetValue_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      typeof(Product).GetProperty("ProductName").
        SetValue(entity, "PDSA .NET Productivity Framework", null);

      MessageBox.Show(entity.ProductName);
    }
    #endregion

    #region InvokeMember Method to Get a Property
    private void btnInvokeMemberGet_Click(object sender, RoutedEventArgs e)
    {
      object value;
      Product entity = new Product();

      entity.ProductName = "Haystack Code Generator";

      value = typeof(Product).InvokeMember("ProductName",
        BindingFlags.GetProperty,
          Type.DefaultBinder, entity, null);

      MessageBox.Show(value.ToString());
    }
    #endregion

    private void btnGetValue_Click(object sender, RoutedEventArgs e)
    {
      object value;
      Product entity = new Product();

      entity.ProductName = "Haystack Code Generator";

      value = typeof(Product).GetProperty("ProductName").GetValue(entity);

      MessageBox.Show(value.ToString());
    }
  }
}
