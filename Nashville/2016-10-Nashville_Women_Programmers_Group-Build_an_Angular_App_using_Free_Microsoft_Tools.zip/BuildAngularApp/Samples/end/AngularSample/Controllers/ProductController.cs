﻿using AngularSample.Models;
using System.Linq;
using System.Web.Http;

namespace AngularSample.Controllers
{
  public class ProductController : ApiController
  {
    public IHttpActionResult Get()
    {
      IHttpActionResult ret = null;
      ProductsDB db = new ProductsDB();

      if (db.Products.Count() > 0)
      {
        ret = Ok(db.Products);
      }
      else
      {
        ret = NotFound();
      }

      return ret;
    }
  }
}