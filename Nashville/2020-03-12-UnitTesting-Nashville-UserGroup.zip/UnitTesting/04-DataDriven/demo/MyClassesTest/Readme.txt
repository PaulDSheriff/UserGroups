﻿Run the SQL script located in the \SqlScripts folder in a SQL Server database.
Modify the connection string in the App.config file to point to the SQL Server database where you ran the scripts.