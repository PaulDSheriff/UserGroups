To run this sample
---------------------------------
npm install
npm run dev

You also need to run the WebApi sample in order to retrieve data from the Web API