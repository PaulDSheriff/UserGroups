To run this sample
---------------------------------
npm install
npm run dev

You also need to run the WebApi sample in order to retrieve data from the Web API


XMLHttpRequest.readyState
=================================
0 - Unsent
1 - Opened
2 - Headers Received
3 - Loading
4 - Done