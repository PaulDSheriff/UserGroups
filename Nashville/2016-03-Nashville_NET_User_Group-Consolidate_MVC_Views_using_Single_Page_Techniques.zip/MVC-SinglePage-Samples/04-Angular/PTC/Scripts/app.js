﻿(function () {
  'use strict';

  // Register an Angular module
  angular.module('ptcApp', []);
})();