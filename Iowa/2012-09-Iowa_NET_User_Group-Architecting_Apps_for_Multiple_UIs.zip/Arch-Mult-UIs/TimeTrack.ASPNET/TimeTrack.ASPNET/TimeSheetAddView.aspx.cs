﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.ASPNET
{
  public partial class TimeSheetAddView : System.Web.UI.Page
  {
    private TimeSheetAddViewModel _ViewModel = null;

    #region ViewModelObject Property
    private TimeSheetAddViewModel ViewModelObject
    {
      get
      {
        if (_ViewModel == null)
          _ViewModel = new TimeSheetAddViewModel(false);

        return _ViewModel;
      }
      set { _ViewModel = value; }
    }
    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
      _ViewModel = ViewModelObject;

      if (!Page.IsPostBack)
      {
        CustomerLoad();
        EmployeeLoad();
        InitForm();
      }
    }

    #region InitForm Method
    private void InitForm()
    {
      rvTaskDate.MinimumValue = DateTime.Now.AddDays(-7).ToShortDateString();
      rvTaskDate.MaximumValue = DateTime.Now.ToShortDateString();
      rvTaskDate.ErrorMessage = "Task Date must be between " + DateTime.Now.AddDays(-7).ToShortDateString() + " and " + DateTime.Now.ToShortDateString();

      InitTextBoxes();
    }
    #endregion

    #region InitTextBoxes Method
    private void InitTextBoxes()
    {
      txtHours.Text = _ViewModel.Hours.ToString();
      txtTaskDate.Text = _ViewModel.TaskDate;
      txtDesc.Text = _ViewModel.Description;
    }
    #endregion

    #region btnHome_Click Event Procedure
    protected void btnHome_Click(object sender, EventArgs e)
    {
      Response.Redirect("Default.aspx");
    }
    #endregion

    #region CustomerLoad Method
    private void CustomerLoad()
    {
      ddlCustomers.DataTextField = "CustomerName";
      ddlCustomers.DataValueField = "CustomerId";
      ddlCustomers.DataSource = ViewModelObject.Customers;
      ddlCustomers.DataBind();
    }
    #endregion

    #region ProjectLoad Method
    private void ProjectLoad(int customerId)
    {
      ViewModelObject.GetProjectsByCustomer(customerId);

      ddlProjects.DataTextField = "ProjectName";
      ddlProjects.DataValueField = "ProjectId";
      ddlProjects.DataSource = ViewModelObject.Projects;
      ddlProjects.DataBind();
    }
    #endregion

    #region EmployeeLoad Method
    private void EmployeeLoad()
    {
      ddlEmployees.DataTextField = "EmployeeName";
      ddlEmployees.DataValueField = "EmployeeId";
      ddlEmployees.DataSource = ViewModelObject.Employees;
      ddlEmployees.DataBind();
    }
    #endregion

    #region ddlCustomers_SelectedIndexChanged Event Procedure
    protected void ddlCustomers_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (ddlCustomers.SelectedIndex != -1)
      {
        ProjectLoad(Convert.ToInt32(ddlCustomers.SelectedValue));
        lblMessages.Text = string.Empty;
      }
    }
    #endregion

    #region Save_Click Event Procedure
    protected void btnSave_Click(object sender, ImageClickEventArgs e)
    {
      lstErrors.Visible = false;
      lblMessages.Text = string.Empty;

      _ViewModel.SelectedCustomer.CustomerId = Convert.ToInt32(ddlCustomers.SelectedValue);
      _ViewModel.SelectedProject.ProjectId = Convert.ToInt32(ddlProjects.SelectedValue);
      _ViewModel.SelectedEmployee.EmployeeId = Convert.ToInt32(ddlEmployees.SelectedValue);
      _ViewModel.TaskDate = txtTaskDate.Text;
      _ViewModel.Hours = Convert.ToDecimal(txtHours.Text);
      _ViewModel.Description = txtDesc.Text;
      _ViewModel.Insert();

      if (_ViewModel.IsValidationAreaVisible)
      {
        lstErrors.Visible = true;
        lstErrors.DataTextField = "Message";
        lstErrors.DataSource = _ViewModel.ValidationFailures;
        lstErrors.DataBind();
      }
      else
        // Prepare for new entry
        InitTextBoxes();

      lblMessages.Text = _ViewModel.MessageToDisplay;
    }
    #endregion

    #region Cancel_Click Event Procedure
    protected void btnCancel_Click(object sender, ImageClickEventArgs e)
    {
      Response.Redirect("Default.aspx");
    }
    #endregion
  }
}