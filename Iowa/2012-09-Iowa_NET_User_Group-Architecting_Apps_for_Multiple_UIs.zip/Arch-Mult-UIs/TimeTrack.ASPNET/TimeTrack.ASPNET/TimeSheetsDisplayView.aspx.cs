﻿using System;
using System.Web.UI;

using TimeTrack.ViewModels;

namespace TimeTrack.ASPNET
{
  public partial class TimeSheetsDisplayView : System.Web.UI.Page
  {
    private TimeSheetsDisplayViewModel _ViewModel = null;

    #region ViewModelObject Property
    private TimeSheetsDisplayViewModel ViewModelObject
    {
      get
      {
        if (_ViewModel == null)
          _ViewModel = new TimeSheetsDisplayViewModel(false);
        
        return _ViewModel;
      }
      set { _ViewModel = value; }
    }
    #endregion

    #region Page_Load Event Procedure
    protected void Page_Load(object sender, EventArgs e)
    {
      // Get ViewModel from ViewState
      _ViewModel = ViewModelObject;

      if (!Page.IsPostBack)
      {
        _ViewModel.GetAllCustomers();

        CustomerLoad();
      }
    }
    #endregion

    #region btnHome_Click Event Procedure
    protected void btnHome_Click(object sender, EventArgs e)
    {
      Response.Redirect("Default.aspx");
    }
    #endregion

    #region CustomerLoad Method
    private void CustomerLoad()
    {
      ddlCustomers.DataTextField = "CustomerName";
      ddlCustomers.DataValueField = "CustomerId";
      ddlCustomers.DataSource = _ViewModel.CustomerCollection;
      ddlCustomers.DataBind();
    }
    #endregion

    #region ddlCustomers_SelectedIndexChanged Event Procedure
    protected void ddlCustomers_SelectedIndexChanged(object sender, EventArgs e)
    {
      _ViewModel.SelectedCustomer.CustomerId = Convert.ToInt32(ddlCustomers.SelectedValue);
      if (ddlCustomers.SelectedIndex == 0)
        _ViewModel.GetAllTimeSheets();
      else
        _ViewModel.GetTimeSheetsByCustomer(_ViewModel.SelectedCustomer.CustomerId);

      grdTimeSheets.DataSource = _ViewModel.DataCollection;
      grdTimeSheets.DataBind();
    }
    #endregion
  }
}