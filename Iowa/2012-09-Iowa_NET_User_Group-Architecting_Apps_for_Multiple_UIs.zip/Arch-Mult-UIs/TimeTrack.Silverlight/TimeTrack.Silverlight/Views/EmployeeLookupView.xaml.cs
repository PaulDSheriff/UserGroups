﻿using System.Windows;
using System.Windows.Controls;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.Silverlight
{
  public partial class EmployeeLookupView : ChildWindow
  {
    private EmployeeViewModel _ViewModel = null;

    #region Constructor
    public EmployeeLookupView()
    {
      InitializeComponent();

      // Grab the Instance of the ViewModel
      _ViewModel = (EmployeeViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region Loaded Event Procedure
    private void ChildWindow_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.GetEmployees();
    }
    #endregion

    #region SelectionChanged Event Procedure
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      //// Get Selected Customer and Store into Application Level
      (Application.Current as App).TimeSheetModel.SelectedEmployee =
        (Employee)lstData.SelectedItem;

      this.DialogResult = true;    
    }
    #endregion

    #region TextChanged Event
    private void txtName_TextChanged(object sender, TextChangedEventArgs e)
    {
      _ViewModel.FilterEmployees(txtName.Text.Trim());
    }
    #endregion

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
      this.DialogResult = false;
    }

  }
}

