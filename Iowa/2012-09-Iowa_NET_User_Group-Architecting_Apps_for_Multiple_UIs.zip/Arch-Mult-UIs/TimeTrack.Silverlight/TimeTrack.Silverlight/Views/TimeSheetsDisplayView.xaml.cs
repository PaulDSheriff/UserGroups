﻿using System;
using System.Windows;
using System.Windows.Controls;

using TimeTrack.EntityClasses;
using TimeTrack.ViewModels;

namespace TimeTrack.Silverlight
{
  public partial class TimeSheetsDisplayView : UserControl
  {
    private TimeSheetsDisplayViewModel _ViewModel = null;

    #region Constructor
    public TimeSheetsDisplayView()
    {
      InitializeComponent();

      // Ensure TimeSheet View Model object is valid
      (Application.Current as App).InitTimeSheetViewModel();

      // Grab the Instance of the ViewModel
      _ViewModel = (TimeSheetsDisplayViewModel)this.Resources["viewModel"];
    }
    #endregion

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.GetAllCustomers();
    }

    #region Customers Click Event
    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      ResetUI();
    }
    #endregion

    #region PerformSearch Method
    private void PerformSearch()
    {
      if (_ViewModel.SelectedCustomer == null || _ViewModel.SelectedCustomer.CustomerId == -1)
      {
        lstData.ItemTemplate = (DataTemplate)this.Resources["tmplWithCustomer"];
        _ViewModel.GetAllTimeSheets();
      }
      else
      {
        lstData.ItemTemplate = (DataTemplate)this.Resources["tmplProjectOnly"];
        _ViewModel.GetTimeSheetsByCustomer(_ViewModel.SelectedCustomer);
      }
    }
    #endregion

    #region Reset Click Event
    private void Reset_Click(object sender, EventArgs e)
    {
      (Application.Current as App).TimeSheetModel.SelectedCustomer = new Customer();
      (Application.Current as App).TimeSheetModel.SelectedCustomer.CustomerId = -1;
      _ViewModel.SelectedCustomer = (Application.Current as App).TimeSheetModel.SelectedCustomer;
      ResetUI();
    }
    #endregion

    #region ResetUI Method
    private void ResetUI()
    {
      _ViewModel.DataCollection = new System.Collections.ObjectModel.ObservableCollection<TimeSheet>();
      _ViewModel.IsMessageVisible = false;
      lstData.SelectedIndex = -1;
    }
    #endregion

    #region ComboBox Event Procedures
    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      PerformSearch();
    }
    #endregion
  }
}
