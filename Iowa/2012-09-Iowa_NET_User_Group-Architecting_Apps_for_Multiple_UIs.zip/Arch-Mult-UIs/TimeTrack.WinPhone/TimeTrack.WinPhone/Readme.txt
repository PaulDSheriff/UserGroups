﻿Mobile Time Track
-----------------------------------------
To Run this application you must do the following:

1. Create a SQL Server database called TimeTrack
2. Run the \SQLScript\TimeTrack.sql file in the TimeTrack database
3. Modify the Connection String in the Web.Config file in the TimeTrack.WCFHost project as appropriate
