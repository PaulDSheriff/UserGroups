﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Common.Library
{
  /// <summary>
  /// Call this converter to change a True value to Collapsed and a False value to Visibile
  /// </summary>
  public class InvertBooleanToVisibilityConverter : IValueConverter
  {
    /// <summary>
    /// Convert a True/False value to Visibility.Collapsed/Visibility.Visible value
    /// </summary>
    /// <param name="value">A boolean value</param>
    /// <param name="targetType">The type of object</param>
    /// <param name="parameter">Any parameters passed via XAML</param>
    /// <param name="culture">The current culture</param>
    /// <returns>A Visibility Enumeration</returns>
    public object Convert(object value, Type targetType,
                          object parameter, CultureInfo culture)
    {
      if ((bool)value)
        return Visibility.Collapsed;
      else
        return Visibility.Visible;
    }

    /// <summary>
    /// NOT IMPLEMENTED
    /// </summary>
    /// <param name="value">A boolean value</param>
    /// <param name="targetType">The type of object</param>
    /// <param name="parameter">Any parameters passed via XAML</param>
    /// <param name="culture">The current culture</param>
    /// <returns>NOT IMPLEMENTED</returns>
    public object ConvertBack(object value, Type targetType,
                              object parameter, CultureInfo culture)
    {
      throw new NotImplementedException("InvertBooleanToVisibility ConvertBack Method Not Implemented");
    }
  }
}