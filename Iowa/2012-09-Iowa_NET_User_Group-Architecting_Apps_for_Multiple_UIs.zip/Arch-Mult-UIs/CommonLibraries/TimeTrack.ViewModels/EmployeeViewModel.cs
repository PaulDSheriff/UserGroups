﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common.Library;

using TimeTrack.EntityClasses;
#if WINDOWS_PHONE
using TimeTrack.ViewModels.WinPhone.EmployeeServiceReference;
#endif
#if SILVERLIGHT && !WINDOWS_PHONE
using TimeTrack.ViewModels.Silverlight.EmployeeServiceReference;
#endif
#if !WINDOWS_PHONE && !SILVERLIGHT
using TimeTrack.ViewModels.EmployeeServiceReference;
#endif

namespace TimeTrack.ViewModels
{
	/// <summary>
	/// ViewModel class for working with the Employee view
	/// </summary>
  public class EmployeeViewModel : ViewModelBase
  {
    #region Constructors
    /// <summary>
    /// The Constructor automatically calls the Init() method
    /// </summary>
    public EmployeeViewModel() : base()
    {     
    }

    public EmployeeViewModel(bool useAsync)
      : base(useAsync)
    {
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      MessageToDisplay = "Please wait while loading employees...";
    }
    #endregion

    #region Private Variables
    // WCF Service Client
    EmployeeServicesClient _Client = null;

    private ObservableCollection<Employee> _DataCollection;
    private IEnumerable<Employee> _FilteredDataCollection;
    #endregion

    #region Public Properties
    public ObservableCollection<Employee> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public IEnumerable<Employee> FilteredDataCollection
    {
      get { return _FilteredDataCollection; }
      set
      {
        _FilteredDataCollection = value;
        RaisePropertyChanged("FilteredDataCollection");
      }
    }
    #endregion

    #region CreateServiceClient Method
    private EmployeeServicesClient CreateServiceClient()
    {
      _Client = new EmployeeServicesClient();

      // Set any additional properties here

      return _Client;
    }
    #endregion

    #region CloseServiceClient Method
    private void CloseServiceClient()
    {
#if WINDOWS_PHONE || SILVERLIGHT
      _Client.CloseAsync();
#else
      _Client.Close();
#endif
    }
    #endregion

    #region GetEmployees Method
    public void GetEmployees()
    {
      // Reset View Model Variables
      IsNoRecordsVisible = false;

      CreateServiceClient();

      if (UseAsync)
      {
        _Client.GetEmployeesCompleted += new EventHandler<GetEmployeesCompletedEventArgs>(client_GetEmployeesCompleted);
        _Client.GetEmployeesAsync();
      }
#if !WINDOWS_PHONE && !SILVERLIGHT
      else
        GetEmployeesCompleted(_Client.GetEmployees());
#endif
      }

    void client_GetEmployeesCompleted(object sender, GetEmployeesCompletedEventArgs e)
    {
      EmployeeResponse response;

      response = (EmployeeResponse)e.Result;

      GetEmployeesCompleted(response);
    }

    private void GetEmployeesCompleted(EmployeeResponse response)
    {
      if (response.Status == OperationResult.Success)
      {
        DataCollection = response.DataCollection;
        FilteredDataCollection = DataCollection;
        IsMessageVisible = false;
      }
      else if (response.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No Employees found.";
        IsNoRecordsVisible = true;
      }

      CloseServiceClient();
    }
    #endregion

    #region FilterEmployees Method
    public void FilterEmployees(string filter)
    {
      FilteredDataCollection =
        from Employee in DataCollection
        where Employee.LastName.ToLower().StartsWith(filter.ToLower())
        orderby Employee.LastName
        select Employee;
    }
    #endregion
  }
}
