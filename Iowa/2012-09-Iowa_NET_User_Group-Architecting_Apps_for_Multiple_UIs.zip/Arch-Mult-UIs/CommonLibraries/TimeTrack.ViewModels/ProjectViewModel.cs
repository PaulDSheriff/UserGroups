﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common.Library;
using TimeTrack.EntityClasses;

#if WINDOWS_PHONE
using TimeTrack.ViewModels.WinPhone.ProjectServiceReference;
#endif
#if SILVERLIGHT && !WINDOWS_PHONE
using TimeTrack.ViewModels.Silverlight.ProjectServiceReference;
#endif
#if !WINDOWS_PHONE && !SILVERLIGHT
using TimeTrack.ViewModels.ProjectServiceReference;
#endif

namespace TimeTrack.ViewModels
{
  /// <summary>
  /// ViewModel class for working with the Project View
  /// </summary>
  public class ProjectViewModel : ViewModelBase
  {
    #region Constructors
    /// <summary>
    /// The Constructor automatically calls the Init() method
    /// </summary>
    public ProjectViewModel()
      : base()
    {
    }

    public ProjectViewModel(bool useAsync)
      : base(useAsync)
    {
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      MessageToDisplay = "Please wait while loading projects...";
    }
    #endregion

    #region Private Variables
    // WCF Service Client
    ProjectServicesClient _Client = null;

    private ObservableCollection<Project> _DataCollection;
    private IEnumerable<Project> _FilteredDataCollection;
    #endregion

    #region Public Properties
    public ObservableCollection<Project> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public IEnumerable<Project> FilteredDataCollection
    {
      get { return _FilteredDataCollection; }
      set
      {
        _FilteredDataCollection = value;
        RaisePropertyChanged("FilteredDataCollection");
      }
    }
    #endregion

    #region CreateServiceClient Method
    private ProjectServicesClient CreateServiceClient()
    {
      _Client = new ProjectServicesClient();

      // Set any additional properties here

      return _Client;
    }
    #endregion

    #region CloseServiceClient Method
    private void CloseServiceClient()
    {
#if WINDOWS_PHONE || SILVERLIGHT
      _Client.CloseAsync();
#else
      _Client.Close();
#endif
    }
    #endregion

    #region GetProjectsByCustomers Method
    public void GetProjectsByCustomers(int customerId)
    {
      Customer entity = new Customer();

      entity.CustomerId = customerId;

      GetProjectsByCustomers(entity);
    }

    public void GetProjectsByCustomers(Customer entity)
    {
      // Reset View Model Variables
      IsNoRecordsVisible = false;

      CreateServiceClient();

      if (UseAsync)
      {
        _Client.GetProjectsByCustomerCompleted += new EventHandler<GetProjectsByCustomerCompletedEventArgs>(client_GetProjectsByCustomerCompleted);
        _Client.GetProjectsByCustomerAsync(entity);
      }
#if !WINDOWS_PHONE && !SILVERLIGHT
      else
        GetProjectsByCustomerCompleted(_Client.GetProjectsByCustomer(entity));
#endif
    }

    void client_GetProjectsByCustomerCompleted(object sender, GetProjectsByCustomerCompletedEventArgs e)
    {
      ProjectResponse response;

      response = (ProjectResponse)e.Result;

      GetProjectsByCustomerCompleted(response);
    }

    private void GetProjectsByCustomerCompleted(ProjectResponse response)
    {
      if (response.Status == OperationResult.Success)
      {
        DataCollection = response.DataCollection;
        FilteredDataCollection = DataCollection;
        IsMessageVisible = false;
      }
      else if (response.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No projects found for customer.";
        IsNoRecordsVisible = true;
      }

      CloseServiceClient();
    }
    #endregion

    #region FilterProjects Method
    public void FilterProjects(string filter)
    {
      FilteredDataCollection =
        from proj in DataCollection
        where proj.ProjectName.ToLower().StartsWith(filter.ToLower())
        orderby proj.ProjectName
        select proj;
    }
    #endregion
  }
}
