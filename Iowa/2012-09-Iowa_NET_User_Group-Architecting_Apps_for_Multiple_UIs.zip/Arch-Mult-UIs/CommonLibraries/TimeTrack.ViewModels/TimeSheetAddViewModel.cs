﻿using System;
using System.Collections.ObjectModel;
using Common.Library;
using TimeTrack.EntityClasses;

#if WINDOWS_PHONE
using TimeTrack.ViewModels.WinPhone.TimeSheetServiceReference;
#endif
#if SILVERLIGHT && !WINDOWS_PHONE
using TimeTrack.ViewModels.Silverlight.TimeSheetServiceReference;
#endif
#if !WINDOWS_PHONE && !SILVERLIGHT
using TimeTrack.ViewModels.TimeSheetServiceReference;
#endif

namespace TimeTrack.ViewModels
{
  /// <summary>
  /// ViewModel class for adding Time Sheets
  /// </summary>
  public class TimeSheetAddViewModel : ViewModelBase
  {
    #region Constructors
    /// <summary>
    /// The Constructor automatically calls the Init() method
    /// </summary>
    public TimeSheetAddViewModel()
      : base()
    {
    }

    public TimeSheetAddViewModel(bool useAsync)
      : base(useAsync)
    {
    }
    #endregion

    #region Private Variables
    private ObservableCollection<Customer> _Customers;
    private ObservableCollection<Project> _Projects;
    private ObservableCollection<Employee> _Employees;

    private Customer _SelectedCustomer;
    private Project _SelectedProject;
    private Employee _SelectedEmployee;

    private string _TaskDate;
    private decimal _Hours;
    private string _Description;

    // WCF Client Service
    TimeSheetServicesClient _Client = null;

    private ObservableCollection<ValidationMessage> _ValidationFailures;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the Collection of Customers to choose from
    /// </summary>
    public ObservableCollection<Customer> Customers
    {
      get { return _Customers; }
      set
      {
        _Customers = value;
        RaisePropertyChanged("Customers");
      }
    }

    /// <summary>
    /// Get/Set the Collection of Projects to choose from
    /// </summary>
    public ObservableCollection<Project> Projects
    {
      get { return _Projects; }
      set
      {
        _Projects = value;
        RaisePropertyChanged("Projects");
      }
    }

    /// <summary>
    /// Get/Set the Collection of Employees to choose from
    /// </summary>
    public ObservableCollection<Employee> Employees
    {
      get { return _Employees; }
      set
      {
        _Employees = value;
        RaisePropertyChanged("Employees");
      }
    }

    /// <summary>
    /// Get/Set the Selected Customer
    /// </summary>
    public Customer SelectedCustomer
    {
      get { return _SelectedCustomer; }
      set
      {
        _SelectedCustomer = value;
        RaisePropertyChanged("SelectedCustomer");
      }
    }

    /// <summary>
    /// Get/Set the Selected Project
    /// </summary>
    public Project SelectedProject
    {
      get { return _SelectedProject; }
      set
      {
        _SelectedProject = value;
        RaisePropertyChanged("SelectedProject");
      }
    }

    /// <summary>
    /// Get/Set the Selected Employee
    /// </summary>
    public Employee SelectedEmployee
    {
      get { return _SelectedEmployee; }
      set
      {
        _SelectedEmployee = value;
        RaisePropertyChanged("SelectedEmployee");
      }
    }

    /// <summary>
    /// Get/Set the Task Date
    /// </summary>
    public string TaskDate
    {
      get { return _TaskDate; }
      set
      {
        _TaskDate = value;
        RaisePropertyChanged("TaskDate");
      }
    }

    /// <summary>
    /// Get/Set the Hours
    /// </summary>
    public decimal Hours
    {
      get { return _Hours; }
      set
      {
        _Hours = value;
        RaisePropertyChanged("Hours");
      }
    }

    /// <summary>
    /// Get/Set the Description
    /// </summary>
    public string Description
    {
      get { return _Description; }
      set
      {
        _Description = value;
        RaisePropertyChanged("Description");
      }
    }

    public ObservableCollection<ValidationMessage> ValidationFailures
    {
      get { return _ValidationFailures; }
      set
      {
        _ValidationFailures = value;
        RaisePropertyChanged("ValidationFailures");
      }
    }
    #endregion

    #region CreateServiceClient Method
    private TimeSheetServicesClient CreateServiceClient()
    {
      _Client = new TimeSheetServicesClient();

      // Set any additional properties here

      return _Client;
    }
    #endregion

    #region CloseServiceClient Method
    private void CloseServiceClient()
    {
#if WINDOWS_PHONE || SILVERLIGHT
      _Client.CloseAsync();
#else
      _Client.Close();
#endif
    }
    #endregion

    #region Init Method
    /// <summary>
    /// Initialize to a valid start state
    /// </summary>
    public override void Init()
    {
      base.Init();

      Customers = new ObservableCollection<Customer>();
      GetCustomers();
      Projects = new ObservableCollection<Project>();
      Employees = new ObservableCollection<Employee>();
      GetEmployees();
      SelectedCustomer = new Customer();
      SelectedCustomer.CustomerId = -1;
      SelectedProject = new Project();
      SelectedProject.ProjectId = -1;
      SelectedEmployee = new Employee();
      SelectedEmployee.EmployeeId = -1;
           
      ValidationFailures = new ObservableCollection<ValidationMessage>();
      IsMessageVisible = false;

      PrepareForNew();
    }
    #endregion

    #region GetCustomers Method
    /// <summary>
    /// Get all Customers
    /// </summary>
    public void GetCustomers()
    {
      CustomerViewModel vm = new CustomerViewModel(false);

      vm.GetCustomers();
      Customers = vm.DataCollection;
    }
    #endregion

    #region GetProjectsByCustomer Method
    public void GetProjectsByCustomer(int customerId)
    {
      ProjectViewModel vm = new ProjectViewModel(false);
      Customer entity = new Customer();

      entity.CustomerId = customerId;
      vm.GetProjectsByCustomers(entity);

      Projects = vm.DataCollection;
    }
    #endregion

    #region GetEmployees Method
    /// <summary>
    /// Get all Employees
    /// </summary>
    public void GetEmployees()
    {
      EmployeeViewModel vm = new EmployeeViewModel(false);

      vm.GetEmployees();
      Employees = vm.DataCollection;
    }
    #endregion

    #region PrepareForNew Method
    /// <summary>
    /// Call after entering a Time Sheet Entry to setup for a new one
    /// </summary>
    public void PrepareForNew()
    {
      Projects = new ObservableCollection<Project>();

      TaskDate = DateTime.Now.ToShortDateString();
      Hours = 1;
      Description = string.Empty;
      
      ValidationFailures.Clear();
      IsValidationAreaVisible = false;
    }
    #endregion

    #region Insert Method
    public void Insert()
    {
      TimeSheet entity = new TimeSheet();

      entity.CustomerId = SelectedCustomer.CustomerId;
      entity.ProjectId = SelectedProject.ProjectId;
      entity.EmployeeId = SelectedEmployee.EmployeeId;
      entity.Description = Description;
      entity.Hours = Hours;
      entity.TaskDate = Convert.ToDateTime(TaskDate);

      CreateServiceClient();

      if (UseAsync)
      {
        _Client.InsertCompleted += new EventHandler<InsertCompletedEventArgs>(client_InsertCompleted);
        _Client.InsertAsync(entity);
      }
#if !WINDOWS_PHONE && !SILVERLIGHT
      else
        InsertCompleted(_Client.Insert(entity));
#endif
    }

    void client_InsertCompleted(object sender, InsertCompletedEventArgs e)
    {
      InsertCompleted(e.Result);
    }

    private void InsertCompleted(TimeSheetResponse response)
    {
      if (response.Status == OperationResult.Success)
        MessageToDisplay = "Insert Successful";
      else if (response.Status == OperationResult.ValidationFailed)
      {
        IsValidationAreaVisible = true;
        MessageToDisplay = response.ErrorMessage;
        ValidationFailures = response.ValidationMessages;
      }
      else
        MessageToDisplay = response.ErrorMessage;

      IsMessageVisible = true;

      CloseServiceClient();

      if (response.Status == OperationResult.Success)
        PrepareForNew();
    }
    #endregion
  }
}
