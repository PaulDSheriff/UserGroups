﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common.Library;

using TimeTrack.EntityClasses;
#if WINDOWS_PHONE
using TimeTrack.ViewModels.WinPhone.CustomerServiceReference;
#endif
#if SILVERLIGHT && !WINDOWS_PHONE
using TimeTrack.ViewModels.Silverlight.CustomerServiceReference;
#endif
#if !WINDOWS_PHONE && !SILVERLIGHT
using TimeTrack.ViewModels.CustomerServiceReference;
#endif

namespace TimeTrack.ViewModels
{
	/// <summary>
	/// ViewModel class for working with the Customer view
	/// </summary>
  public class CustomerViewModel : ViewModelBase
  {
    #region Constructors
    /// <summary>
    /// The Constructor automatically calls the Init() method
    /// </summary>
    public CustomerViewModel()
      : base()
    {      
    }

    public CustomerViewModel(bool useAsync) : base(useAsync)
    {
    }
    #endregion

    #region Init Method
    public override void Init()
    {
      base.Init();

      MessageToDisplay = "Please wait while loading customers...";
    }
    #endregion

    #region Private Variables
    // WCF Service Client
    CustomerServicesClient _Client = null;

    private ObservableCollection<Customer> _DataCollection;
    private IEnumerable<Customer> _FilteredDataCollection;
    #endregion

    #region Public Properties
    public ObservableCollection<Customer> DataCollection 
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public IEnumerable<Customer> FilteredDataCollection
    {
      get { return _FilteredDataCollection; }
      set
      {
        _FilteredDataCollection = value;
        RaisePropertyChanged("FilteredDataCollection");
      }
    }
    #endregion

    #region CreateServiceClient Method
    private CustomerServicesClient CreateServiceClient()
    {
      _Client = new CustomerServicesClient();

      // Set any additional properties here

      return _Client;
    }
    #endregion

    #region CloseServiceClient Method
    private void CloseServiceClient()
    {
#if WINDOWS_PHONE || SILVERLIGHT
      _Client.CloseAsync();
#else
      _Client.Close();
#endif
    }
    #endregion

    #region GetCustomers Method
    public void GetCustomers()
    {
      // Reset View Model Variables
      IsNoRecordsVisible = false;

      CreateServiceClient();

      if (UseAsync)
      {
        _Client.GetCustomersCompleted += new EventHandler<GetCustomersCompletedEventArgs>(client_GetCustomersCompleted);
        _Client.GetCustomersAsync();
      }
#if !WINDOWS_PHONE && !SILVERLIGHT
      else
        GetCustomersCompleted(_Client.GetCustomers());
#endif
    }

    void client_GetCustomersCompleted(object sender, GetCustomersCompletedEventArgs e)
    {
      CustomerResponse response;

      response = (CustomerResponse)e.Result;

      GetCustomersCompleted(response);
    }

    private void GetCustomersCompleted(CustomerResponse response)
    {
      if (response.Status == OperationResult.Success)
      {
        DataCollection = response.DataCollection;
        FilteredDataCollection = DataCollection;
        IsMessageVisible = false;
      }
      else if (response.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No customers found.";
        IsNoRecordsVisible = true;
      }

      CloseServiceClient();
    }
    #endregion

    #region FilterCustomers Method
    public void FilterCustomers(string filter)
    {
      FilteredDataCollection = 
        from cust in DataCollection 
        where cust.CustomerName.ToLower().StartsWith(filter.ToLower()) 
        orderby cust.CustomerName 
        select cust;
    }
    #endregion
  }
}
