﻿Sample01 - Hard coded HTML page with all areas displayed
Sample02 - Handling UI state
           Add closure
           Only handles Add and Cancel
Sample03.html
           Handles all events
Sample04 - Call a Web API to get products.
           Use mustache data-binding to create HTML table
           Add products array in closure
Sample05 - Format the date and price
           Add toLocalDate and toCurrency functions
           Call these functions in mustache template
Sample06 - Get a Product
           Modify the get() function to call Web API
           Add product object in closure
           Reset product = {} in addClick()
           Modify the setPageElements() function to display product
Sample07 - Save a Product
           Create inputToObject() function
           Modify save() function to call inputToObject()
           Modify insertData() function to call Web API to add a new product
           Modify updateData() function to call Web API to update product
Sample08 - Delete a Product
           Modify deleteData() function to call Web API to delete a product
