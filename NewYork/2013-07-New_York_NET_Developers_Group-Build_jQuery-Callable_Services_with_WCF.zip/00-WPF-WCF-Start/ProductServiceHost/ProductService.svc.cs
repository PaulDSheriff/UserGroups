﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using ProductDataLayer;

namespace ProductServiceHost
{
  public class ProductService : IProductService
  {
    public List<Product> GetProducts()
    {
      ProductManager mgr = new ProductManager();

      return mgr.GetProducts();
    }

    public Product GetProduct(int productId)
    {
      ProductManager mgr = new ProductManager();

      return mgr.GetProduct(productId);
    }

    public int Insert(Product entity)
    {
      ProductManager mgr = new ProductManager();
       
      mgr.Insert(entity);

      return Convert.ToInt32(entity.ProductId);
    }

    public bool Update(Product entity)
    {
      ProductManager mgr = new ProductManager();

      return mgr.Update(entity);
    }

    public bool Delete(Product entity)
    {
      ProductManager mgr = new ProductManager();

      return mgr.Delete(entity);
    }
  }
}
