﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace ProductDataLayer
{
  public class ProductManager
  {
    #region GetProducts Method
    public List<Product> GetProducts()
    {
      List<Product> ret = new List<Product>();
      Product entity;
      SqlDataAdapter da;
      DataTable dt = new DataTable();

      da = new SqlDataAdapter("SELECT * FROM Product",
        AppSettings.Instance.ConnectString);

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows)
      {
        entity = new Product();

        entity.ProductId = Convert.ToInt32(dr["ProductId"]);
        entity.ProductName = dr["ProductName"].ToString();
        entity.IntroductionDate =
                DataConvert.ConvertTo<DateTime>(dr["IntroductionDate"],
                  default(DateTime));
        entity.Cost =
                DataConvert.ConvertTo<decimal>(dr["Cost"],
                  default(decimal));
        entity.Price =
                DataConvert.ConvertTo<decimal>(dr["Price"],
                  default(decimal));
        entity.IsDiscontinued =
                DataConvert.ConvertTo<bool>(dr["IsDiscontinued"],
                  default(bool));

        ret.Add(entity);
      }

      return ret;
    }
    #endregion

    #region GetProduct Method
    public Product GetProduct(int productId)
    {
      Product entity = new Product();
      SqlDataAdapter da;
      DataTable dt = new DataTable();
      SqlCommand cmd = null;
      DataRow dr;

      cmd = new SqlCommand("SELECT * FROM Product WHERE ProductId = @ProductId");
      cmd.Connection = new SqlConnection(AppSettings.Instance.ConnectString);
      cmd.Parameters.Add(new SqlParameter("ProductId", productId));

      da = new SqlDataAdapter(cmd);
      da.Fill(dt);

      if (dt.Rows.Count > 0)
      {
        dr = dt.Rows[0];

        entity.ProductId = Convert.ToInt32(dr["ProductId"]);
        entity.ProductName = dr["ProductName"].ToString();
        entity.IntroductionDate =
                DataConvert.ConvertTo<DateTime>(dr["IntroductionDate"],
                  default(DateTime));
        entity.Cost =
                DataConvert.ConvertTo<decimal>(dr["Cost"],
                  default(decimal));
        entity.Price =
                DataConvert.ConvertTo<decimal>(dr["Price"],
                  default(decimal));
        entity.IsDiscontinued =
                DataConvert.ConvertTo<bool>(dr["IsDiscontinued"],
                  default(bool));
      }

      return entity;
    }
    #endregion

    #region Update Method
    public bool Update(Product prod)
    {
      string sql = string.Empty;
      bool ret = false;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;

      sql = "UPDATE Product ";
      sql += " SET ";
      sql += " ProductName = @ProductName, ";
      sql += " IntroductionDate = @IntroductionDate, ";
      sql += " Cost = @Cost, ";
      sql += " Price = @Price, ";
      sql += " IsDiscontinued = @IsDiscontinued ";
      sql += " WHERE ProductId = @ProductId ";

      cnn = new SqlConnection(
         AppSettings.Instance.ConnectString);
      cmd = new SqlCommand(sql, cnn);
      parm = new SqlParameter("@ProductName",
        prod.ProductName);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@IntroductionDate",
        prod.IntroductionDate);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@Cost",
        prod.Cost);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@Price",
        prod.Price);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@IsDiscontinued",
        prod.IsDiscontinued);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@ProductId",
        prod.ProductId);
      cmd.Parameters.Add(parm);

      cnn.Open();
      cmd.ExecuteNonQuery();
      ret = true;

      cnn.Close();
      cnn.Dispose();
      cmd.Dispose();

      return ret;
    }
    #endregion

    #region Insert Method
    public bool Insert(Product prod)
    {
      string sql = string.Empty;
      bool ret = false;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;

      sql = "INSERT INTO Product(ProductName, ";
      sql += " IntroductionDate, Cost, Price, IsDiscontinued)";
      sql += " VALUES(@ProductName, @IntroductionDate, ";
      sql += " @Cost, @Price, @IsDiscontinued)";

      cnn = new SqlConnection(
           AppSettings.Instance.ConnectString);
      cmd = new SqlCommand(sql, cnn);
      parm = new SqlParameter("@ProductName",
        prod.ProductName);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@IntroductionDate",
        prod.IntroductionDate);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@Cost",
        prod.Cost);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@Price",
        prod.Price);
      cmd.Parameters.Add(parm);
      parm = new SqlParameter("@IsDiscontinued",
        prod.IsDiscontinued);
      cmd.Parameters.Add(parm);

      cnn.Open();
      cmd.ExecuteNonQuery();
      ret = true;

      // Retrieve Product ID
      cmd.Parameters.Clear();
      cmd.CommandText = "SELECT @@IDENTITY";
      prod.ProductId = Convert.ToInt32(cmd.ExecuteScalar());

      cnn.Close();
      cnn.Dispose();
      cmd.Dispose();

      return ret;
    }
    #endregion

    #region Delete Method
    public bool Delete(Product entity)
    {
      string sql = string.Empty;
      bool ret = false;
      SqlCommand cmd = null;
      SqlConnection cnn = null;
      SqlParameter parm = null;

      sql = "DELETE FROM Product ";
      sql += " WHERE ProductId = @ProductId ";

      cnn = new SqlConnection(
         AppSettings.Instance.ConnectString);
      cmd = new SqlCommand(sql, cnn);
      parm = new SqlParameter("@ProductId",
        entity.ProductId);
      cmd.Parameters.Add(parm);

      cnn.Open();
      cmd.ExecuteNonQuery();
      ret = true;

      cnn.Close();
      cnn.Dispose();
      cmd.Dispose();

      return ret;
    }
    #endregion
  }
}
