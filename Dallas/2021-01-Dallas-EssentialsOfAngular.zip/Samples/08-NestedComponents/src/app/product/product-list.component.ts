import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { PRODUCTS_MOCK } from './products-mock';

@Component({
  selector: 'ptc-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = PRODUCTS_MOCK;
  product: Product;
  message: string;

  constructor() { }

  ngOnInit(): void {
  }

  selectProduct(product: Product): void {
    this.product = product;
  }

  onSaved(isSaved: boolean): void {
    if (isSaved) {
      this.message = "Data was saved.";
      this.product = null;
    }
    else {
      this.message = "Data was NOT saved.";
    }
  }  
}
