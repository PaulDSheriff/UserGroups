import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ptc-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: any[] = [
    { productName: "Product 1" },
    { productName: "Product 2" },
    { productName: "Product 3" }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
