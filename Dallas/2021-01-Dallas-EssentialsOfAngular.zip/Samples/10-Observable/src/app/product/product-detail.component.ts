import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Product } from './product';
import { Category } from '../category/category';
import { CategoryService } from '../category/category.service';

@Component({
  selector: 'ptc-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  @Input() product: Product;
  @Output() saved: EventEmitter<boolean> = new EventEmitter<boolean>();
  categories: Category[] = [];
  
  constructor(private categoryService: CategoryService) { }

  ngOnInit(): void {
    this.getCategories();
  }

  private getCategories(): void {
    this.categoryService.getCategories()
    .subscribe(categories => this.categories = categories);
  }

  saveData() : void {
    this.saved.emit(true);
  }  
}
