import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { ProductService } from './product.service';

@Component({
  selector: 'ptc-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[];
  product: Product;
  message: string;

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.getProducts();
  }

  selectProduct(product: Product): void {
    this.product = product;
  }

  private getProducts(): void {
    this.products = this.productService.getProducts();
  }
  
  onSaved(isSaved: boolean): void {
    if (isSaved) {
      this.message = "Data was saved.";
      this.product = null;
    }
    else {
      this.message = "Data was NOT saved.";
    }
  }  
}
