import { Injectable } from '@angular/core';
import { Product } from './product';
import { PRODUCTS_MOCK } from './products-mock';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }

  getProducts(): Product[] {
    return PRODUCTS_MOCK;
  }  
}
