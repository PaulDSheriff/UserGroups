﻿import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { ProductService } from "./product.service";
import { Product } from "./product";

@Component({
  templateUrl: "./product-detail.component.html"
})
export class ProductDetailComponent implements OnInit {
  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private location: Location
  ) { }

  product: Product;
  messages: string[] = [];

  ngOnInit() {
    this.product = new Product();
    this.product.price = 1;
    this.product.url = "http://www.fairwaytech.com";
  }

  goBack() {
    this.location.back();
  }

  private handleErrors(errors: any) {
    this.messages = [];

    for (let msg of errors) {
      this.messages.push(msg);
    }
  }
}