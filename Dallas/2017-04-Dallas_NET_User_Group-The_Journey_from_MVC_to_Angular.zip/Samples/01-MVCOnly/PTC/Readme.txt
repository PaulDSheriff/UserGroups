﻿Create the Product table in a SQL Server database by running the script in the \SqlScripts folder.
Update the connection string in Web.config to point to your server and database name.