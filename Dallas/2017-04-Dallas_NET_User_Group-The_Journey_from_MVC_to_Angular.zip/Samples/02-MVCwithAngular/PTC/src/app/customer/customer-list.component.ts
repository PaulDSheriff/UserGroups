﻿import { Component } from "@angular/core";

@Component({
  templateUrl: "./customer-list.component.html"
})
export class CustomerListComponent { }
