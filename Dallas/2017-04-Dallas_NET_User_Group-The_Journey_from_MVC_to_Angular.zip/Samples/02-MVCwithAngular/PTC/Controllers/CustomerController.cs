﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace PTC.Controllers
{
  public class CustomerController : Controller
  {
    public ActionResult Customer() {
      return View();
    }
  }
}