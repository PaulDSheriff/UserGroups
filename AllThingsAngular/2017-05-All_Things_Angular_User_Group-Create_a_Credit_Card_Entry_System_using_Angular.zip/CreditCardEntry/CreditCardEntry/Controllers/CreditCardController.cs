﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using ViewModelLayer;

namespace CreditCardEntry.Controllers
{
  public class CreditCardController : ApiController
  {
    [HttpPost()]
    public IHttpActionResult Post(
       CreditCard card) {
      IHttpActionResult ret = null;
      CreditCardViewModel vm =
        new CreditCardViewModel();
      ModelStateDictionary Messages =
        new ModelStateDictionary();

      // Assign client-side credit card object 
      // to view model entity
      vm.Entity = card;

      // Attempt to save data
      vm.SaveData();
      if (vm.IsValid) {
        ret = Created<CreditCard>(
           Request.RequestUri +
             vm.Entity.CreditCardId.ToString(),
               vm.Entity);
      }
      else {
        if (vm.Messages.Count > 0) {
          // Validation errors
          foreach (var msgs in vm.Messages) {
            foreach (var item in msgs.ValidationErrors) {
              Messages.AddModelError(item.PropertyName,
                 item.ErrorMessage);
            }
          }

          ret = BadRequest(Messages);
        }
      }

      return ret;
    }
  }
}