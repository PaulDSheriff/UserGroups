﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ViewModelLayer;

namespace CreditCardEntry.Controllers
{
  public class CreditCardTypeController : ApiController
  {
    [Route("api/CreditCardType")]
    public IHttpActionResult Get() {
      IHttpActionResult ret = Ok();
      CreditCardViewModel vm = new CreditCardViewModel();

      try
      {
        vm.LoadCardTypes();
        if (vm.CardTypes.Count() > 0)
        {
          ret = Ok(vm.CardTypes);
        }
        else
        {
          ret = NotFound();
        }
      }
      catch (Exception ex)
      {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }

      return ret;
    }

  }
}