﻿import { Directive, forwardRef } from '@angular/core';
import { FormControl, NG_VALIDATORS, ValidatorFn } from '@angular/forms';

function notLowerCaseValidate(c: FormControl): ValidatorFn {
  let ret: any = null;

  if (c.value) {
    if (c.value.toString().trim() === c.value.toString().toLowerCase().trim()) {
      ret = { 'validateNotlowercase': c.value };
    }
  }

  return ret;
}

@Directive({
  selector: '[validateNotlowercase]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: forwardRef(() => NotLowerCaseValidatorDirective), multi: true }
  ]
})
export class NotLowerCaseValidatorDirective {
  validator: Function;

  constructor() {
    this.validator = notLowerCaseValidate;
  }

  validate(c: FormControl): { [key: string]: any } {
    return this.validator(c);
  }
}