﻿export class CreditCardType {
  cardTypeId: number;
  cardType: string;
  isActive: boolean;
}