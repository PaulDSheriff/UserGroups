﻿export class CreditCard {
  creditCardId: number;
  cardType: string;
  nameOnCard: string;
  cardNumber: string;
  securityCode: string;
  expMonth: number;
  expYear: number;
  billingPostalCode: string;
}