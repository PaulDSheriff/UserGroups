﻿import { Component, OnInit } from "@angular/core";
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
import { FormsModule, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

import { CreditCard } from "./creditcard";
import { CreditCardService } from "./creditcard.service";

import { CreditCardType } from "../creditcardtype/creditcardtype";
import { CreditCardTypeService } from "../creditcardtype/creditcardtype.service";
import { MonthInfo } from "../monthnames/monthinfo";
import { MonthNamesService } from "../monthnames/monthnames.service";
import { YearsService } from "../years/years.service";

@Component({
  templateUrl: "./creditcard.component.html"
})
export class CreditCardComponent implements OnInit {
  constructor(
    private creditCardService: CreditCardService,
    private creditCardTypeService: CreditCardTypeService,
    private monthNamesService: MonthNamesService,
    private yearsService: YearsService,
    private router: Router,
    private location: Location
  ) { }

  // Public properties
  creditCard: CreditCard;
  creditCardTypes: CreditCardType[] = [];
  monthNames: MonthInfo[] = [];
  years: number[] = [];
  isLoading: boolean = true;
  messages: string[] = [];
  theForm: FormControl;

  ngOnInit() {
    // Loading the page
    this.isLoading = true;

    // Initialize Credit Card
    this.creditCard = new CreditCard();
    this.initCreditCard();

    // Load Credit Card Types
    this.loadCreditCardTypes();

    // Load Month Names
    this.loadMonthNames();

    // Load Years
    this.loadYears();
  }
  
  private initCreditCard() {
    this.creditCard.nameOnCard = "";
    this.creditCard.cardNumber = "";
    this.creditCard.securityCode = "";
    this.creditCard.billingPostalCode = "";
  }

  goBack() {
    this.location.back();
  }

  save(creditCardForm: FormControl) {
    this.theForm = creditCardForm;
    if (creditCardForm.invalid) {
      creditCardForm.markAsTouched();
    }
    else {
      if (this.creditCard) {
        this.creditCardService.addCreditCard(this.creditCard)
          .subscribe(creditCard => this.dataSaved(),
          error => this.handleErrors(error));
      }
    }
  }

  private dataSaved() {
    this.messages = [];
    this.messages.push("Credit card has been saved...");
    // After 2 seconds, reinitialize the page
    setTimeout(() => {
      this.initCreditCard();
      this.theForm.markAsUntouched();
      this.theForm.markAsPristine();
      this.messages = [];

      // NOTE: Redirect if desired
      // this.goBack();
    }, 2000);
  }

  private loadCreditCardTypes() {
    this.creditCardTypeService.getCardTypes()
      .subscribe(cardTypes => this.creditCardTypes = cardTypes,
      errors => this.handleErrors(errors),
      () => {
        if (this.creditCardTypes.length > 0) {
          this.creditCard.cardType = this.creditCardTypes[0].cardType;
        }

        this.isLoading = false;
      });
  }

  private loadMonthNames() {
    this.monthNamesService.getMonthNames()
      .subscribe(names => this.monthNames = names,
      errors => this.handleErrors(errors),
      () => {
        this.creditCard.expMonth = new Date().getMonth() + 2;
      });
  }

  private loadYears() {
    this.yearsService.getYears()
      .subscribe(years => this.years = years,
      errors => this.handleErrors(errors),
      () => {
        this.creditCard.expYear = new Date().getFullYear() + 1;
      });
  }

  private handleErrors(errors: any): Observable<any> {
    this.isLoading = false;

    for (let msg of errors) {
      this.messages.push(msg);
    }

    return new Observable<any>();
  }
}