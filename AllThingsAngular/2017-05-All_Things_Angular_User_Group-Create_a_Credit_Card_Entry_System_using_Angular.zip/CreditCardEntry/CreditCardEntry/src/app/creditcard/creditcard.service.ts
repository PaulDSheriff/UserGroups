﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { CreditCard } from "./creditcard";

@Injectable()
export class CreditCardService {
  constructor(private http: Http) {
  }

  private url = "/api/creditcard";

  addCreditCard(creditCard: CreditCard): Observable<CreditCard> {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    return this.http.post(this.url, creditCard, options)
      .map(this.extractData)
      .catch(this.handleErrors);    
  }

  private extractData(res: Response) {
    let body = res.json();
    return body || {};
  }

  private handleErrors(error: any): Observable<any> {
    let errors: string[] = [];

    switch (error.status) {
      case 400:  // Model State Error
        let valErrors = error.json().modelState;
        for (var key in valErrors) {
          for (var i = 0; i < valErrors[key].length; i++) {
            errors.push(valErrors[key][i]);
          }
        }
        break;

      case 404: // Not Found
        errors.push("No Credit Card Data Is Available.");
        break;

      case 500: // Internal Error
        errors.push(error.json().exceptionMessage);
        break;

      default:
        errors.push("Status: " + error.status + " - Error Message: " + error.statusText);
        break;
    };

    console.error('An error occurred', errors);

    return Observable.throw(errors);
  }
}