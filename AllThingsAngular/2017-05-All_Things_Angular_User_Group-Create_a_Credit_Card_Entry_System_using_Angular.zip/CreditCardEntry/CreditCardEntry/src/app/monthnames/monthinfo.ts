﻿export class MonthInfo {
  monthNumber: number;
  monthName: string;
}