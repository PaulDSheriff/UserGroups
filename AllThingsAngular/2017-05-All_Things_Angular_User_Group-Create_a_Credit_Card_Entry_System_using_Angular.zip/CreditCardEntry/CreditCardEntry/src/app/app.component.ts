import { Component } from '@angular/core';

@Component({
  selector: "cc-app",
  templateUrl: "./app.component.html"
})
export class AppComponent { }
