﻿/****** Object:  Table [dbo].[CreditCard]    Script Date: 12/1/2016 4:56:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CreditCard](
	[CreditCardId] [uniqueidentifier] NOT NULL,
	[CardType] [varchar](20) NOT NULL,
	[NameOnCard] [varchar](100) NOT NULL,
	[CardNumber] [varchar](25) NOT NULL,
	[SecurityCode] [varchar](4) NOT NULL,
	[ExpMonth] [smallint] NOT NULL,
	[ExpYear] [smallint] NOT NULL,
	[BillingPostalCode] [varchar](10) NOT NULL,
 CONSTRAINT [PK_CreditCard] PRIMARY KEY CLUSTERED 
(
	[CreditCardId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[CreditCardType]    Script Date: 12/1/2016 4:56:43 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CreditCardType](
	[CardTypeId] [int] IDENTITY(1,1) NOT NULL,
	[CardType] [varchar](20) NOT NULL,
	[IsActive] [bit] NOT NULL
) ON [PRIMARY]

GO
SET IDENTITY_INSERT [dbo].[CreditCardType] ON 

GO
INSERT [dbo].[CreditCardType] ([CardTypeId], [CardType], [IsActive]) VALUES (1, N'Visa', 1)
GO
INSERT [dbo].[CreditCardType] ([CardTypeId], [CardType], [IsActive]) VALUES (2, N'Master Card', 1)
GO
INSERT [dbo].[CreditCardType] ([CardTypeId], [CardType], [IsActive]) VALUES (3, N'American Express', 1)
GO
INSERT [dbo].[CreditCardType] ([CardTypeId], [CardType], [IsActive]) VALUES (4, N'Discover', 1)
GO
INSERT [dbo].[CreditCardType] ([CardTypeId], [CardType], [IsActive]) VALUES (5, N'Diners Club', 1)
GO
SET IDENTITY_INSERT [dbo].[CreditCardType] OFF
GO
/****** Object:  Index [PK__CreditCa__AB0A3D10B02826C4]    Script Date: 12/1/2016 4:56:43 PM ******/
ALTER TABLE [dbo].[CreditCardType] ADD PRIMARY KEY NONCLUSTERED 
(
	[CardTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CreditCardType] ADD  DEFAULT ((1)) FOR [IsActive]
GO
