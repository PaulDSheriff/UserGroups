﻿To run this sample you need to...
- Create a database in a SQL Server
- Run the \SqlScripts\PTC.SQL in that database
- Modify the connection string in the Web.Config

\src\index.html - The starting page


\src\app\creditcard Folder
---------------------------------------------------------------------------------------
creditcard.controller.js - Controller for credit card entry
creditcard.directives.js - Customer directives for validation
creditcard.html - HTML for credit card page
  NOTE: Do NOT use *ngIf="isLoading" around input fields that you need for validation



Credit Card Information
------------------------------------------------------------
Visa and Visa Electron Credit Cards
  13 or 16 digits
Mastercard and Discover Credit Cards
  16 digits
American Express Credit Cards
  15 digits
Diner's Club
  14 digits