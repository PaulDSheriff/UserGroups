﻿using Newtonsoft.Json.Serialization;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace CreditCardEntry
{
  public class WebApiApplication : System.Web.HttpApplication
  {
    protected void Application_Start()
    {
      // Register Web API Routes
      GlobalConfiguration.Configure(WebApiConfig.Register);

      // Get Global Configuration
      HttpConfiguration config =
          GlobalConfiguration.Configuration;

      // Convert to camelCase
      var jsonFormatter = config.Formatters
        .OfType<JsonMediaTypeFormatter>()
          .FirstOrDefault();

      jsonFormatter.SerializerSettings
        .ContractResolver = new
           CamelCasePropertyNamesContractResolver();
    }
  }
}
