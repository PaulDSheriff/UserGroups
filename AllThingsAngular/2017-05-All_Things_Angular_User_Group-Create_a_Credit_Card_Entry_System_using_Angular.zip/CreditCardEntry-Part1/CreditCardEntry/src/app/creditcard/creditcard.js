"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CreditCard = (function () {
    function CreditCard() {
    }
    return CreditCard;
}());
exports.CreditCard = CreditCard;
//# sourceMappingURL=creditcard.js.map