"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var Observable_1 = require("rxjs/Observable");
var router_1 = require("@angular/router");
var creditcard_1 = require("./creditcard");
var creditcard_service_1 = require("./creditcard.service");
var creditcardtype_service_1 = require("../creditcardtype/creditcardtype.service");
var monthnames_service_1 = require("../monthnames/monthnames.service");
var years_service_1 = require("../years/years.service");
var CreditCardComponent = (function () {
    function CreditCardComponent(creditCardService, creditCardTypeService, monthNamesService, yearsService, router, location) {
        this.creditCardService = creditCardService;
        this.creditCardTypeService = creditCardTypeService;
        this.monthNamesService = monthNamesService;
        this.yearsService = yearsService;
        this.router = router;
        this.location = location;
        this.creditCardTypes = [];
        this.monthNames = [];
        this.years = [];
        this.isLoading = true;
        this.messages = [];
    }
    CreditCardComponent.prototype.ngOnInit = function () {
        // Loading the page
        this.isLoading = true;
        // Initialize Credit Card
        this.creditCard = new creditcard_1.CreditCard();
        this.initCreditCard();
        // Load Credit Card Types
        this.loadCreditCardTypes();
        // Load Month Names
        this.loadMonthNames();
        // Load Years
        this.loadYears();
    };
    CreditCardComponent.prototype.initCreditCard = function () {
        this.creditCard.nameOnCard = "";
        this.creditCard.cardNumber = "";
        this.creditCard.securityCode = "";
        this.creditCard.billingPostalCode = "";
    };
    CreditCardComponent.prototype.goBack = function () {
        this.location.back();
    };
    CreditCardComponent.prototype.save = function (creditCardForm) {
        var _this = this;
        this.theForm = creditCardForm;
        if (creditCardForm.invalid) {
            creditCardForm.markAsTouched();
        }
        else {
            if (this.creditCard) {
                this.creditCardService.addCreditCard(this.creditCard)
                    .subscribe(function (creditCard) { return _this.dataSaved(); }, function (error) { return _this.handleErrors(error); });
            }
        }
    };
    CreditCardComponent.prototype.dataSaved = function () {
        var _this = this;
        this.messages = [];
        this.messages.push("Credit card has been saved...");
        // After 2 seconds, reinitialize the page
        setTimeout(function () {
            _this.initCreditCard();
            _this.theForm.markAsUntouched();
            _this.theForm.markAsPristine();
            _this.messages = [];
            // NOTE: Redirect if desired
            // this.goBack();
        }, 2000);
    };
    CreditCardComponent.prototype.loadCreditCardTypes = function () {
        var _this = this;
        this.creditCardTypeService.getCardTypes()
            .subscribe(function (cardTypes) { return _this.creditCardTypes = cardTypes; }, function (errors) { return _this.handleErrors(errors); }, function () {
            if (_this.creditCardTypes.length > 0) {
                _this.creditCard.cardType = _this.creditCardTypes[0].cardType;
            }
            _this.isLoading = false;
        });
    };
    CreditCardComponent.prototype.loadMonthNames = function () {
        var _this = this;
        this.monthNamesService.getMonthNames()
            .subscribe(function (names) { return _this.monthNames = names; }, function (errors) { return _this.handleErrors(errors); }, function () {
            _this.creditCard.expMonth = new Date().getMonth() + 2;
        });
    };
    CreditCardComponent.prototype.loadYears = function () {
        var _this = this;
        this.yearsService.getYears()
            .subscribe(function (years) { return _this.years = years; }, function (errors) { return _this.handleErrors(errors); }, function () {
            _this.creditCard.expYear = new Date().getFullYear() + 1;
        });
    };
    CreditCardComponent.prototype.handleErrors = function (errors) {
        this.isLoading = false;
        for (var _i = 0, errors_1 = errors; _i < errors_1.length; _i++) {
            var msg = errors_1[_i];
            this.messages.push(msg);
        }
        return new Observable_1.Observable();
    };
    return CreditCardComponent;
}());
CreditCardComponent = __decorate([
    core_1.Component({
        templateUrl: "./creditcard.component.html"
    }),
    __metadata("design:paramtypes", [creditcard_service_1.CreditCardService,
        creditcardtype_service_1.CreditCardTypeService,
        monthnames_service_1.MonthNamesService,
        years_service_1.YearsService,
        router_1.Router,
        common_1.Location])
], CreditCardComponent);
exports.CreditCardComponent = CreditCardComponent;
//# sourceMappingURL=creditcard.component.js.map