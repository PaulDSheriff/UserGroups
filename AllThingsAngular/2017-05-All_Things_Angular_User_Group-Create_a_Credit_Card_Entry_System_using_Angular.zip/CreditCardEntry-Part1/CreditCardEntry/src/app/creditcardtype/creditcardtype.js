"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CreditCardType = (function () {
    function CreditCardType() {
    }
    return CreditCardType;
}());
exports.CreditCardType = CreditCardType;
//# sourceMappingURL=creditcardtype.js.map