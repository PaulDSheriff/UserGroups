"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CREDIT_CARD_TYPES_MOCK = [
    {
        cardTypeId: 1,
        cardType: "Visa",
        isActive: true
    },
    {
        cardTypeId: 2,
        cardType: "American Express",
        isActive: true
    },
    {
        cardTypeId: 3,
        cardType: "Master Card",
        isActive: true
    }
];
//# sourceMappingURL=mock-creditcardtypes.js.map