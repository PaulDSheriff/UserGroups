﻿import { CreditCardType } from "./creditcardtype";

export const CREDIT_CARD_TYPES_MOCK: CreditCardType[] = [
  {
    cardTypeId: 1,
    cardType: "Visa",
    isActive: true
  },
  {
    cardTypeId: 2,
    cardType: "American Express",
    isActive: true
  },
  {
    cardTypeId: 3,
    cardType: "Master Card",
    isActive: true
  }
];