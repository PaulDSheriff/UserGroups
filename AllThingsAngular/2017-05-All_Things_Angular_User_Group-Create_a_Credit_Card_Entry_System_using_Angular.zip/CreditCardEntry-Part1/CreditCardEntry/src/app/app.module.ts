import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreditCardComponent } from "./creditcard/creditcard.component";

// Register Services for DI
import { CreditCardService } from "./creditcard/creditcard.service";
import { CreditCardTypeService } from "./creditcardtype/creditcardtype.service";
import { MonthNamesService } from "./monthnames/monthnames.service";
import { YearsService } from "./years/years.service";

@NgModule({
  imports: [BrowserModule, FormsModule, AppRoutingModule],
  declarations: [AppComponent, CreditCardComponent],
  bootstrap: [AppComponent],
  providers: [CreditCardService, CreditCardTypeService, MonthNamesService, YearsService]
})
export class AppModule { }
