"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MonthInfo = (function () {
    function MonthInfo() {
    }
    return MonthInfo;
}());
exports.MonthInfo = MonthInfo;
//# sourceMappingURL=monthinfo.js.map