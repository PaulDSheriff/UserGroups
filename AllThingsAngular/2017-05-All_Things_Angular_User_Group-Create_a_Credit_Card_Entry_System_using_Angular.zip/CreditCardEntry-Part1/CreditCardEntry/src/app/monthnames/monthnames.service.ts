﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/observable/of';

import { MonthInfo } from "./monthinfo";
import { MONTH_NAMES_MOCK } from "./mock-monthnames";

@Injectable()
export class MonthNamesService {
  getMonthNames(): Observable<MonthInfo[]> {
    return Observable.of(MONTH_NAMES_MOCK);
  }

  private handleErrors(error: any): Observable<any> {
    let errors: string[] = [];

    switch (error.status) {
      case 404: // Not Found
        errors.push("No Month Names are Available.");
        break;

      case 500: // Internal Error
        errors.push(error.json().exceptionMessage);
        break;

      default:
        errors.push("Status: " + error.status + " - Error Message: " + error.statusText);
        break;
    };

    console.error('An error occurred', errors);

    return Observable.throw(errors);
  }
}