﻿using Newtonsoft.Json.Serialization;
using System.Linq;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace CreditCardEntry
{
  public class WebApiApplication : System.Web.HttpApplication
  {
    protected void Application_Start()
    {
     
    }
  }
}
