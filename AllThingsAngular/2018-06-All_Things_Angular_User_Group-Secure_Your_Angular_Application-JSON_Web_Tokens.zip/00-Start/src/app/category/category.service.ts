import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { Category } from './category';
import { CATEGORIES_MOCK } from './category-mock';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor() { }

  getCategories(): Observable<Category[]> {
    return of<Category[]>(CATEGORIES_MOCK);
  }  
}
