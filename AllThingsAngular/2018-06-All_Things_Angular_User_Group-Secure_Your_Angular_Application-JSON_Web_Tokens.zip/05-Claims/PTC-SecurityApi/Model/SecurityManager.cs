using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using PtcApi.Model;

namespace PtcApi.Security
{
  public class SecurityManager
  {
    private JwtSettings _settings;
    public SecurityManager(JwtSettings settings)
    {
      _settings = settings;
    }

    public AppUserAuth AuthenticateUser(AppUser user)
    {
      AppUserAuth ret = new AppUserAuth();
      AppUser authUser = null;

      using (var db = new PtcDbContext())
      {
        // Attempt to validate user
        authUser = db.Users.Where(
          u => u.UserName.ToLower()
               == user.UserName.ToLower()
            && u.Password
               == user.Password).FirstOrDefault();
      }

      if (authUser != null)
      {
        // Build User Security Object
        ret = BuildUserAuthObject(authUser);
      }

      return ret;
    }

    protected List<AppUserClaim>
      GetUserClaims(AppUser authUser)
    {
      List<AppUserClaim> list = new List<AppUserClaim>();

      using (var db = new PtcDbContext())
      {
        list = db.Claims.Where(
               u => u.UserId == authUser.UserId).ToList();
      }

      return list;
    }

    protected AppUserAuth BuildUserAuthObject(AppUser authUser)
    {
      AppUserAuth ret = new AppUserAuth();
      List<AppUserClaim> claims = new List<AppUserClaim>();

      // Get all claims for this user
      ret.Claims = GetUserClaims(authUser);

      // Set User Properties
      ret.UserName = authUser.UserName;
      ret.IsAuthenticated = true;

      // Build JWT Token
      ret.BearerToken = BuildJwtToken(ret, ret.Claims);

      return ret;
    }

    protected string BuildJwtToken(AppUserAuth authUser, List<AppUserClaim> claims)
    {
      SymmetricSecurityKey key = new SymmetricSecurityKey(
        Encoding.UTF8.GetBytes(_settings.Key));

      // Create standard JWT claims
      List<Claim> jwtClaims = new List<Claim>();
      jwtClaims.Add(new Claim(JwtRegisteredClaimNames.Sub,
          authUser.UserName));
      jwtClaims.Add(new Claim(JwtRegisteredClaimNames.Jti,
          Guid.NewGuid().ToString()));

      // Create a JWT Claim for each user claim
      foreach (var item in claims)
      {
        jwtClaims.Add(new Claim(item.ClaimType, item.ClaimValue));
      }

      // Create the JwtSecurityToken object
      var token = new JwtSecurityToken(
        issuer: _settings.Issuer,
        audience: _settings.Audience,
        claims: jwtClaims,
        notBefore: DateTime.UtcNow,
        expires: DateTime.UtcNow.AddMinutes(
            _settings.MinutesToExpiration),
        signingCredentials: new SigningCredentials(key,
                    SecurityAlgorithms.HmacSha256)
      );

      // Create a string representation of the Jwt token
      return new JwtSecurityTokenHandler().WriteToken(token);
    }
  }
}
