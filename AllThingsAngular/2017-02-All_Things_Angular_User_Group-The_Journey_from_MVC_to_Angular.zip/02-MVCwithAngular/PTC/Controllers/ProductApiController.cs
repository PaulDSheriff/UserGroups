﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PTC.Controllers
{
  public class ProductApiController : ApiController
  {
    public IHttpActionResult Get() {
      IHttpActionResult ret;
      ProductViewModel vm = new ProductViewModel();

      // Uncomment the following to test error handling
      // throw new ApplicationException("A BAD ERROR");
      
      vm.LoadProducts();
      if (vm.Products.Count() > 0) {
        ret = Ok(vm.Products);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }
  }
}