﻿import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { Product } from "./product";
import { ProductService } from "./product.service";

@Component({
  moduleId: module.id,
  templateUrl: "./product-detail.component.html"
})
export class ProductDetailComponent implements OnInit {
  product: Product;
  messages: string[] = [];

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private location: Location
  ) { }


  ngOnInit(): void {
    this.product = new Product();
  }

  goBack(): void {
    this.location.back();
  }

  editProduct(product: Product) {

  }

  addProduct(product: Product) {
    this.productService.addProduct(product)
      .subscribe(() => this.goBack(),
      errors => this.handleErrors(errors));
  }

  saveProduct(): void {
    if (this.product) {
      if (this.product.productId) {
        this.editProduct(this.product);
      }
      else {
        this.addProduct(this.product);
      }
    }
  }

  handleErrors(errors: any): void {
    for (let msg of errors) {
      this.messages.push(msg);
    }
  }
}
