﻿import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { Product } from "./product";
import { ProductService } from "./product.service";

@Component({
  moduleId: module.id,
  templateUrl: "./product-detail.component.html"
})
export class ProductDetailComponent {
  product: Product;
  messages: string[] = [];

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.route.params.forEach((params: Params) => {
      if (params['id'] !== undefined) {
        let id = +params['id'];
        if (id && id.toString() != "-1") {
          this.productService.getProduct(id)
            .subscribe(product => this.product = product);
        }
        else {
          this.product = new Product();
          this.product.price = 1;
          this.product.url = "http://www.fairwaytech.com";
        }
      }
    });
  }

  goBack(): void {
    this.location.back();
  }

  addProduct(product: Product) {
    this.productService.addProduct(product)
      .subscribe(() => this.goBack(),
      errors => this.handleErrors(errors));
  }

  editProduct(product: Product) {
    this.productService.updateProduct(product)
      .subscribe(() => this.goBack(),
      errors => this.handleErrors(errors));
  }

  saveProduct(): void {
    if (this.product) {
      if (this.product.productId) {
        this.editProduct(this.product);
      }
      else {
        this.addProduct(this.product);
      }
    }
  }

  handleErrors(errors: any): void {
    for (let msg of errors) {
      this.messages.push(msg);
    }
  }
}
