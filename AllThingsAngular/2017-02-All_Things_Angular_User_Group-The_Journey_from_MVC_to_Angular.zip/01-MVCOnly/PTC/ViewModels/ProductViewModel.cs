﻿using System;
using System.Collections.Generic;
using PTC.Models;
using System.Linq;
using System.Data.Entity.Validation;
using System.Data.Entity;

namespace PTC
{
  public class ProductViewModel
  {
    #region Constructor
    public ProductViewModel() {
      Products = new List<Product>();
      LastException = null;
      Entity = new Product();
      Messages = new List<KeyValuePair<string, string>>();
      EventAction = string.Empty;
      EventArgument = string.Empty;
      PageMode = PDSAPageModeEnum.List;
      IsValid = true;
    }
    #endregion

    #region Public Properties
    public List<Product> Products { get; set; }
    public Exception LastException { get; set; }
    public Product Entity { get; set; }
    public List<KeyValuePair<string, string>> Messages { get; set; }
    public string EventAction { get; set; }
    public string EventArgument { get; set; }
    public PDSAPageModeEnum PageMode { get; set; }
    public bool IsValid { get; set; }
    #endregion

    #region HandleRequest Method
    public void HandleRequest() {
      // Make sure we have a valid event command
      EventAction = (EventAction == null ? "" : EventAction.ToLower());

      IsValid = true;
      Messages = new List<KeyValuePair<string, string>>();
      switch (EventAction) {
        case "add":
          PageMode = PDSAPageModeEnum.Add;
          break;

        case "edit":
          PageMode = PDSAPageModeEnum.Edit;
          GetProduct(Convert.ToInt32(EventArgument));
          break;

        case "cancel":
          PageMode = PDSAPageModeEnum.List;
          break;

        case "save":
          if (Entity.ProductId <= 0) {
            Insert(Entity);
          }
          else {
            Update(Entity);
          }
          break;

        case "delete":
          Delete(Convert.ToInt32(EventArgument));
          break;
      }

      if (PageMode == PDSAPageModeEnum.List) {
        LoadProducts();

        if (PageMode == PDSAPageModeEnum.List) {
          if (Products.Count == 0) {
            Messages.Add(new KeyValuePair<string, string>("Products", "No Product Data Found."));
          }
        }
      }
    }
    #endregion

    #region LoadProducts Method
    public void LoadProducts() {
      PTCData db = new PTCData();

      Products = db.Products.ToList();
    }
    #endregion

    #region GetProduct Method
    public Product GetProduct(int id) {
      PTCData db = new PTCData();

      Entity = db.Products.Find(id);

      return Entity;
    }
    #endregion

    #region Insert Method
    public bool Insert(Product product) {
      PTCData db = null;

      IsValid = false;
      Entity = product;
      try {
        db = new PTCData();

        // Insert the new entity
        db.Products.Add(Entity);
        db.SaveChanges();

        IsValid = true;
        PageMode = PDSAPageModeEnum.List;
      }
      catch (DbEntityValidationException ex) {
        ValidationErrorsToMessages(ex);
      }
      catch (Exception ex) {
        LastException = ex;
      }

      return IsValid;
    }
    #endregion

    #region Update Method
    public bool Update(Product product) {
      PTCData db = null;

      IsValid = false;
      Entity = product;
      try {
        db = new PTCData();

        // Update the product
        db.Entry(Entity).State = EntityState.Modified;
        db.SaveChanges();

        IsValid = true;
        PageMode = PDSAPageModeEnum.List;
      }
      catch (DbEntityValidationException ex) {
        ValidationErrorsToMessages(ex);
      }
      catch (Exception ex) {
        LastException = ex;
      }

      return IsValid;
    }
    #endregion

    #region Delete Method
    public bool Delete(int id) {
      bool ret = false;
      PTCData db = null;

      try {
        db = new PTCData();

        // Get the product
        Product product = db.Products.Find(id);

        // Delete the product
        db.Products.Remove(product);
        db.SaveChanges();

        ret = true;
      }
      catch (Exception ex) {
        LastException = ex;
      }

      return ret;
    }
    #endregion

    #region ValidationErrorsToMessages Method
    protected void ValidationErrorsToMessages(DbEntityValidationException ex) {
      foreach (DbEntityValidationResult result in ex.EntityValidationErrors) {
        foreach (DbValidationError item in result.ValidationErrors) {
          Messages.Add(new KeyValuePair<string, string>(item.PropertyName, item.ErrorMessage));
        }
      }
    }
    #endregion
  }
}
