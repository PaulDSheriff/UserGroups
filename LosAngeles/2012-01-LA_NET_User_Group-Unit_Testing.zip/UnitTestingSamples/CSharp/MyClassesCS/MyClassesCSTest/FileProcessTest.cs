﻿using MyClassesCS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace MyClassesCSTest
{


  /// <summary>
  ///This is a test class for FileProcessTest and is intended
  ///to contain all FileProcessTest Unit Tests
  ///</summary>
  [TestClass()]
  public class FileProcessTest
  {


    private TestContext testContextInstance;

    /// <summary>
    ///Gets or sets the test context which provides
    ///information about and functionality for the current test run.
    ///</summary>
    public TestContext TestContext
    {
      get
      {
        return testContextInstance;
      }
      set
      {
        testContextInstance = value;
      }
    }

    #region Additional test attributes
    // 
    //You can use the following additional attributes as you write your tests:
    //
    //Use ClassInitialize to run code before running the first test in the class
    [ClassInitialize()]
    public static void MyClassInitialize(TestContext testContext)
    {
      System.IO.File.AppendAllText(@"D:\Test.txt", "Some Content");
    }
    
    //Use ClassCleanup to run code after all tests in a class have run
    [ClassCleanup()]
    public static void MyClassCleanup()
    {
      System.IO.File.Delete(@"D:\Test.txt");
    }
    //
    //Use TestInitialize to run code before running each test
    //[TestInitialize()]
    //public void MyTestInitialize()
    //{
    //}
    //
    //Use TestCleanup to run code after each test has run
    //[TestCleanup()]
    //public void MyTestCleanup()
    //{
    //}
    //
    #endregion


    /// <summary>
    ///A test for FileExists
    ///</summary>
    [TestMethod()]
    public void FileExistsTest()
    {
      FileProcess target = new FileProcess(); // TODO: Initialize to an appropriate value
      string FileName = string.Empty; // TODO: Initialize to an appropriate value
      bool expected = false; // TODO: Initialize to an appropriate value
      bool actual;
      actual = target.FileExists(FileName);
      Assert.AreEqual(expected, actual, "Test: " + TestContext.TestName + " failed");
    }

    [TestMethod()]
    public void FileExistsTestSimple()
    {
      FileProcess fp = new FileProcess();

      Assert.IsTrue(fp.FileExists(@"D:\Test.txt"), "Test: " + TestContext.TestName + " failed");
    }

    /// <summary>
    ///A test for FileExistsWithException
    ///</summary>
    [TestMethod(), ExpectedException(typeof(System.ArgumentNullException))]
    public void FileExistsWithExceptionTest()
    {
      FileProcess target = new FileProcess(); // TODO: Initialize to an appropriate value
      string FileName = string.Empty; // TODO: Initialize to an appropriate value
      bool expected = false; // TODO: Initialize to an appropriate value
      bool actual;
      actual = target.FileExistsWithException(FileName);
      Assert.AreEqual(expected, actual, "Test: " + TestContext.TestName + " failed");
    }

    [TestMethod()]
    [DataSource("System.Data.SqlClient", 
       "Server=Localhost;Database=Sandbox;Integrated Security=SSPI", 
       "FileProcessTest", 
       DataAccessMethod.Sequential)] 
    public void FileExistsFromDB()
    {
      FileProcess target = new FileProcess();
      string fileName;
      bool expected;

      fileName = TestContext.DataRow["FileName"].ToString();
      expected = System.Convert.ToBoolean(TestContext.DataRow["ExpectedValue"]);

      Assert.AreEqual(expected, target.FileExists(fileName), 
        "File Name: " + fileName + " has failed it's existence test in test: FileExistsFromDB()");
    }

    [TestMethod()]
    [DataSource("Sandbox")]
    public void FileExistsFromDBConfig()
    {
      FileProcess target = new FileProcess();
      string fileName;
      bool expected;

      fileName = TestContext.DataRow["FileName"].ToString();
      expected = System.Convert.ToBoolean(TestContext.DataRow["ExpectedValue"]);

      Assert.AreEqual(expected, target.FileExists(fileName),
        "File Name: " + fileName + " has failed it's existence test in test: FileExistsFromDB()");
    }
  }
}
