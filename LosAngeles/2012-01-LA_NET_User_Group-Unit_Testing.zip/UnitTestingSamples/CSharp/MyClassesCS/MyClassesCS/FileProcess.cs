﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace MyClassesCS
{
  public class FileProcess
  {
    public bool FileExists(string fileName)
    {
      return File.Exists(fileName);
    }

    public bool FileExistsWithException(string fileName)
    {
      if (string.IsNullOrEmpty(fileName))
      {
        throw new
          ArgumentNullException("fileName");
      }
      else
      {
        return File.Exists(fileName);
      }
    }
  }
}
