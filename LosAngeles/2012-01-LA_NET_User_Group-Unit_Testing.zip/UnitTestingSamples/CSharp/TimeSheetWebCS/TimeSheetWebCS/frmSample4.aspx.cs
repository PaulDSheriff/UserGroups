﻿using System;
using System.Web.UI;

using TimeSheetComponentsCS;

namespace TimeSheetWebCS
{
  public partial class frmSample4 : System.Web.UI.Page
  {
    #region Loading Methods
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        ResourcesLoad();
        CustomersLoad();
        txtEntryDate.Text = DateTime.Now.ToShortDateString();
      }
    }

    private void ResourcesLoad()
    {
      Resources res = new Resources();

      ddlResource.DataTextField = "Name";
      ddlResource.DataValueField = "Name";
      ddlResource.DataSource = res.GetResources();
      ddlResource.DataBind();
    }

    private void CustomersLoad()
    {
      Customers cust = new Customers();

      ddlCustomer.DataTextField = "Name";
      ddlCustomer.DataValueField = "Name";
      ddlCustomer.DataSource = cust.GetCustomers();
      ddlCustomer.DataBind();
    }
    #endregion

    #region Saving Methods
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (ValidateData())
      {
        lblMessage.Text = "Data is Valid";
      }
    }

    private bool ValidateData()
    {
      TimeSheetValidator timeValidator = new TimeSheetValidator();
      TimeSheetData timeData = new TimeSheetData();

      timeData.Resource = ddlResource.Text;
      timeData.EntryDate = txtEntryDate.Text;
      timeData.Customer = ddlCustomer.Text;
      timeData.Hours = txtHours.Text;
      timeData.Description = txtDescription.Text;

      if (!timeValidator.ValidateData(timeData))
      {
        lblMessage.Text = timeValidator.MessagesForWebDisplay;
      }

      return (timeValidator.Messages == string.Empty);
    }
    #endregion
  }
}