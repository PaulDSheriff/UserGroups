﻿using System;
using System.Web.UI;

using TimeSheetComponentsCS;

namespace TimeSheetWebCS
{
  public partial class frmSample3 : System.Web.UI.Page
  {
    #region Loading Methods
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        ResourcesLoad();
        CustomersLoad();
        txtEntryDate.Text = DateTime.Now.ToShortDateString();
      }
    }

    private void ResourcesLoad()
    {
      Resources res = new Resources();

      ddlResource.DataTextField = "Name";
      ddlResource.DataValueField = "Name";
      ddlResource.DataSource = res.GetResources();
      ddlResource.DataBind();
    }

    private void CustomersLoad()
    {
      Customers cust = new Customers();

      ddlCustomer.DataTextField = "Name";
      ddlCustomer.DataValueField = "Name";
      ddlCustomer.DataSource = cust.GetCustomers();
      ddlCustomer.DataBind();
    }
    #endregion

    #region Saving Methods
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (ValidateData())
      {
        lblMessage.Text = "Data is Valid";
      }
    }

    private bool ValidateData()
    {
      TimeSheetSample3 time3 = new TimeSheetSample3();

      if (!time3.ValidateData(ddlResource.SelectedItem.Text,
          txtEntryDate.Text,
          ddlCustomer.SelectedItem.Text,
          txtHours.Text,
          txtDescription.Text))
      {
        lblMessage.Text = time3.MessagesForWebDisplay;
      }

      return (time3.Messages == string.Empty);
    }
    #endregion
  }
}