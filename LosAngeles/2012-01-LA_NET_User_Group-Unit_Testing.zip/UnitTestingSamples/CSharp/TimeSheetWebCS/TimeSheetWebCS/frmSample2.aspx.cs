﻿using System;
using System.Web.UI;

using TimeSheetComponentsCS;

namespace TimeSheetWebCS
{
  public partial class frmSample2 : System.Web.UI.Page
  {
    private string _Messages = string.Empty;
    private TimeSheetSample2 _Time2 = new TimeSheetSample2();

    #region Loading Methods
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        ResourcesLoad();
        CustomersLoad();
        txtEntryDate.Text = DateTime.Now.ToShortDateString();
      }
    }

    private void ResourcesLoad()
    {
      Resources res = new Resources();

      ddlResource.DataTextField = "Name";
      ddlResource.DataValueField = "Name";
      ddlResource.DataSource = res.GetResources();
      ddlResource.DataBind();
    }

    private void CustomersLoad()
    {
      Customers cust = new Customers();

      ddlCustomer.DataTextField = "Name";
      ddlCustomer.DataValueField = "Name";
      ddlCustomer.DataSource = cust.GetCustomers();
      ddlCustomer.DataBind();
    }
    #endregion

    #region Saving Methods
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (ValidateData())
      {
        lblMessage.Text = "Data is Valid";
      }
      else
      {
        lblMessage.Text = _Messages.Replace(Environment.NewLine, "<br />");
      }
    }

    private bool ValidateData()
    {
      decimal value = 0;

      _Messages = string.Empty;

      // **********************************************
      //  Move values from form into TimeSheet Class
      // **********************************************
      if (ddlResource.SelectedItem.Text == Resource.UnSelected)
      {
        _Messages += "You must choose a Resource." + Environment.NewLine;
      }
      if (!Utilities.IsDate(txtEntryDate.Text))
      {
        _Messages += "Entry Date must be a valid date." + Environment.NewLine;
      }
      if (ddlCustomer.SelectedItem.Text == Customer.UnSelected)
      {
        _Messages += "You must choose a Customer." + Environment.NewLine;
      }
      //  Make sure hours entered are decimal values
      if (decimal.TryParse(txtHours.Text, out value) == false)
      {
        _Messages += "Hours must be in decimal format." + Environment.NewLine;
      }

      if (_Messages == string.Empty)
      {
        _Time2.Customer = ddlCustomer.SelectedItem.Text;
        _Time2.Description = txtDescription.Text;
        _Time2.EntryDate = Convert.ToDateTime(txtEntryDate.Text);
        _Time2.Hours = Convert.ToDecimal(txtHours.Text);
        _Time2.Resource = ddlResource.SelectedItem.Text;
        _Time2.ValidateData();
        _Messages = _Time2.Messages;
      }

      return (_Messages == string.Empty);
    }
    #endregion
  }
}