﻿using System.Windows;

using TimeSheetComponentsCS;

namespace TimeSheetWPFCS
{
  public partial class winTimeSheetSample4 : Window
  {
    public winTimeSheetSample4()
    {
      InitializeComponent();
    }

    private TimeSheetValidator _timeValidator = new TimeSheetValidator();

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (ValidateData())
      {
        MessageBox.Show("Data is Valid");
      }
      else
      {
        MessageBox.Show(_timeValidator.Messages);
      }
    }

    private bool ValidateData()
    {
      // **************************************************
      //  Move values from form into TimeSheetData Class
      // **************************************************
      TimeSheetData timeData;

      timeData = (TimeSheetData)ucTime.DataContext;

      return (_timeValidator.ValidateData(timeData)); 
    }

    #region Cancel Method
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }
    #endregion
  }
}