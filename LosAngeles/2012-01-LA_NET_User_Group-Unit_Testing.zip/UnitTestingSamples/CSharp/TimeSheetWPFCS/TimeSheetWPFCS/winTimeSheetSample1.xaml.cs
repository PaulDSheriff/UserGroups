﻿using System;
using System.Windows;

using TimeSheetComponentsCS;

namespace TimeSheetWPFCS
{
  public partial class winTimeSheetSample1 : Window
  {
    public winTimeSheetSample1()
    {
      InitializeComponent();
    }

    #region Support Methods
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      ResourcesLoad();
      CustomersLoad();
    }

    private void ResourcesLoad()
    {
      Resources res = new Resources();

      cboResource.DataContext = res.GetResources();
      cboResource.SelectedIndex = 0;
    }

    private void CustomersLoad()
    {
      Customers cust = new Customers();

      cboCustomer.DataContext = cust.GetCustomers();
      cboCustomer.SelectedIndex = 0;
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }
    #endregion

    private string _Messages = string.Empty;

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (ValidateData())
      {
        MessageBox.Show("Data is Valid");
      }
      else
      {
        MessageBox.Show(_Messages);
      }
    }

    private bool ValidateData()
    {
      decimal value = 0;

      _Messages = string.Empty;

      //  User Must Enter a Resource
      if (cboResource.SelectedIndex <= 0)
      {
        _Messages += "You must choose a Resource." +
          Environment.NewLine;
      }
      // Check to see if value entered is a date
      if (Utilities.IsDate(txtEntryDate.Text))
      {
        //  Entry Date must not be older than 7 days
        if (Convert.ToDateTime(txtEntryDate.Text) <
          (DateTime.Now.Subtract(new TimeSpan(7, 0, 0, 0))))
        {
          _Messages += "Entry Date must be greater than 7 days ago" +
            Environment.NewLine;
        }
        //  Entry Date Must Be Today's Date or Less
        if (Convert.ToDateTime(txtEntryDate.Text) > DateTime.Now)
        {
          _Messages += "Entry Date must today's date or less" +
            Environment.NewLine;
        }
      }
      else
        _Messages += "Entry Date must be a valid date." + Environment.NewLine;

      //  User Must Enter a Customer
      if (cboCustomer.SelectedIndex <= 0)
      {
        _Messages += "You must choose a Customer." +
          Environment.NewLine;
      }
      //  Make sure hours entered are decimal values
      if (decimal.TryParse(txtHours.Text, out value) == false)
      {
        _Messages += "Hours must be in decimal format." +
          Environment.NewLine;
      }
      else
      {
        //  Hours must be greater than 0
        if (value <= 0)
        {
          _Messages += "Hours must be greater than zero." +
            Environment.NewLine;
        }
        //  Hours must be less than 12
        if (value > 12)
        {
          _Messages += "Hours must be less than 12." +
            Environment.NewLine;
        }
      }
      //  User Must Enter a Description
      if (txtDescription.Text.Trim() == string.Empty)
      {
        _Messages += "Description must be entered." +
          Environment.NewLine;
      }
      else
      {
        //  Description length must be greater than 10 characters
        if (txtDescription.Text.Trim().Length < 10)
        {
          _Messages += "Description entered must be greater than 10 characters." + Environment.NewLine;
        }
      }

      return (_Messages == string.Empty);
    }
  }
}