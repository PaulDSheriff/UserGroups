﻿using System.Windows;

using TimeSheetComponentsCS;

namespace TimeSheetWPFCS
{
  public partial class winTimeSheetSample3 : Window
  {
    #region Constructor
    public winTimeSheetSample3()
    {
      InitializeComponent();
    }
    #endregion

    #region Windows Loaded and Cancel Event Procedures
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _TimeValidator = (TimeSheetSample3)this.FindResource("time3");
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }
    #endregion

    private TimeSheetSample3 _TimeValidator = new TimeSheetSample3();

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (ValidateData())
      {
        MessageBox.Show("Data is Valid");
      }
      else
      {
        MessageBox.Show(_TimeValidator.Messages);
      }
    }

    private bool ValidateData()
    {
      // ******************************************************
      //  Move values manually from form into TimeSheet Class
      //  as string values
      // ******************************************************
      return (_TimeValidator.ValidateData(cboResource.Text, txtEntryDate.Text,
        cboCustomer.Text, txtHours.Text, txtDescription.Text));
    }
  }
}