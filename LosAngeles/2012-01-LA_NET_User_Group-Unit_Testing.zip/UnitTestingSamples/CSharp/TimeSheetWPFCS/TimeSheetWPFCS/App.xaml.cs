﻿using System.Windows;

namespace TimeSheetWPFCS
{
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
  }
}
