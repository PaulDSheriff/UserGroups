﻿using System.Windows;

namespace TimeSheetWPFCS
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    private void btnTime1_Click(object sender, RoutedEventArgs e)
    {
      winTimeSheetSample1 win = new winTimeSheetSample1();

      win.Show();
    }

    private void btnTime2_Click(object sender, RoutedEventArgs e)
    {
      winTimeSheetSample2 win = new winTimeSheetSample2();

      win.Show();
    }

    private void btnTime3_Click(object sender, RoutedEventArgs e)
    {
      winTimeSheetSample3 win = new winTimeSheetSample3();

      win.Show();
    }

    private void btnTime4_Click(object sender, RoutedEventArgs e)
    {
      winTimeSheetSample4 win = new winTimeSheetSample4();

      win.Show();
    }
  }
}
