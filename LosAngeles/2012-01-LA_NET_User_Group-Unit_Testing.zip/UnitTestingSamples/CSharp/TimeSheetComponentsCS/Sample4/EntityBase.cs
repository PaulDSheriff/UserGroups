﻿using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace TimeSheetComponentsCS
{
  /// <summary>
  /// This is an abstract class from which "Entity" classes inherit.
  /// </summary>
  public abstract class EntityBase : INotifyPropertyChanged
  {
    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
      {
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
      }
    }
    #endregion
  }
}
