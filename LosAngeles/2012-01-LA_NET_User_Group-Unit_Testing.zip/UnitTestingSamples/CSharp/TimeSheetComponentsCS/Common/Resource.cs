﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace TimeSheetComponentsCS
{
  public class Resource
  {
    #region Constructors
    public Resource()
    {
      Name = string.Empty;
    }

    public Resource(string name)
    {
      Name = name;
    }
    #endregion

    public string Name { get; set; }

    public static string UnSelected
    {
      get { return "[Select]"; }
    }
  }

  public class Resources : List<Resource>
  {
    public Resources GetResources()
    {
      Resources ret = new Resources();

      try
      {
        var xElem = XElement.Load(Utilities.GetCurrentDirectory() +
                                   @"\Xml\Resource.xml");

        // Get All Resources
        var items = from item in xElem.Descendants("Resource")
                    select item;

        // Build Collection
        foreach (var item in items)
          ret.Add(new Resource(item.Element("Name").Value));
      }
      catch (Exception ex)
      {
        ret.Add(new Resource("RESOURCE 1"));
      }

      return ret;
    }
  }
}
