MVC Basics
-------------------------------------
Sample 1 - Action Links
Sample 2 - @Url.Action
Sample 3 - Anchor Tag Helper
Sample 4 - Partial Page
Sample 5 - Custom Page Styles
Sample 6 - JavaScript
Sample 7 - Configuration Settings
