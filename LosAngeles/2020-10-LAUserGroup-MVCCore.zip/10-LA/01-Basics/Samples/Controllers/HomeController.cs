﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MVCBasics.Models;

namespace MVCBasics.Controllers
{
  public class HomeController : Controller
  {
    private readonly ILogger<HomeController> _logger;
    private readonly IConfiguration _config;
    public string CompanyName { get; set; }
    public string ContactName { get; set; }

    public HomeController(ILogger<HomeController> logger, IConfiguration config)
    {
      _logger = logger;
      _config = config;
    }

    public IActionResult Index()
    {
      return View();
    }

    public IActionResult Sample01() => View();
    public IActionResult Sample02() => View();
    public IActionResult Sample03() => View();
    public IActionResult Sample04() => View();
    public IActionResult Sample05() => View();
    public IActionResult Sample06() => View();
    public IActionResult Sample07()
    {
      CompanyName = _config.GetValue<string>("MVCBasics:CompanyName");
      ContactName = _config.GetValue<string>("MVCBasics:ContactName");

      return View(this);
    }

    public IActionResult Privacy()
    {
      return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}
