using System;
using System.Collections.Generic;
using System.Linq;
using MVCDataLayer;
using MVCEntityLayer;

namespace MVCViewModelLayer {
  public class ProductViewModel {
    /// <summary>
    ///  NOTE: You need to have a parameterless constructor for Post-Backs in MVC    
    /// </summary>
    public ProductViewModel() {
    }

    public ProductViewModel(IProductRepository repository) {
      Repository = repository;
    }

    public ProductViewModel(IProductRepository repository, IColorRepository colorRepo) {
      Repository = repository;
      ColorRepository = colorRepo;
    }
    public IProductRepository Repository { get; set; }
    public IColorRepository ColorRepository { get; set; }
    public List<Product> Products { get; set; }
    public Product SelectedProduct { get; set; }
    public List<Color> Colors { get; set; }

    public virtual void LoadProducts() {
      if (Repository == null) {
        throw new ApplicationException("Must set the Repository property.");
      } else {
        Products = Repository.Get().OrderBy(p => p.Name).ToList();
      }
    }

    public virtual void LoadProduct(int id) {
      SelectedProduct = Repository.Get(id);
      
      LoadColors();
    }

    public virtual void LoadColors() {
      if (ColorRepository == null) {
        Colors = new List<Color>();
      } else {
        Colors = ColorRepository.Get();
      }
    }
  }
}