using System.Collections.Generic;
using System.Linq;
using MVCDataLayer;
using MVCEntityLayer;

namespace MVCViewModelLayer
{
  public class ColorViewModel
  {
    /// <summary>
    ///  NOTE: You need to have a parameterless constructor for Post-Backs in MVC    
    /// </summary>
    public ColorViewModel()
    {
    }

    public ColorViewModel(IColorRepository repository)
    {
      Repository = repository;
    }

    public IColorRepository Repository { get; set; }
    public List<Color> Colors { get; set; }
    public Color SelectedColor { get; set; }

    public virtual void LoadColors()
    {
      Colors = Repository.Get().OrderBy(p => p.ColorName).ToList();
    }

    public void LoadColor(int id)
    {
      SelectedColor = Repository.Get(id);
    }
  }
}