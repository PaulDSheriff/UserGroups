using System.Collections.Generic;
using MVCEntityLayer;

namespace MVCDataLayer
{
  public interface IColorRepository
  {
    List<Color> Get();
    Color Get(int id);
  }
}