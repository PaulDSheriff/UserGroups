using System.Collections.Generic;
using System.Linq;
using MVCEntityLayer;

namespace MVCDataLayer
{
  public partial class ColorRepository : IColorRepository
  {
    public virtual Color Get(int id) {
      return Get().Where(c => c.ColorId == id).FirstOrDefault();  
    }

    public virtual List<Color> Get()
    {
      return new List<Color> {
        new Color {
          ColorId = 1,
          ColorName = "Red",
          IsActive = true
        },
          new Color {
          ColorId = 2,
          ColorName = "Blue",
          IsActive = true
        },
          new Color {
          ColorId = 3,
          ColorName = "Green",
          IsActive = true
        },
          new Color {
          ColorId = 4,
          ColorName = "Yellow",
          IsActive = false
        },
          new Color {
          ColorId = 5,
          ColorName = "Grey",
          IsActive = true
        },
          new Color {
          ColorId = 6,
          ColorName = "Black",
          IsActive = true
        },
      };
    }
  }
}