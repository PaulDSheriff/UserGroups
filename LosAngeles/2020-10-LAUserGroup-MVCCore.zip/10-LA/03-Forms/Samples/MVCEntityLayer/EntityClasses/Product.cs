using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace MVCEntityLayer
{
  public partial class Product
  {
    [HiddenInput]
    public int ProductID { get; set; }
    [Display(Name = "Is Active?")]
    public bool IsActive { get; set; }
    [Display(Name = "Product Name")]
    public string Name { get; set; }
    [Display(Name = "Product Number")]
    public string ProductNumber { get; set; }
    public string Color { get; set; }
    [Display(Name = "Cost")]
    public decimal StandardCost { get; set; }
    [Display(Name = "Price")]
    public decimal ListPrice { get; set; }
    public string Size { get; set; }
    public decimal? Weight { get; set; }
    [Display(Name = "Start Selling Date")]
    public DateTime SellStartDate { get; set; }
    [Display(Name = "End Selling Date")]
    public DateTime? SellEndDate { get; set; }
    [Display(Name = "Date Discontinued")]
    public DateTime? DiscontinuedDate { get; set; }
  }
}