﻿using Microsoft.AspNetCore.Mvc;
using MVCDataLayer;
using MVCViewModelLayer;

namespace MVCBasics.Controllers {
  public class FormsController : Controller
  {
    public FormsController(IProductRepository productRepo,
                           IColorRepository colorRepo)
    {
      _productRepository = productRepo;
      _colorRepository = colorRepo;
    }

    private IProductRepository _productRepository;
    private IColorRepository _colorRepository;

    public IActionResult Sample01()
    {
      ProductViewModel vm = new ProductViewModel(_productRepository);

      vm.LoadProduct(706);

      return View(vm);
    }

    [HttpPost]
    public IActionResult Sample01(ProductViewModel vm)
    {
      System.Diagnostics.Debugger.Break();
      vm.Repository = _productRepository;

      return View(vm);
    }
  }
}
