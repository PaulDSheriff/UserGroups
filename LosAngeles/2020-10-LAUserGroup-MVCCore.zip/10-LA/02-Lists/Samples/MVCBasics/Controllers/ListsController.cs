﻿using Microsoft.AspNetCore.Mvc;
using MVCDataLayer;
using MVCViewModelLayer;

namespace MVCBasics.Controllers {
  public class ListsController : Controller {
    public ListsController(IProductRepository productRepo) {
      _productRepository = productRepo;
    }

    private IProductRepository _productRepository;

    public IActionResult Sample01() {
      ProductViewModel vm = new ProductViewModel(_productRepository);

      vm.LoadProducts();

      return View(vm);
    }

    public IActionResult Sample02() {
      ProductViewModel vm = new ProductViewModel(_productRepository);

      vm.LoadProducts();

      return View(vm);
    }
  }
}
