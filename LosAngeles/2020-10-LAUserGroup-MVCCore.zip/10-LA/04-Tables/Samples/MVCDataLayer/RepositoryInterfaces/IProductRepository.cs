using System.Collections.Generic;
using MVCEntityLayer;

namespace MVCDataLayer
{
  public interface IProductRepository
  {
    List<Product> Get();
    Product Get(int id);
    List<Product> Search(ProductSearch search);
  }
}