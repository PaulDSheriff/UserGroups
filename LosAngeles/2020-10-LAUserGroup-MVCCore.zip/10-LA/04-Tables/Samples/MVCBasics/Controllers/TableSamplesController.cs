using Microsoft.AspNetCore.Mvc;
using MVCDataLayer;
using MVCViewModelLayer;

namespace MVCBasics.Controllers
{
  public class TableSamplesController : Controller
  {
    public TableSamplesController(IProductRepository productRepo)
    {
      _productRepository = productRepo;
    }

    private IProductRepository _productRepository;

    public IActionResult Sample01()
    {
      ProductViewModel vm = new ProductViewModel(_productRepository);

      vm.LoadProducts();

      return View(vm);
    }
  }
}
