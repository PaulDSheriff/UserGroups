Passing Data
-------------------------------------
Sample 1 - ViewData
Sample 2 - ViewBag
Sample 3 - TempData
Sample 4 - Query Strings