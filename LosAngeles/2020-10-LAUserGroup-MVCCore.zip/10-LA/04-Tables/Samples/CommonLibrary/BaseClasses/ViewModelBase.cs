namespace CommonLibrary
{
  public class ViewModelBase
  {
    public ViewModelBase()
    {
      EventCommand = string.Empty;
      EventArgument = string.Empty;
    }

    public string EventCommand { get; set; }
    public string EventArgument { get; set; }

    public virtual void HandleRequest()
    {
    }
  }
}