using Microsoft.AspNetCore.Mvc;
using MVCDataLayer;
using MVCViewModelLayer;

namespace MVCBasics.Controllers
{
  public class ProductMaintenanceController : Controller
  {
    public ProductMaintenanceController(IProductRepository productRepo)
    {
      _productRepository = productRepo;
    }

    private IProductRepository _productRepository;

    public IActionResult ProductMaintenance()
    {
      ProductViewModel vm = new ProductViewModel(_productRepository);

      // Load all products
      vm.EventCommand = "load";
      // Call HandleRequest to process event command
      vm.HandleRequest();

      return View(vm);
    }

    [HttpPost]
    public IActionResult ProductMaintenance(ProductViewModel vm)
    {
      vm.Repository = _productRepository;
      vm.HandleRequest();

      ModelState.Clear();

      return View(vm);
    }
  }
}
