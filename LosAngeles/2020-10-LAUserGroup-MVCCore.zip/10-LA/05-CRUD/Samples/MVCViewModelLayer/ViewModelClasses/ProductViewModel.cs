using System;
using System.Collections.Generic;
using System.Linq;
using MVCDataLayer;
using MVCEntityLayer;
using CommonLibrary;

namespace MVCViewModelLayer
{
  public class ProductViewModel : ViewModelBase
  {
    /// <summary>
    ///  NOTE: You need to have a parameterless constructor for Post-Backs in MVC    
    /// </summary>
    public ProductViewModel()
    {
    }

    public ProductViewModel(IProductRepository repository)
    {
      Repository = repository;
    }

    public IProductRepository Repository { get; set; }
    public List<Product> Products { get; set; }
    public Product SelectedProduct { get; set; }
    
    public override void HandleRequest()
    {
      switch (EventCommand.ToLower())
      {
         case "load":
          LoadProducts();
          break;

        case "add":
          CreateEmptyProduct();
          IsDetailVisible = true;
          break;

        case "edit":
          LoadProduct(Convert.ToInt32(EventArgument));
          IsDetailVisible = true;
          break;

        case "save":
          if (Save())
          {
            LoadProducts();
            IsDetailVisible = false;
          }
          break;

        case "delete":
          DeleteProduct(Convert.ToInt32(EventArgument));
          LoadProducts();
          break;

        case "cancel":
          LoadProducts();
          IsDetailVisible = false;
          break;

        default:
          LoadProducts();
          break;
      }
    }

    protected virtual bool Save()
    {
      if (SelectedProduct.ProductID.HasValue)
      {
        // Editing an existing product
        Repository.Update(SelectedProduct);
      }
      else
      {
        // Adding a new product
        Repository.Add(SelectedProduct);
      }

      return true;
    }

    protected virtual bool DeleteProduct(int id)
    {
      Repository.Delete(id);

      // Clear EventArgument so it does not interfere with paging
      EventArgument = string.Empty;

      return true;
    }

    protected virtual void CreateEmptyProduct()
    {
      SelectedProduct = Repository.CreateEmpty();
    }

    protected virtual void LoadProducts()
    {
      if (Repository == null)
      {
        throw new ApplicationException("Must set the Repository property.");
      }
      else
      {
        Products = Repository.Get().OrderBy(p => p.Name).ToList();
      }
    }

    protected virtual void LoadProduct(int id)
    {
      SelectedProduct = Repository.Get(id);
    }
  }
}