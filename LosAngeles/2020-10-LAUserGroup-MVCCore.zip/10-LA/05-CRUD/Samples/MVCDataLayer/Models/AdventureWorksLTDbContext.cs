using Microsoft.EntityFrameworkCore;
using MVCEntityLayer;

namespace MVCDataLayer
{
  public partial class AdventureWorksLTDbContext : DbContext
  {
    public virtual DbSet<Product> Products { get; set; }
   
    private const string CONN = @"Server=Localhost;Database=AdventureWorksLT;Trusted_Connection=True;MultipleActiveResultSets=true;Application Name=MVCBasics";

    protected override void OnConfiguring(
      DbContextOptionsBuilder optionsBuilder)
    {
      optionsBuilder.UseSqlServer(CONN);
    }
  }
}
