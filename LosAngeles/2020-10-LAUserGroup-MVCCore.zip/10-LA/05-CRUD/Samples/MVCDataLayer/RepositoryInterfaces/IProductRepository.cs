using System.Collections.Generic;
using MVCEntityLayer;

namespace MVCDataLayer
{
  public interface IProductRepository
  {
    List<Product> Get();
    Product Get(int id);
    Product CreateEmpty();
    Product Add(Product entity);
    Product Update(Product entity);
    bool Delete(int id);
  }
}