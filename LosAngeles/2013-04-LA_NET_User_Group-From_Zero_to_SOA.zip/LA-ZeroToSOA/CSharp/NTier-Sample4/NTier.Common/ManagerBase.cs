﻿using System;
using System.Runtime.Serialization;

namespace NTier.Common
{
  public class ManagerBase
  {
    #region Constructors
    public ManagerBase()
    {
      RowsAffected = 0;
      SQL = string.Empty;
      Message = string.Empty;
      ConnectString = string.Empty;
    }

    public ManagerBase(string connectString)
    {
      RowsAffected = 0;
      SQL = string.Empty;
      Message = string.Empty;
      ConnectString = connectString;
    }
    #endregion

    public int RowsAffected { get; set; }

    public string SQL { get; set; }

    public string Message { get; set; }

    public string ConnectString { get; set; }
  }
}
