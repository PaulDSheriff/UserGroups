﻿using System.Configuration;

namespace NTier_Sample1
{
  public class AppConfig
  {
    public static string ConnectString
    {
      get { return ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString; }
    }
  }
}
