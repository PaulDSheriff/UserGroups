﻿Imports System.Collections.Generic
Imports System.Data
Imports NTier.Data.Library
Imports NTier.EntityClasses
Imports NTier.Common

Public Class PersonManager
#Region "Constructors"
  Public Sub New()
  End Sub

  Public Sub New(ByVal connectString__1 As String)
    ConnectString = connectString__1
  End Sub
#End Region

#Region "Public Properties"
  Public Property ConnectString() As String
    Get
      Return m_ConnectString
    End Get
    Set(ByVal value As String)
      m_ConnectString = value
    End Set
  End Property
  Private m_ConnectString As String
  Public Property Message() As String
    Get
      Return m_Message
    End Get
    Set(ByVal value As String)
      m_Message = value
    End Set
  End Property
  Private m_Message As String
#End Region

#Region "GetPersons Method"
  Public Function GetPersons() As List(Of Person)
    Dim ret As New List(Of Person)()
    Dim entity As Person
    Dim dt As DataTable
    Dim sql As String = String.Empty

    Message = String.Empty

    sql = "SELECT PersonId, FirstName, LastName, EmailAddress "
    sql += " FROM Person "
    sql += " ORDER BY LastName "
    Try
      dt = DataLayer.GetDataTable(sql, ConnectString)

      For Each dr As DataRow In dt.Rows
        entity = New Person()

        entity.PersonId = Convert.ToInt32(dr("PersonId"))
        entity.FirstName = dr("FirstName").ToString()
        entity.LastName = dr("LastName").ToString()
        entity.EmailAddress = dr("EmailAddress").ToString()

        ret.Add(entity)
      Next
    Catch ex As Exception
      Message = ex.Message
    End Try

    Return ret
  End Function
#End Region

#Region "GetPerson Method"
  Public Function GetPerson(ByVal personId As Integer) As Person
    Dim entity As New Person()
    Dim dt As New DataTable()
    Dim sql As String = String.Empty
    Dim cmd As IDbCommand = Nothing
    Dim dr As DataRow

    Message = String.Empty

    sql = "SELECT PersonId, FirstName, LastName, EmailAddress "
    sql += " FROM Person "
    sql += " WHERE PersonId = @PersonId"
    Try
      cmd = DataLayer.CreateCommand(sql)
      cmd.Connection = DataLayer.CreateConnection(ConnectString)
      cmd.Parameters.Add(DataLayer.CreateParameter("@PersonId", personId))
      dt = DataLayer.GetDataTable(cmd)
      If dt.Rows.Count > 0 Then
        dr = dt.Rows(0)

        entity.PersonId = Convert.ToInt32(dr("PersonId"))
        entity.FirstName = dr("FirstName").ToString()
        entity.LastName = dr("LastName").ToString()
        entity.EmailAddress = dr("EmailAddress").ToString()
      End If
    Catch ex As Exception
      Message = ex.Message
      entity.Message = Message
    End Try

    Return entity
  End Function
#End Region

#Region "UpdatePerson Method"
  Public Function UpdatePerson(ByVal entity As Person) As Integer
    Dim ret As Integer = 0
    Dim sql As String = String.Empty
    Dim cmd As IDbCommand = Nothing


    Message = String.Empty
    entity.Message = String.Empty

    sql = "UPDATE Person "
    sql += " SET FirstName = @FirstName, "
    sql += "     LastName = @LastName, "
    sql += "     EmailAddress = @EmailAddress"
    sql += " WHERE PersonId = @PersonId"
    Try
      ' Validate the Data
      ' Raises an exception if there are errors.
      Validate(entity)

      cmd = DataLayer.CreateCommand(sql)
      cmd.Connection = DataLayer.CreateConnection(ConnectString)
      cmd.Parameters.Add(DataLayer.CreateParameter("@FirstName", entity.FirstName))
      cmd.Parameters.Add(DataLayer.CreateParameter("@LastName", entity.LastName))
      cmd.Parameters.Add(DataLayer.CreateParameter("@EmailAddress", entity.EmailAddress))
      cmd.Parameters.Add(DataLayer.CreateParameter("@PersonId", entity.PersonId))

      ret = DataLayer.ExecuteSQL(cmd)
    Catch ex As ValidationException
      Message = ex.Message
      entity.Message = Message

    Catch ex As Exception
      Message = ex.Message
      entity.Message = Message
    Finally
      If cmd IsNot Nothing Then
        If cmd.Connection IsNot Nothing Then
          cmd.Connection.Close()
          cmd.Connection.Dispose()
          cmd.Dispose()
        End If
      End If
    End Try

    Return ret
  End Function
#End Region

#Region "Validate Method"
  Private Sub Validate(entity As Person)
    Dim msg As String = String.Empty

    If entity.FirstName.Trim() = String.Empty Then
      msg &= "First Name must be filled in." + Environment.NewLine
    End If
    If entity.LastName.Trim() = String.Empty Then
      msg &= "Last Name must be filled in." + Environment.NewLine
    End If
    If entity.EmailAddress.Trim() = String.Empty Then
      msg &= "Email Address must be filled in." + Environment.NewLine
    End If

    If msg <> String.Empty Then
      Throw New ValidationException(msg)
    End If
  End Sub
#End Region
End Class