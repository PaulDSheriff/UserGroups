﻿Imports System.Windows

Imports NTier.DataClasses
Imports NTier.EntityClasses

Class MainWindow
  Inherits Window
  Private _Manager As PersonManager = Nothing

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    _Manager = New PersonManager(AppConfig.ConnectString)

    lstData.DataContext = _Manager.GetPersons()

    
    If _Manager.Message <> String.Empty Then
      tbMessage.Text = _Manager.Message
    End If
  End Sub

  Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If lstData.SelectedIndex >= 0 Then
      _Manager.UpdatePerson(DirectCast(lstData.SelectedItem, Person))
      If _Manager.Message <> String.Empty Then
        tbMessage.Text = _Manager.Message
      End If
    End If
  End Sub
End Class