﻿Imports System.Data
Imports System.Data.SqlClient

Public Class DataLayer
#Region "GetDataSet Methods"
  Public Shared Function GetDataSet(ByVal sql As String, ByVal connectString As String) As DataSet
    Dim cmd As SqlCommand = Nothing
    Dim cnn As SqlConnection = Nothing

    '  Create Command Object
    cmd = New SqlCommand(sql)
    '  Create Connection Object
    cnn = New SqlConnection(connectString)
    '  Assign Connection to Command Object
    cmd.Connection = cnn

    '  Call Overloaded GetDataSet method
    Return GetDataSet(cmd)
  End Function

  Public Shared Function GetDataSet(ByVal cmd As IDbCommand) As DataSet
    Dim ds As New DataSet()
    Dim da As SqlDataAdapter = Nothing

    '  Create Data Adapter
    da = New System.Data.SqlClient.SqlDataAdapter(DirectCast(cmd, SqlCommand))
    da.Fill(ds)
    cmd.Connection.Close()
    cmd.Connection.Dispose()

    Return ds
  End Function
#End Region

#Region "GetDataTable Methods"
  Public Shared Function GetDataTable(ByVal sql As String, ByVal connectString As String) As DataTable
    Return GetDataSet(sql, connectString).Tables(0)
  End Function

  Public Shared Function GetDataTable(ByVal cmd As IDbCommand) As DataTable
    Return GetDataSet(cmd).Tables(0)
  End Function
#End Region

#Region "ExecuteSQL Methods"
  Public Shared Function ExecuteSQL(ByVal cmd As IDbCommand) As Integer
    Dim ret As Integer = 0

    If cmd.Connection.State = ConnectionState.Closed Then
      cmd.Connection.Open()
    End If

    ret = cmd.ExecuteNonQuery()
    cmd.Connection.Close()
    cmd.Connection.Dispose()

    Return ret
  End Function

  Public Shared Function ExecuteSQL(ByVal sql As String, ByVal connectString As String) As Integer
    Dim cmd As SqlCommand = Nothing
    Dim ret As Integer = 0

    '  Create Command Object
    cmd = New SqlCommand(sql)
    ' Create Connection Object
    cmd.Connection = New SqlConnection(connectString)
    ' Open Connection
    cmd.Connection.Open()

    '  Execute SQL
    ret = ExecuteSQL(cmd)

    ' Close & Dispose of Connection
    cmd.Connection.Close()
    cmd.Connection.Dispose()

    Return ret
  End Function
#End Region

#Region "'Create' methods"
  Public Shared Function CreateCommand(ByVal sql As String) As SqlCommand
    Return New SqlCommand(sql)
  End Function

  Public Shared Function CreateConnection(ByVal connectString As String) As SqlConnection
    Return New SqlConnection(connectString)
  End Function

  Public Shared Function CreateParameter(ByVal name As String, ByVal value As Object) As SqlParameter
    Return New SqlParameter(name, value)
  End Function
#End Region
End Class