Imports System.Collections.Generic
Imports System.Runtime.Serialization

Imports NTier.Common
Imports NTier.EntityClasses

<DataContract()> _
  Public Class PersonResponse
  Inherits ResponseBase



  <DataMember()> _
  Public Property DetailData() As Person
    Get
      Return m_DetailData
    End Get
    Set(ByVal value As Person)
      m_DetailData = value
    End Set
  End Property
  Private m_DetailData As Person

  <DataMember()> _
  Public Property DataCollection() As List(Of Person)
    Get
      Return m_DataCollection
    End Get
    Set(ByVal value As List(Of Person))
      m_DataCollection = value
    End Set
  End Property
  Private m_DataCollection As List(Of Person)
End Class