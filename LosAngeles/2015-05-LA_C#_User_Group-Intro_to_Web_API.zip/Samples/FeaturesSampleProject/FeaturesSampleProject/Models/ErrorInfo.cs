﻿namespace FeaturesSampleProject.Models
{
   /// <summary>
   /// Custom error information for
   /// exception handling
   /// </summary>
   public class ErrorInfo
   {
      public string FriendlyMessage { get; set; }
      public string RequestedUrl { get; set; }
      public string SystemMessage { get; set; }
   }
}