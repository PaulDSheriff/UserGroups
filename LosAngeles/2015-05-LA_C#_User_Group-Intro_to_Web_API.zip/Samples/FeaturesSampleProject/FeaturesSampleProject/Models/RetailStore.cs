﻿using System.Collections.Generic;

namespace FeaturesSampleProject.Models
{
   /// <summary>
   /// 
   /// </summary>
   public class RetailStore
   {
      /// <summary>
      /// 
      /// </summary>
      public RetailStore()
      {
         this.Features = new List<string>();
      }

      /// <summary>
      /// 
      /// </summary>
      public string BusinessName { get; set; }

      /// <summary>
      /// 
      /// </summary>
      public string StreetAddress { get; set; }

      /// <summary>
      /// 
      /// </summary>
      public string UnitAddress { get; set; }

      /// <summary>
      /// 
      /// </summary>
      public string City { get; set; }

      /// <summary>
      /// 
      /// </summary>
      public string StateProvince { get; set; }

      /// <summary>
      /// 
      /// </summary>
      public string PostalCode { get; set; }

      /// <summary>
      /// 
      /// </summary>
      public List<string> Features { get; set; }
   }
}