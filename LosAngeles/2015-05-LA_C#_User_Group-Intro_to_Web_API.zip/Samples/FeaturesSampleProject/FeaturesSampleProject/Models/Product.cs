﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FeaturesSampleProject.Models
{
   public class SimpleProduct
   {
      public string ProductName { get; set; }
      public decimal Price { get; set; }
   }

   public class Product
   {
      [Required]
      public int ProductId { get; set; }

      [Required]
      public string ProductName { get; set; }

      public decimal? Price { get; set; }
      public decimal? Cost { get; set; }
      public bool? IsActive { get; set; }
   }

   public class ProductCollection : List<Product>
   {

   }
}