﻿using FeaturesSampleProject.Models.DataAccess;
using System.Collections.Generic;

namespace FeaturesSampleProject.Models
{
   public class ProductManager
   {
      public List<Product> GetProducts(string productName, bool discontinued)
      {
         ProductData data;
         List<Product> result = null;

         data = new ProductData();
         result = data.GetAllProducts();
         
         return result;
      }

      public List<Product> GetProducts()
      {
         ProductData data;
         List<Product> result = null;

         data = new ProductData();
         result = data.GetAllProducts();

         return result;
      }

      internal Product GetProduct(int id)
      {
         Product result;
         ProductData data;

         data = new ProductData();
         result = data.Retrieve(id);

         return result;
      }

      internal void Insert(Product product)
      {
         ProductData data;

         data = new ProductData();
         data.Insert(product);
      }

      internal void Update(Product product)
      {
         ProductData data;

         data = new ProductData();
         data.Update(product);
      }

      internal void Delete(int id)
      {
         ProductData data;

         data = new ProductData();
         data.Delete(id);
      }
   }
}