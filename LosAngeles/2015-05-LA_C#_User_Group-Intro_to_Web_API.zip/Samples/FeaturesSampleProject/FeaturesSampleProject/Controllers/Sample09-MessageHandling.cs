﻿using FeaturesSampleProject.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Linq;

namespace FeaturesSampleProject.Controllers
{
   #region Sample Message Handler

   /// <summary>
   /// Example of using a delegating handler to inspect messages
   /// </summary>
   public class LoggingHandler : DelegatingHandler
   {
      private void Log(HttpRequestMessage request)
      {
         StringBuilder sb = new StringBuilder(1024);

         // Headers
         foreach (var item in request.Headers)
         {
            sb.AppendLine(String.Format("{0} : {1}", item.Key, string.Join(string.Empty, item.Value.ToArray())));
         }

         // Body
         string content = Task.Run(async () => await request.Content.ReadAsStringAsync()).Result;
         sb.Append(content);

         // Write to file
         string fileName = string.Format(@"D:\Talks\{0}.txt", Guid.NewGuid());
         System.IO.File.WriteAllText(fileName, sb.ToString());
      }

      /// <summary>
      /// SendAsync allows you to check the request and determine what to do
      /// </summary>
      /// <param name="request"></param>
      /// <param name="cancellationToken"></param>
      /// <returns></returns>
      protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, 
         CancellationToken cancellationToken)
      {
         Debugger.Break();

         // In this case, log the request
         Log(request);
         
         // Continue on
         return base.SendAsync(request, cancellationToken);
      }
   }

   #endregion

   /// <summary>
   /// Demonstrates custom message handling
   /// </summary>
   public class Sample09Controller : ApiController
   {
      /// <summary>
      /// Returns a store 
      /// </summary>
      /// <returns></returns>
      public RetailStore Get()
      {
         Debugger.Break();

         RetailStore result = new RetailStore
         {
            BusinessName = "The Broadway",
            StreetAddress = "3301 E Main St.",
            UnitAddress = "Suite A",
            City = "Ventura",
            StateProvince = "California",
            PostalCode = "93003"
         };

         return result;
      }
   }
}
