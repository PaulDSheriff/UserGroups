﻿using FeaturesSampleProject.Models;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Filters;

namespace FeaturesSampleProject.Controllers
{
   #region Action Result for Challenge

   public class ChallengeResult : IHttpActionResult
   {
      private IHttpActionResult _innerResult;
      private AuthenticationHeaderValue _challenge;

      public ChallengeResult(AuthenticationHeaderValue challenge, IHttpActionResult innerResult)
      {
         _challenge = challenge;
         _innerResult = innerResult;
      }

      public async Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
      {
         HttpResponseMessage result = null;

         result = await _innerResult.ExecuteAsync(cancellationToken);
         if (result.StatusCode == HttpStatusCode.Unauthorized)
         {
            if (!result.Headers.WwwAuthenticate.Any(h => h.Scheme == _challenge.Scheme))
            {
               result.Headers.WwwAuthenticate.Add(_challenge);
            }
         }

         return result;
      }
   }

   #endregion

   #region Action Result for Failure

   public class AuthenticationFailedResult : IHttpActionResult
   {
      private string _message;
      private HttpRequestMessage _request;

      public AuthenticationFailedResult(string message, HttpRequestMessage request)
      {
         _message = message;
         _request = request;
      }
      public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
      {
         throw new NotImplementedException();
      }
   }

   #endregion

   #region Credential Class

   public class Credential
   {
      public string UserName { get; set; }
      public string Password { get; set; }
   }

   #endregion

   #region Basic Authentication Filter

   /// <summary>
   /// 
   /// </summary>
   public class BasicAuthenticationAttribute : Attribute, IAuthenticationFilter
   {
      /// <summary>
      /// 
      /// </summary>
      /// <param name="context"></param>
      /// <param name="cancellationToken"></param>
      /// <returns></returns>
      public async Task AuthenticateAsync(HttpAuthenticationContext context, CancellationToken cancellationToken)
      {
         bool keepGoing = true;
         HttpRequestMessage request = null;
         AuthenticationHeaderValue authorization = null;
         Credential user = null;

         await Task.Run(() => {

            request = context.Request;
            authorization = request.Headers.Authorization;

            if (authorization == null)
            {
               return;
            }

            if (authorization.Scheme != "Basic")
            {
               keepGoing = false;
            }

            if (String.IsNullOrEmpty(authorization.Parameter))
            {
               context.ErrorResult = new AuthenticationFailedResult("Missing credentials", request);
               keepGoing = false;
            }

            user = this.GetCredentials(authorization.Parameter);

            if (user == null)
            {
               // Authentication was attempted but failed. Set ErrorResult to indicate an error.
               context.ErrorResult = new AuthenticationFailedResult("Invalid credentials", request);
               keepGoing = false;
            }

            if (keepGoing)
            {
               if (user.UserName == "pdsa" & user.Password == "P@ssw0rd")
               {
                  context.Principal = this.CreatePrincipal(); // 
               }
               else
               {
                  // Authentication was attempted but failed. Set ErrorResult to indicate an error.
                  context.ErrorResult = new AuthenticationFailedResult("Invalid username or password", request);
               }
            }
         });
      }

      private IPrincipal CreatePrincipal()
      {
         IIdentity id = new GenericIdentity("pdsa", "Basic");
         List<Claim> claims = new List<Claim>();
         ClaimsIdentity identity = new ClaimsIdentity(id, claims);

         return new ClaimsPrincipal(identity);
      }

      private Credential GetCredentials(string headerValue)
      {
         byte[] credentialBytes;
         string decodedCredentials;
         Credential result;

         try
         {
            credentialBytes = Convert.FromBase64String(headerValue);
         }
         catch (FormatException)
         {
            return null;
         }

         Encoding encoding = Encoding.ASCII;
         encoding = (Encoding)encoding.Clone();
         encoding.DecoderFallback = DecoderFallback.ExceptionFallback;

         try
         {
            decodedCredentials = encoding.GetString(credentialBytes);
         }
         catch (DecoderFallbackException)
         {
            return null;
         }

         if (String.IsNullOrEmpty(decodedCredentials))
         {
            return null;
         }

         int colonIndex = decodedCredentials.IndexOf(':');

         if (colonIndex == -1)
         {
            return null;
         }

         result = new Credential
         {
            UserName = decodedCredentials.Substring(0, colonIndex),
            Password = decodedCredentials.Substring(colonIndex + 1)
         };

         return result;
      }

      /// <summary>
      /// Create a custom challenge result 
      /// </summary>
      /// <param name="context"></param>
      /// <param name="cancellationToken"></param>
      /// <returns></returns>
      public Task ChallengeAsync(HttpAuthenticationChallengeContext context, CancellationToken cancellationToken)
      {
         string realm = null;

         context.Result = new ChallengeResult(
            new AuthenticationHeaderValue("Basic", realm),
            context.Result);

         return Task.FromResult(0);
      }

      /// <summary>
      /// Implementation required by IFilter -- we only want one 
      /// authentication filter per method.
      /// </summary>
      public bool AllowMultiple
      {
         get { return false; }
      }
   }

   #endregion

   /// <summary>
   /// Demonstrates security
   /// </summary>
   public class Sample05Controller : ApiController
   {
      /// <summary>
      /// Basic case using the Authorize attribute
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      [Authorize]
      [BasicAuthentication]
      public RetailStore Get(int id)
      {
         // If it does not hit this break,
         // you're not authorized.

         Debugger.Break();

         RetailStore result = new RetailStore
         {
            BusinessName = "The Broadway",
            StreetAddress = "3301 E Main St.",
            UnitAddress = "Suite A",
            City = "Ventura",
            StateProvince = "California",
            PostalCode = "93003"
         };

         return result;
      }
   }
}
