﻿using FeaturesSampleProject.Models;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web.Http;

namespace FeaturesSampleProject.Controllers
{
   /// <summary>
   /// Demonstrates controller methods accessed via custom routes
   /// </summary>
   [RoutePrefix("api/stores")]
   public class Sample07Controller : ApiController
   {
      /// <summary>
      /// Called via route defined by RoutePrefix attribute 
      /// with Route attribute to map the parameter pattern
      /// </summary>
      /// <param name="id"></param>
      /// <returns></returns>
      [Route("{id:int}")]
      public RetailStore Get(int id)
      {
         Debugger.Break();
         
         RetailStore result = new RetailStore
         {
            BusinessName = "The Broadway",
            StreetAddress = "3301 E Main St.",
            UnitAddress = "Suite A",
            City = "Ventura",
            StateProvince = "California",
            PostalCode = "93003"
         };

         return result;
      }

      /// <summary>
      /// Called via route defined in WebApiConfig.cs
      /// </summary>
      /// <param name="latitude"></param>
      /// <param name="longitude"></param>
      /// <param name="radius"></param>
      /// <returns></returns>
      public List<RetailStore> GetStoresNearCoordinates(double latitude, double longitude, double radius)
      {
         Debugger.Break();

         List<RetailStore> result = new List<RetailStore>();
         result.Add(new RetailStore { BusinessName = "May Company" });

         return result;
      }

      /// <summary>
      /// Called via route defined using the Route attribute
      /// </summary>
      /// <param name="latitude"></param>
      /// <param name="longitude"></param>
      /// <param name="radius"></param>
      /// <param name="feature"></param>
      /// <returns></returns>
      [Route("~/api/list/{latitude}/{longitude}/{radius}/{feature}")]
      public List<RetailStore> GetStoresNearCoordinatesWithFeature(double latitude, double longitude, double radius, string feature)
      {
         Debugger.Break();

         List<RetailStore> result = new List<RetailStore>();
         result.Add(new RetailStore 
         { 
            BusinessName = "The Broadway", 
            Features = new List<string> { feature } 
         });
         
         return result;
      }
   }
}
