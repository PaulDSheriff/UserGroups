﻿using System.Data;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ViewModels
{
  public class SearchViewModel : ViewModelBase
  {
    #region WhereClause
    /// <summary>
    /// Filter products using where
    /// </summary>
    public void WhereClause()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    where prod.Name.StartsWith("L")
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Where(prod => prod.Name.StartsWith("L")).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Find
    /// <summary>
    /// Filter products using Find
    /// NOTE: Find() only works on List<T> not IEnumerable<T>
    /// </summary>
    public void Find()
    {
      System.Diagnostics.Debugger.Break();

      Product value;

      LoadProductsCollection();

      // NOTE: Find() only works on List<T> not IEnumerable<T>

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).ToList().Find(prod => prod.Name.Contains("a"));
      }
      else {
        // Method Syntax
        value = Products.Find(prod => prod.Name.Contains("a"));
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region First
    /// <summary>
    /// Locate the first product using First()
    /// NOTE: First() throws an exception if the result does not produce any values
    /// </summary>
    public void First()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      LoadProductsCollection();

      // NOTE: First() throws an exception if the result does not produce any values

      try {
        if (UseQuerySyntax) {
          // Query Syntax
          value = (from prod in Products
                   where prod.Color == "Red"
                   select prod).First();
        }
        else {
          // Method Syntax
          value = Products.Where(prod => prod.Color == "Red").First();
        }
      }
      catch {
        // Ignore exception
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region FirstOrDefault
    /// <summary>
    /// Locate the first product using FirstOrDefault()
    /// NOTE: FirstOrDefault() returns a null if no value is found
    /// </summary>
    public void FirstOrDefault()
    {
      System.Diagnostics.Debugger.Break();

      Product value;

      LoadProductsCollection();

      // NOTE: FirstOrDefault() returns a null if no value is found

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 where prod.Color == "Red2"
                 select prod).FirstOrDefault();
      }
      else {
        // Method Syntax
        value = Products.Where(prod => prod.Color == "Red").FirstOrDefault();
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region Last
    /// <summary>
    /// Locate the last product in collection using Last()
    /// NOTE: Last returns the last value from a collection, or throws an exception if no value is found
    /// </summary>
    public void Last()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      LoadProductsCollection();

      // NOTE: Last returns the last value from a collection, or throws an exception if no value is found

      try {
        if (UseQuerySyntax) {
          // Query Syntax
          value = (from prod in Products
                   where prod.Color == "Red"
                   select prod).Last();
        }
        else {
          // Method Syntax
          value = Products.Where(prod => prod.Color == "Red").Last();
        }
      }
      catch {
        // Ignore exception
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region LastOrDefault
    /// <summary>
    /// Locate the last product in collection using LastOrDefault()
    /// NOTE: LastOrDefault returns the last value in a collection, or null if no values are found
    /// </summary>
    public void LastOrDefault()
    {
      System.Diagnostics.Debugger.Break();

      Product value;

      LoadProductsCollection();

      // NOTE: LastOrDefault returns the last value in a collection, or null if no values are found

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 where prod.Color == "Red"
                 select prod).LastOrDefault();
      }
      else {
        // Method Syntax
        value = Products.Where(prod => prod.Color == "Red").LastOrDefault();
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region Single
    /// <summary>
    /// Locate a specific product using Single()
    /// NOTE: Single() expects a single element to be returned, otherwise an exception is throw
    /// </summary>
    public void Single()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      LoadProductsCollection();

      // NOTE: Single() expects a single element to be returned, otherwise an exception is throw

      try {
        if (UseQuerySyntax) {
          // Query Syntax
          value = (from prod in Products
                   where prod.ProductID == 706
                   select prod).Single();
        }
        else {
          // Method Syntax
          value = Products.Where(prod => prod.ProductID == 706).Single();
        }
      }
      catch {
        // Ignore exception
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region SingleOrDefault
    /// <summary>
    /// Locate a specific product using SingleOrDefault()
    /// NOTE: SingleOrDefault() expects a single element to be returned, otherwise an exception is throw
    /// </summary>
    public void SingleOrDefault()
    {
      System.Diagnostics.Debugger.Break();

      Product value = null;

      LoadProductsCollection();

      // NOTE: SingleOrDefault() expects a single element to be returned, otherwise an exception is throw

      try {
        if (UseQuerySyntax) {
          // Query Syntax
          value = (from prod in Products
                   where prod.ProductID == 706
                   select prod).SingleOrDefault();
        }
        else {
          // Method Syntax
          value = Products.Where(prod => prod.ProductID == 706).SingleOrDefault();
        }
      }
      catch {
        // Ignore exception
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion
  }
}
