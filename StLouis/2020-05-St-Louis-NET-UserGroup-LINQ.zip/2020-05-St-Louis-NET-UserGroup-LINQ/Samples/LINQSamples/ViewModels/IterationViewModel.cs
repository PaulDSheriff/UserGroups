﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.ManagerClasses;

namespace LINQSamples.ViewModels
{
  public class IterationViewModel : ViewModelBase
  {
    #region ForEach Method
    /// <summary>
    /// ForEach allows you to iterate over a collection
    /// </summary>
    public void ForEach()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    let tmp = prod.ResultText = prod.Name.Length.ToString()
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products.ForEach(prod => prod.ResultText = prod.Name.Length.ToString());
      }

      ResultText = $"Look at ResultText property.\r\nTotal Products: {Products.Count}";
    }
    #endregion

    #region ForEachCallingMethod Method
    /// <summary>
    /// You can call any method within a ForEach
    /// This method passes in each Product object into the SalesForProduct() method
    /// In the SalesForProduct() method, the total sales for each Product is calculated
    /// The total is placed into each Product objects' ResultText property
    /// </summary>
    public void ForEachCallingMethod()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    let tmp = prod.ResultText = SalesForProduct(prod).ToString()
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products.ForEach(prod => prod.ResultText = SalesForProduct(prod).ToString());
      }

      ResultText = $"Look at Product.ResultText property.\r\nTotal Products: {Products.Count}";
    }

    List<SalesOrderDetail> sales = new List<SalesOrderDetail>();

    private string SalesForProduct(Product prod)
    {
      if (sales.Count == 0) {
        SalesOrderDetailManager mgr = new SalesOrderDetailManager();
        sales = mgr.GetAll();
      }

      return sales.Where(s => s.ProductID == prod.ProductID).Select(s => s.LineTotal).Sum().ToString("c");
    }
    #endregion

    #region Skip Method
    /// <summary>
    /// Use Skip() to move past a specified number of items in a collection
    /// </summary>
    public void Skip()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).Skip(20).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).Skip(20).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region SkipWhile Method
    /// <summary>
    /// Use SkipWhile() to move past a specified number of items in the collection based on a condition
    /// </summary>
    public void SkipWhile()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).SkipWhile(prod => prod.Name.StartsWith("A")).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).SkipWhile(prod => prod.Name.StartsWith("A")).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Take Method
    /// <summary>
    /// Use Take() to select a specified number of items in a collection
    /// </summary>
    public void Take()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).Take(5).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).Take(5).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region TakeWhile Method
    /// <summary>
    /// Use TakeWhile() to select a specified number of items in a collection based on a condition
    /// </summary>
    public void TakeWhile()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).TakeWhile(prod => prod.Name.StartsWith("A")).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).TakeWhile(prod => prod.Name.StartsWith("A")).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
