﻿using System.Collections.Generic;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.ManagerClasses;

namespace LINQSamples.ViewModels
{
  public class ComparisonViewModel : ViewModelBase
  {
    #region SequenceEqual
    /// <summary>
    /// SequenceEqual() compares two different collections to see if they are equal
    /// Use an EqualityComparer class to perform the comparison
    /// </summary>
    public void SequenceEqual()
    {
      System.Diagnostics.Debugger.Break();

      bool value;
      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      // Uncomment the following to produce a 'False' value
      // list1.RemoveAt(0);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in list1
                 select prod).SequenceEqual(list1, pc);
      }
      else {
        // Method Syntax
        value = list1.SequenceEqual(list2, pc);
      }

      if (value) {
        ResultText = "Lists are Equal";
      }
      else {
        ResultText = "Lists are NOT Equal";
      }
      Products = null;
    }
    #endregion

    #region Except
    /// <summary>
    /// Except() finds all products in one list that are not in the other list
    /// </summary>
    public void Except()
    {
      System.Diagnostics.Debugger.Break();

      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      // Remove all products with color = "Black" from list2 to give us a difference in the two lists
      list2.RemoveAll(prod => prod.Color == "Black");

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Except(list2, pc).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Except(list2, pc).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Intersect
    /// <summary>
    /// Intersect() finds all products that are in common between two collections
    /// </summary>
    public void Intersect()
    {
      System.Diagnostics.Debugger.Break();

      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      list1.RemoveAll(prod => prod.Color == "Black");
      list2.RemoveAll(prod => prod.Color == "Red");
      
      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Intersect(list2, pc).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Intersect(list2, pc).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Union
    /// <summary>
    /// Union() combines two lists together, but skips duplicates
    /// </summary>
    public void Union()
    {
      System.Diagnostics.Debugger.Break();

      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      list1.RemoveAll(prod => prod.Color == "Black");
      list2.RemoveAll(prod => prod.Color == "Red");

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Union(list2, pc).OrderBy(prod => prod.ProductID).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Union(list2, pc).OrderBy(prod => prod.ProductID).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Concat
    /// <summary>
    /// Concat() combines two lists together and does NOT check for duplicates
    /// </summary>
    public void Concat()
    {
      System.Diagnostics.Debugger.Break();

      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      list1.RemoveAll(prod => prod.Color == "Black");
      list2.RemoveAll(prod => prod.Color == "Red");

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Concat(list2).OrderBy(prod => prod.ProductID).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Concat(list2).OrderBy(prod => prod.ProductID).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
