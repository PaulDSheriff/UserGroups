﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.ManagerClasses;

namespace LINQSamples.ViewModels
{
  public class SelectViewModel : ViewModelBase
  {
    #region GetAllLooping
    /// <summary>
    /// Put all products into a collection via looping
    /// </summary>
    public void GetAllLooping()
    {
      System.Diagnostics.Debugger.Break();

      Products = LoadProductsCollection();

      List<Product> list = new List<Product>();

      foreach (Product item in Products) {
        list.Add(item);
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region GetAll
    /// <summary>
    /// Put all products into a collection using LINQ
    /// </summary>
    public void GetAll()
    {
      System.Diagnostics.Debugger.Break();

      Products = LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Select(prod => prod).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region DistinctLooping
    /// <summary>
    /// Put distinct product colors into another collection using looping
    /// </summary>
    public void DistinctLooping()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(1024);
      List<Product> list = new List<Product>();

      LoadProductsCollection();

      foreach (Product item in Products) {
        if (!list.Any(p => p.Color == item.Color)) {
          list.Add(item);
        }
      }

      foreach (var color in list) {
        sb.AppendLine($"Color: {color.Color}");
      }
      sb.AppendLine($"Total Colors: {list.Count}");

      ResultText = sb.ToString();

      Products = null;
    }
    #endregion

    #region Distinct
    /// <summary>
    /// Put distinct product colors into another collection using LINQ
    /// </summary>
    public void Distinct()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(1024);

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        var colors = (from prod in Products
                      select prod.Color).Distinct().ToList();

        foreach (var color in colors) {
          sb.AppendLine($"Color: {color}");
        }

        sb.AppendLine($"Total Colors: {colors.Count}");

        ResultText = sb.ToString();
      }
      else {
        // Method Syntax
        var colors = Products.Select(prod => prod.Color).Distinct().ToList();

        foreach (var color in colors) {
          sb.AppendLine($"Color: {color}");
        }

        sb.AppendLine($"Total Colors: {colors.Count}");

        ResultText = sb.ToString();
      }

      Products = null;
    }
    #endregion

    #region DistinctUsingComparer
    /// <summary>
    /// Use an EqualityComparer to retrieve distinct product colors
    /// </summary>
    public void DistinctUsingComparer()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    select prod).Distinct(new ProductColorComparer()).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Distinct(new ProductColorComparer()).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region GetSpecificColumns
    /// <summary>
    /// Select a few specific properties from products
    /// </summary>
    public void GetSpecificColumns()
    {
      System.Diagnostics.Debugger.Break();

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    select new Product
                    {
                      ProductID = prod.ProductID,
                      Name = prod.Name,
                      ProductNumber = prod.ProductNumber
                    }).ToList();
      }
      else {
        // Method Syntax
        Products = Products.Select(prod => new Product
        {
          ProductID = prod.ProductID,
          Name = prod.Name,
          ProductNumber = prod.ProductNumber
        }).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Anonymous Class
    /// <summary>
    /// Create an anonymous class from selected product properties
    /// </summary>
    public void AnonymousClass()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        var products = (from prod in Products
                        select new
                        {
                          ProductId = prod.ProductID,
                          ProductName = prod.Name,
                          Identifier = prod.ProductNumber,
                          ProductSize = prod.Size
                        });
        foreach (var prod in products) {
          sb.AppendLine($"ProductId: {prod.ProductId}");
          sb.AppendLine($"    ProductName: {prod.ProductName}");
          sb.AppendLine($"    Identifier: {prod.Identifier}");
          sb.AppendLine($"    ProductSize: {prod.ProductSize}");
        }
      }
      else {
        // Method Syntax
        var products = Products.Select(prod => new
        {
          ProductId = prod.ProductID,
          ProductName = prod.Name,
          Identifier = prod.ProductNumber,
          ProductSize = prod.Size
        });

        foreach (var prod in products) {
          sb.AppendLine($"ProductId: {prod.ProductId}");
          sb.AppendLine($"    ProductName: {prod.ProductName}");
          sb.AppendLine($"    Identifier: {prod.Identifier}");
          sb.AppendLine($"    ProductSize: {prod.ProductSize}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region Join
    /// <summary>
    /// Join a Sales Order Detail collection with Products
    /// </summary>
    public void Join()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);
      List<SalesOrderDetail> Sales = new SalesOrderDetailManager().GetAll();

      LoadProductsCollection();

      var query = (from prod in Products
                   join so in Sales on prod.ProductID equals so.ProductID
                   select new
                   {
                     prod.ProductID,
                     ProductName = prod.Name,
                     prod.ProductNumber,
                     so.SalesOrderID,
                     so.OrderQty,
                     so.LineTotal
                   });

      foreach (var item in query) {
        sb.AppendLine($"Sales Order: {item.SalesOrderID}");
        sb.AppendLine($"  Product ID: {item.ProductID}");
        sb.AppendLine($"  Product Name: {item.ProductName}");
        sb.AppendLine($"  Product Number: {item.ProductNumber}");
        sb.AppendLine($"  Order Qty: {item.OrderQty}");
        sb.AppendLine($"  Total: {item.LineTotal.ToString("c")}");
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region GroupBy
    /// <summary>
    /// Group products by Size property
    /// </summary>
    public void GroupBy()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);

      LoadProductsCollection();

      var grouped = (from prod in Products
                     group prod by prod.Size into newProd
                     orderby newProd.Key
                     select newProd);

      foreach (var sizes in grouped) {
        sb.AppendLine($"Size: {sizes.Key}");
        foreach (var prod in sizes) {
          sb.Append($"  ProductID: {prod.ProductID}");
          sb.Append($"  Name: {prod.Name}");
          sb.AppendLine($"  Color: {prod.Color}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region GroupedSubquery
    /// <summary>
    /// Group Sales Orders by ID, then add Products into new Sales Order object using a subquery
    /// </summary>
    public void GroupedSubquery()
    {
      System.Diagnostics.Debugger.Break();

      StringBuilder sb = new StringBuilder(2048);
      List<SalesOrderDetail> Sales = new SalesOrderDetailManager().GetAll();

      LoadProductsCollection();

      // Get all products for a sales order id
      var query = (from sales in Sales
                   group sales by sales.SalesOrderID into newSale
                   select new
                   {
                     SalesOrderID = newSale.Key,
                     Products = (from prod in Products
                                 join so in Sales on prod.ProductID equals so.ProductID
                                 where so.SalesOrderID == newSale.Key
                                 select prod).ToList()
                   });

      foreach (var sales in query) {
        sb.AppendLine($"Sales ID: {sales.SalesOrderID}");
        foreach (var prod in sales.Products) {
          sb.Append($"  ProductID: {prod.ProductID}");
          sb.Append($"  Name: {prod.Name}");
          sb.AppendLine($"  Color: {prod.Color}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion
  }
}
