﻿using System.Linq;
using Common.Library;
using LINQSamples.ManagerClasses;

namespace LINQSamples.ViewModels
{
  public class AggregateViewModel : ViewModelBase
  {
    #region Count
    /// <summary>
    /// Gets a total number of products in a collection
    /// </summary>
    public void Count()
    {
      System.Diagnostics.Debugger.Break();

      int value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Count();
      }
      else {
        // Method Syntax
        value = Products.Count();
      }

      ResultText = $"Total Products = {value}";
      Products = null;
    }
    #endregion

    #region CountFiltered
    /// <summary>
    /// You can apply a where clause, or a predicate in Count()
    /// </summary>
    public void CountFiltered()
    {
      System.Diagnostics.Debugger.Break();

      int value;

      Products = new ProductManager().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 where prod.Color == "Red"
                 select prod).Count();
      }
      else {
        // Method Syntax
        value = Products.Count(prod => prod.Color == "Red");
      }

      ResultText = $"Total Products with a color of 'Red' = {value}";
      Products = null;
    }
    #endregion

    #region Sum
    /// <summary>
    /// Get a total value from a numeric property
    /// </summary>
    public void Sum()
    {
      System.Diagnostics.Debugger.Break();

      decimal? value;
      Products = new ProductManager().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Sum();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Sum();
      }

      if (value.HasValue) {
        ResultText = $"Total of all List Prices = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Minimum
    /// <summary>
    /// Get the minimum value in a collection
    /// </summary>
    public void Minimum()
    {
      System.Diagnostics.Debugger.Break();

      decimal? value;
      Products = new ProductManager().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Min();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Min();
      }

      if (value.HasValue) {
        ResultText = $"Minimum List Price = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Maximum
    /// <summary>
    /// Get the maximum value in a collection
    /// </summary>
    public void Maximum()
    {
      System.Diagnostics.Debugger.Break();

      decimal? value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Max();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Max();
      }

      if (value.HasValue) {
        ResultText = $"Maximum List Price = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Average
    /// <summary>
    /// Get the average value in a collection
    /// </summary>
    public void Average()
    {
      System.Diagnostics.Debugger.Break();

      decimal? value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Average();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Average();
      }

      if (value.HasValue) {
        ResultText = $"Average List Price = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Aggregate
    /// <summary>
    /// Get a single value returned from a function passed to the Aggregate() function
    /// </summary>
    public void Aggregate()
    {
      System.Diagnostics.Debugger.Break();

      decimal? value = 0;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Aggregate(0M, (sum, prod) =>
                                             prod.Color == "Black" ? sum += prod.ListPrice.Value : sum);
      }
      else {
        // Method Syntax
        value = Products.Aggregate(0M, (sum, prod) =>
                                        prod.Color == "Black" ? sum += prod.ListPrice.Value : sum);
      }

      if (value.HasValue) {
        ResultText = $"Total List Price of Color is 'Black' = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist for the Color 'Black'.";
      }
      Products = null;
    }
    #endregion
  }
}
