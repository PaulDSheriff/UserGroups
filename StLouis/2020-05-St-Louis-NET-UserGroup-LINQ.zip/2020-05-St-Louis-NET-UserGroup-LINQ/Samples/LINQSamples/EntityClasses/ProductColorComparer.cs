﻿using System;
using System.Collections.Generic;
using LINQSamples.EntityClasses;

namespace LINQSamples
{
  public class ProductColorComparer : EqualityComparer<Product>
  {
    public override bool Equals(Product x, Product y)
    {
      if (string.Equals(x.Color, y.Color, StringComparison.OrdinalIgnoreCase)) {
        return true;
      }
      return false;
    }

    public override int GetHashCode(Product obj)
    {
      if (obj.Color != null) {
        return obj.Color.GetHashCode();
      }
      else {
        return 0;
      }
    }
  }
}
