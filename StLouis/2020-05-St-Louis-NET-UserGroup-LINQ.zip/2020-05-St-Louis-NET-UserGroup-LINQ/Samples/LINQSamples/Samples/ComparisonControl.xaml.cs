﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class ComparisonControl : UserControl
  {
    public ComparisonControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (ComparisonViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly ComparisonViewModel _viewModel = null;

    private void SequenceEqual_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SequenceEqual();
    }

    private void Except_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Except();
    }

    private void Intersect_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Intersect();
    }

    private void Union_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Union();
    }

    private void Concat_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Concat();
    }
  }
}