﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class IterationControl : UserControl
  {
    public IterationControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (IterationViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly IterationViewModel _viewModel = null;

    private void ForEach_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.ForEach();
    }

    private void ForEachMethod_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.ForEachCallingMethod();
    }

    private void Skip_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Skip();
    }

    private void SkipWhile_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SkipWhile();
    }

    private void Take_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Take();
    }

    private void TakeWhile_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.TakeWhile();
    }
    }
}
