﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class SelectControl : UserControl
  {
    public SelectControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (SelectViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly SelectViewModel _viewModel = null;

    private void GetAllLooping_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetAllLooping();
    }

    private void GetAll_Click(object sender, System.Windows.RoutedEventArgs e)
    {
      _viewModel.GetAll();
    }
    
    private void DistinctLooping_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.DistinctLooping();
    }

    private void Distinct_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Distinct();
    }

    private void DistinctComparer_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.DistinctUsingComparer();
    }

    private void GetSpecific_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetSpecificColumns();
    }

    private void Anonymous_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.AnonymousClass();
    }

    private void Join_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Join();
    }

    private void GroupBy_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GroupBy();
    }

    private void Subquery_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GroupedSubquery();
    }
  }
}
