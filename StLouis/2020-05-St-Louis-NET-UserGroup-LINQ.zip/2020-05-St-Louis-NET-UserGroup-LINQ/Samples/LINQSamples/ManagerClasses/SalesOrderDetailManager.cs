﻿using System.Collections.Generic;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ManagerClasses
{
  public class SalesOrderDetailManager : CommonBase
  {
    #region GetAll Method
    public List<SalesOrderDetail> GetAll()
    {
      return new List<SalesOrderDetail>
      {
        new SalesOrderDetail
        {
          SalesOrderID = 71774,
          SalesOrderDetailID = 110562,
          OrderQty = 1,
          ProductID = 680,
          UnitPrice = 356.90M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 356.898000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71774,
          SalesOrderDetailID = 110563,
          OrderQty = 1,
          ProductID = 680,
          UnitPrice = 356.90M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 356.898000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71776,
          SalesOrderDetailID = 110567,
          OrderQty = 1,
          ProductID = 706,
          UnitPrice = 63.90M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 63.900000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71780,
          SalesOrderDetailID = 110616,
          OrderQty = 4,
          ProductID = 707,
          UnitPrice = 218.45M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 873.816000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71780,
          SalesOrderDetailID = 110617,
          OrderQty = 2,
          ProductID = 708,
          UnitPrice = 461.69M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 923.388000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71780,
          SalesOrderDetailID = 110618,
          OrderQty = 6,
          ProductID = 709,
          UnitPrice = 113.00M,
          UnitPriceDiscount = 0.40M,
          LineTotal = 406.792800M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71781,
          SalesOrderDetailID = 110619,
          OrderQty = 2,
          ProductID = 709,
          UnitPrice = 818.70M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 1637.400000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71781,
          SalesOrderDetailID = 110620,
          OrderQty = 1,
          ProductID = 710,
          UnitPrice = 323.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 323.994000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71781,
          SalesOrderDetailID = 110621,
          OrderQty = 1,
          ProductID = 711,
          UnitPrice = 149.87M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 149.874000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71782,
          SalesOrderDetailID = 110622,
          OrderQty = 1,
          ProductID = 711,
          UnitPrice = 809.76M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 809.760000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71782,
          SalesOrderDetailID = 110623,
          OrderQty = 4,
          ProductID = 712,
          UnitPrice = 1376.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 5507.976000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71783,
          SalesOrderDetailID = 110624,
          OrderQty = 2,
          ProductID = 713,
          UnitPrice = 158.43M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 316.860000M,
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71784,
          SalesOrderDetailID = 110625,
          OrderQty = 4,
          ProductID = 714,
          UnitPrice = 1391.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 5567.976000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71784,
          SalesOrderDetailID = 110626,
          OrderQty = 1,
          ProductID = 715,
          UnitPrice = 48.59M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 48.594000M,
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71784,
          SalesOrderDetailID = 110627,
          OrderQty = 6,
          ProductID = 716,
          UnitPrice = 41.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 251.964000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71784,
          SalesOrderDetailID = 110628,
          OrderQty = 1,
          ProductID = 717,
          UnitPrice = 113.00M,
          UnitPriceDiscount = 0.40M,
          LineTotal = 67.798800M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71785,
          SalesOrderDetailID = 110629,
          OrderQty = 2,
          ProductID = 718,
          UnitPrice = 323.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 647.988000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71785,
          SalesOrderDetailID = 110630,
          OrderQty = 3,
          ProductID = 719,
          UnitPrice = 323.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 971.982000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71786,
          SalesOrderDetailID = 110631,
          OrderQty = 1,
          ProductID = 720,
          UnitPrice = 323.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 323.994000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71786,
          SalesOrderDetailID = 110632,
          OrderQty = 2,
          ProductID = 721,
          UnitPrice = 323.99M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 647.988000M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71786,
          SalesOrderDetailID = 110633,
          OrderQty = 2,
          ProductID = 722,
          UnitPrice = 113.00M,
          UnitPriceDiscount = 0.40M,
          LineTotal = 135.597600M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71787,
          SalesOrderDetailID = 110634,
          OrderQty = 3,
          ProductID = 723,
          UnitPrice = 113.00M,
          UnitPriceDiscount = 0.40M,
          LineTotal = 203.396400M,
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71788,
          SalesOrderDetailID = 110635,
          OrderQty = 3,
          ProductID = 724,
          UnitPrice = 113.00M,
          UnitPriceDiscount = 0.40M,
          LineTotal = 203.396400M
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71788,
          SalesOrderDetailID = 110636,
          OrderQty = 2,
          ProductID = 725,
          UnitPrice = 461.69M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 923.388000M,
        },
        new SalesOrderDetail
        {
          SalesOrderID = 71788,
          SalesOrderDetailID = 110637,
          OrderQty = 3,
          ProductID = 726,
          UnitPrice = 461.69M,
          UnitPriceDiscount = 0.00M,
          LineTotal = 1385.082000M
        }
      };
    }
    #endregion
  }
}
