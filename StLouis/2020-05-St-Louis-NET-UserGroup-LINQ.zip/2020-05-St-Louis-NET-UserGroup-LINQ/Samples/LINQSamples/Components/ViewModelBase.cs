﻿using System.Collections.Generic;
using LINQSamples.EntityClasses;
using LINQSamples.ManagerClasses;

namespace Common.Library
{
  public class ViewModelBase : CommonBase
  {
    #region Properties
    private List<Product> _Products;

    public List<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region LoadProductsCollection
    public List<Product> LoadProductsCollection()
    {
      Products = new ProductManager().GetAll();

      return Products;
    }
    #endregion
  }
}
