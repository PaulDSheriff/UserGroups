﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class LinqXmlControl : UserControl
  {
    public LinqXmlControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (LinqXmlViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly LinqXmlViewModel _viewModel = null;

    private void AllNodesButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetAll();
    }

    private void WhereButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.WhereClause();
    }

    private void WhereAttributeButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.WhereClauseUsingAttribute();
    }

    private void OrderByButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.OrderBy();
    }

    private void OrderByDescButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.OrderByDescending();
    }

    private void CountButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Count();
    }

    private void SumButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Sum();
    }

    private void MinimumButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Minimum();
    }

    private void MaximumButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Maximum();
    }

    private void AverageButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Average();
    }

    private void LoadClassesButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.LoadClass();
    }

    private void GetSpecificButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetSpecificColumns();
    }

    private void JoinButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Join();
    }

    private void ReadConfigButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.ReadConfig();
    }
  }
}
