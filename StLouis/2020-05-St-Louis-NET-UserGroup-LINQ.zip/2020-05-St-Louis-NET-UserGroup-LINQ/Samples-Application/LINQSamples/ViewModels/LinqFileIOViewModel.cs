﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ViewModels
{
  public class LinqFileIOViewModel : CommonBase
  {
    #region Properties
    private string _FolderPath1 = @"D:\Samples\Folder1";
    private string _FolderPath2 = @"D:\Samples\Folder2";
    private string _SearchText = "<style>";

    /// <summary>
    /// Get/Set FolderPath
    /// </summary>
    public string FolderPath1
    {
      get { return _FolderPath1; }
      set {
        _FolderPath1 = value;
        RaisePropertyChanged("FolderPath1");
      }
    }

    /// <summary>
    /// Get/Set FolderPath2
    /// </summary>
    public string FolderPath2
    {
      get { return _FolderPath2; }
      set {
        _FolderPath2 = value;
        RaisePropertyChanged("FolderPath1");
      }
    }

    /// <summary>
    /// Get/Set SearchText
    /// </summary>
    public string SearchText
    {
      get { return _SearchText; }
      set {
        _SearchText = value;
        RaisePropertyChanged("SearchText");
      }
    }
    #endregion

    #region GetNewestFile Method
    public void GetNewestFile()
    {
      StringBuilder sb = new StringBuilder(1024);

      // Get Directory Info
      DirectoryInfo di = new DirectoryInfo(FolderPath1);

      // Get list of files from folder path
      List<FileInfo> files = di.GetFiles("*.*", SearchOption.AllDirectories).ToList();

      // Order files by creation date/time and get last one
      var file = (from fi in files
                  orderby fi.CreationTime
                  select new { fi.FullName, fi.CreationTime }).Last();

      sb.AppendLine("Newest File: " + file.FullName + " - " + file.CreationTime.ToString());

      ResultText = sb.ToString();
    }
    #endregion

    #region GetTotalBytesInFolder Method
    public void GetTotalBytesInFolder()
    {
      StringBuilder sb = new StringBuilder(1024);

      // Get list of files from folder path
      List<string> files = Directory.GetFiles(FolderPath1, "*.*", SearchOption.AllDirectories).ToList();

      // Use LINQ to query each file's length
      long[] lengths = (from file in files
                        select GetFileLength(file)).ToArray();

      sb.AppendLine("Total Bytes: " + lengths.Sum().ToString());
      sb.AppendLine("Total Files: " + lengths.Length.ToString());
      sb.AppendLine("Max Length: " + lengths.Max().ToString());
      sb.AppendLine("Min Length: " + lengths.Min().ToString());

      ResultText = sb.ToString();
    }
    #endregion

    #region GetTextInFile Method
    public void GetTextInFile()
    {
      StringBuilder sb = new StringBuilder(1024);

      // Get Directory Info
      DirectoryInfo di = new DirectoryInfo(FolderPath1);

      // Get list of files from folder path
      List<FileInfo> files = di.GetFiles("*.*", SearchOption.AllDirectories).ToList();

      // Search for all .HTML files and look for text within the files
      var matchingFiles = (from fi in files
                           where fi.Extension == ".html"
                           let fileText = GetFileText(fi.FullName)
                           where fileText.Contains(SearchText)
                           orderby fi.FullName
                           select fi.FullName);

      sb.AppendLine("Files with Search Text: " + matchingFiles.Count().ToString());
      foreach (string item in matchingFiles) {
        sb.AppendLine(item);
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region CompareTwoFolders method
    public void CompareTwoFolders()
    {
      // Get Directory Info
      DirectoryInfo di1 = new DirectoryInfo(FolderPath1);
      DirectoryInfo di2 = new DirectoryInfo(FolderPath2);

      // Get list of files from folder path
      List<FileInfo> files1 = di1.GetFiles("*.*", SearchOption.AllDirectories).ToList();
      List<FileInfo> files2 = di2.GetFiles("*.*", SearchOption.AllDirectories).ToList();

      // Create custom FileComparer class
      FileCompare fc = new FileCompare();

      if (files1.SequenceEqual(files2, fc)) {
        ResultText = "The two folders contain the same files";
      }
      else {
        ResultText = "The two folders do NOT contain the same files";
      }
    }
    #endregion

    #region CommonFilesInTwoFolders method
    public void CommonFilesInTwoFolders()
    {
      StringBuilder sb = new StringBuilder(1024);

      // Get Directory Info
      DirectoryInfo di1 = new DirectoryInfo(FolderPath1);
      DirectoryInfo di2 = new DirectoryInfo(FolderPath2);

      // Get list of files from folder path
      List<FileInfo> files1 = di1.GetFiles("*.*", SearchOption.AllDirectories).ToList();
      List<FileInfo> files2 = di2.GetFiles("*.*", SearchOption.AllDirectories).ToList();

      // Create custom FileComparer class
      FileCompare fc = new FileCompare();

      List<FileInfo> commonFiles = files1.Intersect(files2, fc).ToList();

      if (commonFiles.Count() > 0) {
        sb.AppendLine("The following files are found in both folders");
        foreach (FileInfo fi in commonFiles) {
          sb.AppendLine(fi.FullName);
        }
      }
      else {
        sb.AppendLine("No files are found in both folders");
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region DifferentFilesInTwoFolders method
    public void DifferentFilesInTwoFolders()
    {
      StringBuilder sb = new StringBuilder(1024);

      // Get Directory Info
      DirectoryInfo di1 = new DirectoryInfo(FolderPath1);
      DirectoryInfo di2 = new DirectoryInfo(FolderPath2);

      // Get list of files from folder path
      List<FileInfo> files1 = di1.GetFiles("*.*", SearchOption.AllDirectories).ToList();
      List<FileInfo> files2 = di2.GetFiles("*.*", SearchOption.AllDirectories).ToList();

      // Create custom FileComparer class
      FileCompare fc = new FileCompare();

      List<FileInfo> diff = (from file in files1
                             select file).Except(files2, fc).ToList();

      sb.AppendLine("The following files are in Folder 1 but not in Folder 2");
      foreach (FileInfo fi in diff) {
        sb.AppendLine(fi.FullName);
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region GetFileLength Method
    private long GetFileLength(string filename)
    {
      long ret = 0;

      try {
        FileInfo fi = new FileInfo(filename);
        ret = fi.Length;
      }
      catch {
        // Ignore any exceptions
      }

      return ret;
    }
    #endregion

    #region GetFileText Method
    private string GetFileText(string name)
    {
      string ret = String.Empty;

      if (File.Exists(name)) {
        ret = File.ReadAllText(name);
      }
      return ret;
    }
    #endregion
  }

}
