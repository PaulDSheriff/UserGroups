﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Library;

namespace LINQSamples.ViewModels
{
  public class LinqStringViewModel : CommonBase
  {
    #region Properties
    private string _OriginalText = "FR-R92B-58";
    private string _UpToCharacter = "2";

    /// <summary>
    /// Get/Set OriginalText
    /// </summary>
    public string OriginalText
    {
      get { return _OriginalText; }
      set { _OriginalText = value; }
    }

    /// <summary>
    /// Get/Set UpToCharacter
    /// </summary>
    public string UpToCharacter
    {
      get { return _UpToCharacter; }
      set { _UpToCharacter = value; }
    }
    #endregion

    #region FindNumbers Method
    public void FindNumbers()
    {
      StringBuilder sb = new StringBuilder();

      // Select only numbers
      IEnumerable<char> numbers = 
        (from ch in OriginalText
         where Char.IsDigit(ch)
         select ch);

      // Execute the query
      foreach (char c in numbers) {
        sb.AppendLine(c.ToString());
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region GetTextBefore Method
    public void GetTextBefore()
    {
      StringBuilder sb = new StringBuilder();

      // Select only text up to a character
      IEnumerable<char> text = OriginalText.TakeWhile(
         c => c.ToString() != UpToCharacter);

      // Execute the query
      foreach (char c in text) {
        sb.AppendLine(c.ToString());
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region FindSentences Method
    public void FindSentences()
    {
      StringBuilder sb = new StringBuilder(1024);

      // Create array used to split a sentence into individual words
      char[] wordSplit = new char[] { '.', '?', '!', ' ', ';', ':', ',' };

      // Split the text into an array of sentences
      string[] sentences = OriginalText.Split(new char[] { '.', '?', '!' });

      // Split the words to search for into an array
      string[] wordsToMatch = UpToCharacter.Split(",".ToCharArray());

      // Find sentences that contain all the terms in the wordsToMatch array.
      var query = (from sentence in sentences
                   let word = sentence.Split(wordSplit, StringSplitOptions.RemoveEmptyEntries)
                   where word.Distinct().Intersect(wordsToMatch).Count() == wordsToMatch.Count()
                   select sentence);

      // Find all sentences
      foreach (string sentence in query) {
        sb.AppendLine(sentence);
      }

      ResultText = sb.ToString();
    }
    #endregion
  }
}
