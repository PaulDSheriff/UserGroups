﻿using Common.Library;

namespace LINQSamples
{
  public partial class ProductDTO : CommonBase
  {
    public int ProductID { get; set; }
    public string Name { get; set; }
    public string ProductNumber { get; set; }
    public string Size { get; set; }

    public override string ToString()
    {
      return Name;
    }
  }
}
