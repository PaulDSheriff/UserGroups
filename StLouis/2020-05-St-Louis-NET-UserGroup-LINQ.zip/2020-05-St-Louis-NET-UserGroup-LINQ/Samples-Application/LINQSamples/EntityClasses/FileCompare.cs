﻿using System.Collections.Generic;
using System.IO;

namespace LINQSamples.EntityClasses
{
  public class FileCompare : IEqualityComparer<FileInfo>
  {
    public bool Equals(FileInfo fi1, FileInfo fi2)
    {
      return (fi1.Name == fi2.Name && fi1.Length == fi2.Length);
    }

    // Return a hash that is the same as the Equals() method
    public int GetHashCode(FileInfo fi)
    {
      return $"{fi.Name}{fi.Length}".GetHashCode();
    }
  }
}
