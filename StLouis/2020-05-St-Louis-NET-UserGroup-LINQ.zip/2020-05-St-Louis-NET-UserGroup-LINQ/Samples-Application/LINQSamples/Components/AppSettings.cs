﻿using System;
using System.Configuration;

namespace Common.Library
{
  /// <summary>
  /// This class holds global data for this application
  /// </summary>
  public class AppSettings : CommonBase
  {
    #region Constructor
    public AppSettings()
    {
      Init();
    }
    #endregion

    #region Instance Property
    private static AppSettings _Instance;

    public static AppSettings Instance
    {
      get {
        if (_Instance == null) {
          _Instance = new AppSettings();
        }

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Private Properties
    private string _ProductsFile;
    private string _ProductsAttributesFile;
    private string _SalesOrderDetailsFile;
    private string _ConnectionString;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set ProductsFile
    /// </summary>
    public string ProductsFile
    {
      get { return _ProductsFile; }
      set {
        _ProductsFile = value;
        RaisePropertyChanged("ProductsFile");
      }
    }

    /// <summary>
    /// Get/Set ProductsAttributesFile
    /// </summary>
    public string ProductsAttributesFile
    {
      get { return _ProductsAttributesFile; }
      set {
        _ProductsAttributesFile = value;
        RaisePropertyChanged("ProductsAttributesFile");
      }
    }

    /// <summary>
    /// Get/Set SalesOrderDetailsFile
    /// </summary>
    public string SalesOrderDetailsFile
    {
      get { return _SalesOrderDetailsFile; }
      set {
        _SalesOrderDetailsFile = value;
        RaisePropertyChanged("SalesOrderDetailsFile");
      }
    }

    /// <summary>
    /// Get/Set ConnectionString
    /// </summary>
    public string ConnectionString
    {
      get { return _ConnectionString; }
      set { _ConnectionString = value;
        RaisePropertyChanged("ConnectionString");
      }
    }
    #endregion

    #region Init Method
    public void Init()
    {
      string path = GetCurrentDirectory();
      ProductsFile = path + @"\Xml\Products.xml";
      ProductsAttributesFile = path + @"\Xml\Products_Attributes.xml";
      SalesOrderDetailsFile = path + @"\Xml\SalesOrderDetails.xml";

      ConnectionString = ConfigurationManager.ConnectionStrings["AdventureWorksLT"].ConnectionString;
    }
    #endregion

    #region GetCurrentDirectory Method
    public string GetCurrentDirectory()
    {
      string path;

      path = AppDomain.CurrentDomain.BaseDirectory;
      if (path.IndexOf(@"\bin") > 0) {
        path = path.Substring(0, path.LastIndexOf(@"\bin"));
      }

      return path;
    }
    #endregion
  }
}
