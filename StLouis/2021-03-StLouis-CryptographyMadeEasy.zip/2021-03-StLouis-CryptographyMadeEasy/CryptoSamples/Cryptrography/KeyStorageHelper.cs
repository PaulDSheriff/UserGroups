﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace CryptoSamples.Cryptrography
{
  public class KeyStorageHelper
  {
    #region Instance Property
    private static KeyStorageHelper _instance = null;
    public static KeyStorageHelper Instance
    {
      get {
        if (_instance == null) {
          _instance = new KeyStorageHelper();
        }
        return _instance;
      }
      set { _instance = value; }
    }
    #endregion

    #region Save Method
    public void Save(string key, string fileName)
    {
      try {
        // Convert key to byte array
        byte[] data = UnicodeEncoding.ASCII.GetBytes(key);

        // Encrypt the key using DPAPI
        byte[] toWrite = ProtectedData.Protect(data, null, DataProtectionScope.CurrentUser);

        // Write encrypted data to a file
        File.WriteAllBytes(fileName, toWrite);
      }
      catch (Exception ex) {
        Console.WriteLine("ERROR: " + ex.Message);
      }
    }
    #endregion

    #region Get Method
    public string Get(string fileName)
    {
      string ret = string.Empty;

      try {
        // Read raw bytes from file
        byte[] data = File.ReadAllBytes(fileName);

        // Unencrypt data from file
        byte[] key = ProtectedData.Unprotect(data, null, DataProtectionScope.CurrentUser);

        // Convert back to a string
        ret = UnicodeEncoding.ASCII.GetString(key);
      }
      catch (Exception ex) {
        Console.WriteLine("ERROR: " + ex.Message);
      }

      return ret;
    }
    #endregion
  }
}
