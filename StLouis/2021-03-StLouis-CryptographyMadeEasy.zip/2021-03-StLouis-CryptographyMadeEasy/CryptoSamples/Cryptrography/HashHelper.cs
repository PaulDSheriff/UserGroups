﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace CryptoSamples.Cryptrography
{
  public class HashHelper
  {
    #region Instance Property
    private static HashHelper _instance = null;
    public static HashHelper Instance
    {
      get {
        if (_instance == null) {
          _instance = new HashHelper();
        }
        return _instance;
      }
      set { _instance = value; }
    }
    #endregion

    #region HashTypes
    public enum HashTypes : byte
    {
      SHA256,
      SHA384,
      SHA512
    }
    #endregion

    #region GetHashAlgorithm() Method
    protected virtual HashAlgorithm GetHashAlgorithm(HashTypes type)
    {
      HashAlgorithm ret = null;

      switch (type) {
        case HashTypes.SHA256:
          ret = SHA256.Create();
          break;
        case HashTypes.SHA384:
          ret = SHA384.Create();
          break;
        case HashTypes.SHA512:
          ret = SHA512.Create();
          break;
      }

      return ret;
    }
    #endregion

    #region Hash Methods  
    public virtual string Hash(HashTypes type, string value, string salt)
    {
      string ret = string.Empty;

      // Make sure salt value is not null
      salt = salt ?? string.Empty;

      // Create a hash algorithm object
      using (HashAlgorithm algorithm = GetHashAlgorithm(type)) {
        // Compute the hash of the value passed in
        byte[] hash = algorithm.ComputeHash(
          UnicodeEncoding.ASCII.GetBytes(salt + value));

        // Zero out sensitive information from memory
        // prior to disposing of object
        algorithm.Clear();

        // Convert hash to base64 encoded string
        ret = Convert.ToBase64String(hash);
      }

      // Return hashed value
      return ret;
    }
    #endregion

    #region GenerateSalt Method
    /// <summary>
    /// Generate a randomized salt value
    /// </summary>
    /// <returns>A random salt value</returns>
    public virtual string GenerateSalt()
    {
      string ret = string.Empty;

      // Create a random value using a random number generator
      // Use this value as the secret shared by a sender and a receiver
      byte[] key = new Byte[64];
      // Create an instance of the RNGCryptoServiceProvider
      using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider()) {
        // Fill the byte array with cryptographically strong random bytes
        rng.GetBytes(key);

        // Assign value a to base64 encoded string
        ret = Convert.ToBase64String(key);
      }

      return ret;
    }
    #endregion
  }
}
