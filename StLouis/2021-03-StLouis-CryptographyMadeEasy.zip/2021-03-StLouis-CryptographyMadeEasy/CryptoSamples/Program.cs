﻿using System;
using CryptoSamples.Cryptrography;
using CryptoSamples.ViewModels;

namespace CryptoSamples
{
  class Program
  {
    private const string VALUE = "P@ssW0rd";

    static void Main(string[] args)
    {
      // HashSamples();

      // HashHelperSamples();

      // SymmetricSamples();

      // SymmetricHelperSamples();

      KeyStorageSamples();

      // Pause the console window
      Console.ReadKey();
    }

    #region HashSamples Method
    static void HashSamples()
    {
      HashViewModel vm = new HashViewModel();
      string hashedValue;
      string salt;

      // *****************************************************************
      // Hash a value
      // *****************************************************************
      hashedValue = vm.HashUsingSHA256(VALUE);
      Console.WriteLine($"Hash of '{VALUE}' is '{hashedValue}'");

      // *****************************************************************
      // Generate a random salt value
      // *****************************************************************
      salt = vm.GenerateSalt();
      Console.WriteLine();
      Console.WriteLine($"Generated salt: '{salt}'");

      // *****************************************************************
      // Hash a value and add salt value to string to hash
      // *****************************************************************
      hashedValue = vm.HashUsingSHA256AndSalt(VALUE, salt);
      Console.WriteLine();
      Console.WriteLine($"Hash of '{VALUE}' with salt is '{hashedValue}'");
    }
    #endregion

    #region HashHelperSamples Method
    static void HashHelperSamples()
    {
      string salt;
      string hashedValue;

      // *****************************************************************
      // Hash a value
      // *****************************************************************
      hashedValue = HashHelper.Instance.Hash(HashHelper.HashTypes.SHA256, VALUE, string.Empty);
      Console.WriteLine($"Hash of '{VALUE}' is '{hashedValue}'");

      // *****************************************************************
      // Generate a random salt value
      // *****************************************************************
      salt = HashHelper.Instance.GenerateSalt();
      Console.WriteLine();
      Console.WriteLine($"Generated salt: '{salt}'");

      // *****************************************************************
      // Hash a value and add salt value to string to hash
      // *****************************************************************
      hashedValue = HashHelper.Instance.Hash(HashHelper.HashTypes.SHA256, VALUE, salt);
      Console.WriteLine();
      Console.WriteLine($"Hash of '{VALUE}' with salt is '{hashedValue}'");
      Console.WriteLine();
    }
    #endregion

    #region SymmetricSamples Method
    static void SymmetricSamples()
    {
      SymmetricViewModel vm = new SymmetricViewModel();

      // *****************************************************************
      // Generate a Key and IV
      // *****************************************************************
      vm.GenerateKeyAndIV();
      Console.WriteLine($"Key is '{vm.Key}'");
      Console.WriteLine($"IV is '{vm.IV}'");

      // *****************************************************************
      // Encrypt a value
      // *****************************************************************
      vm.Encrypt(VALUE, vm.Key, vm.IV);
      Console.WriteLine();
      Console.WriteLine($"Encoding value '{VALUE}'");
      Console.WriteLine($"  Encoded value is '{vm.EncryptedValue}'");

      // *****************************************************************
      // Decrypt a value
      // *****************************************************************
      vm.Decrypt(vm.EncryptedValue, vm.Key, vm.IV);
      Console.WriteLine();
      Console.WriteLine($"Decoding value '{vm.EncryptedValue}'");
      Console.WriteLine($"  Decoded value is '{vm.DecryptedValue}'");
      Console.WriteLine();
    }
    #endregion

    #region SymmetricHelperSamples Method
    static void SymmetricHelperSamples()
    {
      // NOTE: Pass in a SymmetricTypes enum to the constructor 
      //       to try out different algorithms
      SymmetricHelper vm = new SymmetricHelper();

      // *****************************************************************
      // Generate a Key and IV
      // *****************************************************************
      vm.GenerateKeyAndIV();
      Console.WriteLine($"Key is '{vm.Key}'");
      Console.WriteLine($"IV is '{vm.IV}'");

      // *****************************************************************
      // Encrypt a value
      // *****************************************************************
      vm.Encrypt(VALUE);
      Console.WriteLine();
      Console.WriteLine($"Encoding value '{VALUE}'");
      Console.WriteLine($"  Encoded value is '{vm.EncryptedValue}'");

      // *****************************************************************
      // Decrypt a value
      // *****************************************************************
      vm.Decrypt(vm.EncryptedValue);
      Console.WriteLine();
      Console.WriteLine($"Decoding value '{vm.EncryptedValue}'");
      Console.WriteLine($"  Decoded value is '{vm.DecryptedValue}'");
      Console.WriteLine();
    }
    #endregion

    #region KeyStorageSamples Method
    static void KeyStorageSamples()
    {
      SymmetricHelper svm = new SymmetricHelper();
      KeyStorageHelper vm = new KeyStorageHelper();
      string fileName = "CryptoSample.dat";

      // *****************************************************************
      // Generate a Key and IV
      // *****************************************************************
      svm.GenerateKeyAndIV();
      Console.WriteLine($"Key is '{svm.Key}'");
      Console.WriteLine($"IV is '{svm.IV}'");

      // *****************************************************************
      // Encrypt a value
      // *****************************************************************
      svm.Encrypt(VALUE);
      Console.WriteLine();
      Console.WriteLine($"Encoding value '{VALUE}'");
      Console.WriteLine($"  Encoded value is '{svm.EncryptedValue}'");

      // *****************************************************************
      // Store the IV in a data store
      // *****************************************************************
      vm.Save(svm.IV, fileName);

      // *****************************************************************
      // Wipe out the IV in the Symmetric Helper
      // *****************************************************************
      svm.IV = "";

      // *****************************************************************
      // Restore IV from data store
      // *****************************************************************
      svm.IV = vm.Get(fileName);

      // *****************************************************************
      // Decrypt a value
      // *****************************************************************
      svm.Decrypt(svm.EncryptedValue);
      Console.WriteLine();
      Console.WriteLine($"Decoding value '{svm.EncryptedValue}'");
      Console.WriteLine($"  Decoded value is '{svm.DecryptedValue}'");
      Console.WriteLine();
    }
    #endregion
  }
}
