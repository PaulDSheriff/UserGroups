﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace CryptoSamples.ViewModels
{
  public class SymmetricViewModel
  {
    #region Public Properties
    /// <summary>
    /// Get/Set a Secret Key for Cryptographic Operations
    /// </summary>
    public string Key { get; set; }
    /// <summary>
    /// Get/Set a IV for use with Symmetric Algorithms
    /// </summary>
    public string IV { get; set; }
    /// <summary>
    /// Get/Set the encrypted value
    /// </summary>
    public string EncryptedValue { get; set; }
    /// <summary>
    /// Get/Set the decrypted value
    /// </summary>
    public string DecryptedValue { get; set; }
    #endregion

    #region GenerateKeyAndIV Method
    public void GenerateKeyAndIV()
    {
      // Create a symmetric algorithm object
      using (Aes algorithm = Aes.Create()) {
        // Fill in Key and IV properties
        Key = Convert.ToBase64String(algorithm.Key);
        IV = Convert.ToBase64String(algorithm.IV);
      }
    }
    #endregion

    #region Encrypt Method
    public string Encrypt(string value, string key, string iv)
    {
      byte[] encrypted = null;

      // Create an Aes symmetric algorithm object
      using (Aes algorithm = Aes.Create()) {
        // Fill in Key and IV properties
        algorithm.Key = Convert.FromBase64String(key);
        algorithm.IV = Convert.FromBase64String(iv);

        // Create an encryptor object
        ICryptoTransform enc =
          algorithm.CreateEncryptor(algorithm.Key, algorithm.IV);

        // Create the streams used to encrypt the data
        using (MemoryStream ms = new MemoryStream()) {
          using (CryptoStream cs = new CryptoStream(ms, enc, CryptoStreamMode.Write)) {
            using (StreamWriter sw = new StreamWriter(cs)) {
              // Write data to the stream
              sw.Write(value);
            }
            // Convert memory stream to array of bytes
            encrypted = ms.ToArray();
          }
        }

        // Zero out sensitive information from memory
        // prior to disposing of object
        algorithm.Clear();

        // Convert encrypted result to base64 encoded string
        EncryptedValue = Convert.ToBase64String(encrypted);
      }

      // Return encypted value
      return EncryptedValue;
    }
    #endregion

    #region Decrypt Method
    public string Decrypt(string value, string key, string iv)
    {
      byte[] encrypted = Convert.FromBase64String(value);

      // Create a symmetric algorithm object
      using (Aes algorithm = Aes.Create()) {
        // Fill in Key and IV properties
        algorithm.Key = Convert.FromBase64String(key);
        algorithm.IV = Convert.FromBase64String(iv);

        // Create a decryptor object
        ICryptoTransform dec =
          algorithm.CreateDecryptor(algorithm.Key, algorithm.IV);

        // Create the streams used to decrypt the data
        using (MemoryStream ms = new MemoryStream(encrypted)) {
          using (CryptoStream cs = new CryptoStream(ms, dec, CryptoStreamMode.Read)) {
            using (StreamReader sr = new StreamReader(cs)) {
              // Read data from stream
              DecryptedValue = sr.ReadToEnd();
            }
          }
        }
      }

      // Return decypted value
      return DecryptedValue;
    }
    #endregion
  }
}
