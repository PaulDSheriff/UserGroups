﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace CryptoSamples.ViewModels
{
  public class HashViewModel
  {
    public string HashUsingSHA256(string value)
    {
      string ret = string.Empty;

      // Create a hash algorithm object
      using (SHA256 algorithm = SHA256.Create()) {
        // Compute the hash of the value passed in
        byte[] hash = algorithm.ComputeHash(
          UnicodeEncoding.ASCII.GetBytes(value));

        // Zero out sensitive information from memory
        // prior to disposing of object
        algorithm.Clear();

        // Convert hash to base64 encoded string
        ret = Convert.ToBase64String(hash);
      }

      // Return hashed value
      return ret;
    }

    public virtual string GenerateSalt()
    {
      string ret = string.Empty;

      // Create a random key using a random number generator
      // Use this key as the secret shared by a sender and a receiver
      byte[] key = new Byte[64];
      // Create an instance of the RNGCryptoServiceProvider
      using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider()) {
        // Fill the byte array with cryptographically strong random bytes
        rng.GetBytes(key);

        // Assign key a to base64 encoded string
        ret = Convert.ToBase64String(key);
      }

      return ret;
    }

    public string HashUsingSHA256AndSalt(string value, string salt)
    {
      string ret = string.Empty;

      // Make sure salt value is not null
      salt = salt ?? string.Empty;

      // Create a hash algorithm object
      using (SHA256 algorithm = SHA256.Create()) {
        // Compute the hash of the value passed in
        byte[] hash = algorithm.ComputeHash(
          UnicodeEncoding.ASCII.GetBytes(salt + value));

        // Zero out sensitive information from memory
        // prior to disposing of object
        algorithm.Clear();

        // Convert hash to base64 encoded string
        ret = Convert.ToBase64String(hash);
      }

      // Return hashed value
      return ret;
    }
  }
}
