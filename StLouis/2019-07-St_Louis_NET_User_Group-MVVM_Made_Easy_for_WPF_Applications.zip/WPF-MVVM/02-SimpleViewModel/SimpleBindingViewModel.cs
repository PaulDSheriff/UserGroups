﻿using Common.Library;

namespace WPF_MVVM
{
  public class SimpleBindingViewModel : CommonBase
  {
    private bool _IsBenefitsChecked = true;
    private bool _IsHealthCareEnabled = true;
    private bool _Is401kEnabled = true;

    public bool IsBenefitsChecked
    {
      get { return _IsBenefitsChecked; }
      set {
        _IsBenefitsChecked = value;
        Is401kEnabled = value;
        IsHealthCareEnabled = value;
        RaisePropertyChanged("IsBenefitsChecked");
      }
    }
    public bool IsHealthCareEnabled
    {
      get { return _IsHealthCareEnabled; }
      set {
        _IsHealthCareEnabled = value;
        RaisePropertyChanged("IsHealthCareEnabled");
      }
    }
    public bool Is401kEnabled
    {
      get { return _Is401kEnabled; }
      set {
        _Is401kEnabled = value;
        RaisePropertyChanged("Is401kEnabled");
      }
    }
  }
}
