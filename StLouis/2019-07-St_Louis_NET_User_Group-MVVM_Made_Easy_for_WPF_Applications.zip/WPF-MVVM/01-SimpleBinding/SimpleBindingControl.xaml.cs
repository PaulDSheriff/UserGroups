﻿using System.Windows.Controls;

namespace WPF_MVVM
{
  public partial class SimpleBindingControl : UserControl
  {
    public SimpleBindingControl()
    {
      InitializeComponent();
    }
  }
}
