﻿using System.Windows.Controls;

namespace WPF_MVVM
{
  public partial class ProductListControl : UserControl
  {
    public ProductListControl()
    {
      InitializeComponent();
    }
  }
}
