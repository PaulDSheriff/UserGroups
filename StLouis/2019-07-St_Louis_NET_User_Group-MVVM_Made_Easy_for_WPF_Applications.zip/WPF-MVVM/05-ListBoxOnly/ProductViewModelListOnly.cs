﻿using System;
using System.Collections.ObjectModel;
using Common.Library;
using WPF.ListControls.EntityClasses;
using WPF.ListControls.Models;

namespace WPF_MVVM
{
  public class ProductViewModelListOnly : ViewModelBase
  {
    #region Constructor
    public ProductViewModelListOnly() : base() {
      LoadAll();
    }
    #endregion

    #region Products Property
    private ObservableCollection<Product> _Products;

    public ObservableCollection<Product> Products
    {
      get { return _Products; }
      set
      {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      try {
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = new ObservableCollection<Product>(db.Products);
        }
      }
      catch (Exception) {
        // Ignore design-time errors
      }
    }
    #endregion
  }
}
