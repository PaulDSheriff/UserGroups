﻿using System;
using Common.Library;

namespace WPF_MVVM
{
  public class SearchViewModel : ViewModelBase
  {
    #region Constructor
    public SearchViewModel() : base() {
      StartDate = DateTime.Now;
      EndDate = DateTime.Now.AddDays(14);
    }
    #endregion

    private DateTime _StartDate;
    private DateTime _EndDate;
    public DateTime StartDate
    {
      get { return _StartDate; }
      set
      {
        _StartDate = value;
        RaisePropertyChanged("StartDate");
      }
    }
    public DateTime EndDate
    {
      get { return _EndDate; }
      set
      {
        _EndDate = value;
        RaisePropertyChanged("EndDate");
      }
    }    

    #region Search Method
    public void Search() {
      // Do something else
      if (Validate()) {
      }
    }
    #endregion

    #region Validate Method
    public bool Validate() {
      // Use this to determine if the validation succeeds or not.
      IsMessageVisible = false;
      // Reset Message to Display
      Message = string.Empty;

      // Check Start Date versus End Date
      if (StartDate > EndDate) {
        Message = "Start Date Must Be Less Than End Date";
        IsMessageVisible = true;
      }

      return !IsMessageVisible;
    }
    #endregion
  }
}
