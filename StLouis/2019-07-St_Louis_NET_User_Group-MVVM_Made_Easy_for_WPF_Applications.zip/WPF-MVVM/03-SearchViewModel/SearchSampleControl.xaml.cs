﻿using System.Windows;
using System.Windows.Controls;

namespace WPF_MVVM
{
  public partial class SearchSampleControl : UserControl
  {
    public SearchSampleControl()
    {
      InitializeComponent();
      
      _ViewModel = (SearchViewModel)this.Resources["viewModel"];
    }

    SearchViewModel _ViewModel = null;

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Search();
    }
  }
}
