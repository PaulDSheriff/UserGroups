﻿using System.Windows;
using System.Windows.Controls;
using WPF.ListControls.EntityClasses;

namespace WPF_MVVM
{
  public partial class SimpleViewModelControl : UserControl
  {
    public SimpleViewModelControl()
    {
      InitializeComponent();

      _viewModel = (ProductViewModelSimple)this.Resources["viewModel"];
    }

    private ProductViewModelSimple _viewModel = null;

    private void EditButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Entity = (Product)((Button)sender).DataContext;
      _viewModel.SetModifyMode();
    }

    private void AddButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.AddRecord();
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SaveData();

    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.CancelEdit();

      // TODO: Write code to undo changes
    }
  }
}
