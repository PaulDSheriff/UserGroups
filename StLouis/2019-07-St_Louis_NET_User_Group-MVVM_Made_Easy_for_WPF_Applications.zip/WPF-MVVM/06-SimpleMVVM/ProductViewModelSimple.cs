﻿using System;
using System.Collections.ObjectModel;
using System.Data.Entity;
using Common.Library;
using WPF.ListControls.EntityClasses;
using WPF.ListControls.Models;

namespace WPF_MVVM
{
  public class ProductViewModelSimple : ViewModelBase
  {
    #region Constructor
    public ProductViewModelSimple() : base()
    {
      LoadAll();
    }
    #endregion

    #region Private Variables
    private ObservableCollection<Product> _Products;
    private Product _Entity;

    private bool _IsAddMode = false;
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    private bool _IsListEnabled = true;
    private bool _IsDetailEnabled = false;
    private int _SelectedListIndex = -1;
    private string _Message = string.Empty;
    #endregion

    #region Public Properties
    public ObservableCollection<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }

    public Product Entity
    {
      get { return _Entity; }
      set {
        _Entity = value;
        RaisePropertyChanged("Entity");
      }
    }

    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set {
        _IsSaveEnabled = value;
        RaisePropertyChanged("IsSaveEnabled");
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set {
        _IsCancelEnabled = value;
        RaisePropertyChanged("IsCancelEnabled");
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set {
        _IsAddEnabled = value;
        RaisePropertyChanged("IsAddEnabled");
      }
    }

    public bool IsListEnabled
    {
      get { return _IsListEnabled; }
      set {
        _IsListEnabled = value;
        RaisePropertyChanged("IsListEnabled");
      }
    }

    public int SelectedListIndex
    {
      get { return _SelectedListIndex; }
      set {
        _SelectedListIndex = value;
        RaisePropertyChanged("SelectedListIndex");
      }
    }

    public bool IsDetailEnabled
    {
      get { return _IsDetailEnabled; }
      set {
        _IsDetailEnabled = value;
        RaisePropertyChanged("IsDetailEnabled");
      }
    }

    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set {
        _IsAddMode = value;
        RaisePropertyChanged("IsAddMode");
      }
    }
    #endregion

    #region SetListMode Method
    public void SetListMode()
    {
      IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
      IsListEnabled = true;
      IsDetailEnabled = false;
    }
    #endregion

    #region SetModifyMode Method
    public void SetModifyMode()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
      IsListEnabled = false;
      IsDetailEnabled = true;
      Message = string.Empty;
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      try {
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = new ObservableCollection<Product>(db.Products);
          if (Products.Count > 0) {
            Entity = Products[0];
          }
        }
      }
      catch (Exception) {
        // Ignore design-time errors
      }
    }
    #endregion

    #region AddRecord Method
    public void AddRecord()
    {
      SetModifyMode();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      Entity = new Product {
        ProductID = -99,
        ProductNumber = "Test-1",
        Color = "Red",
        ListPrice = 99,
        StandardCost = 50,
        ModifiedDate = DateTime.Now,
        SellStartDate = DateTime.Now,
        Size = "1 foot"
      };
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      SetListMode();

      IsAddMode = false;
      Message = string.Empty;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData()
    {
      if (IsAddMode) {
        InsertData();
      }
      else {
        UpdateData();
      }

      SetListMode();
    }
    #endregion

    #region Insert Data
    public void InsertData()
    {
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          db.Products.Add(Entity);
          db.SaveChanges();

          Products.Add(Entity);
          Message = "Insert Successful";
        }
        catch (Exception ex) {
          Message = ex.Message;
        }
      }
    }
    #endregion

    #region Update Data
    public void UpdateData()
    {
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          Product entity = db.Products.Find(Entity.ProductID);
          if (entity != null) {
            db.Entry(entity).State = EntityState.Modified;
            db.SaveChanges();
            Message = "Update Successful";
          }
        }
        catch (Exception ex) {
          Message = ex.Message;
        }
      }
    }
    #endregion
  }
}
