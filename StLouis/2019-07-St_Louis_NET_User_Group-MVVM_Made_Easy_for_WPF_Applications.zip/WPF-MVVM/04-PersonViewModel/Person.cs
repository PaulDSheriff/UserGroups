﻿using System;
using System.ComponentModel.DataAnnotations;
using Common.Library;

namespace WPF_MVVM.PersonViewModelSample
{
  public class Person : CommonBase
  {
    #region Constructor
    public Person()
    {
      FirstName = string.Empty;
      LastName = string.Empty;
      BirthDate = DateTime.Now.AddYears(-20);
    }
    #endregion

    #region Private Variables
    private string _FirstName;
    private string _LastName;
    private DateTime _BirthDate;
    #endregion

    #region Public Properties
    [Required]
    public string FirstName
    {
      get { return _FirstName; }
      set {
        _FirstName = value;
        RaisePropertyChanged("FirstName");
      }
    }

    [Required]
    public string LastName
    {
      get { return _LastName; }
      set {
        _LastName = value;
        RaisePropertyChanged("LastName");
      }
    }

    public DateTime BirthDate
    {
      get { return _BirthDate; }
      set {
        _BirthDate = value;
        RaisePropertyChanged("BirthDate");
      }
    }
    #endregion
  }
}
