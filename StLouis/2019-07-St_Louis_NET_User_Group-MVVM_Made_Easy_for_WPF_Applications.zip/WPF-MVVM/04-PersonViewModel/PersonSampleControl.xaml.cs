﻿using System.Windows;
using System.Windows.Controls;
using WPF_MVVM.PersonViewModelSample;

namespace WPF_MVVM
{
  public partial class PersonSampleControl : UserControl
  {
    public PersonSampleControl()
    {
      InitializeComponent();

      _viewModel = (PersonViewModel)this.Resources["viewModel"];
    }

    PersonViewModel _viewModel = null;

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Validate();
    }
  }
}
