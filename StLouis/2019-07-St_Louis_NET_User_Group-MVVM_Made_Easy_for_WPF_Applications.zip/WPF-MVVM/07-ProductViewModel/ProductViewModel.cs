﻿using System;
using System.Collections.ObjectModel;
using System.Data.Entity;
using Common.Library;
using WPF.ListControls.EntityClasses;
using WPF.ListControls.Models;

namespace WPF_MVVM
{
  public class ProductViewModel : ViewModelAddEditDeleteBase
  {  
    #region Private Variables
    private ObservableCollection<Product> _Products;
    private Product _Entity;
    #endregion

    #region Public Properties
    public ObservableCollection<Product> Products
    {
      get { return _Products; }
      set
      {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
  
    public Product Entity
    {
      get { return _Entity; }
      set
      {
        _Entity = value;
        RaisePropertyChanged("Entity");
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll() {
      try {
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = new ObservableCollection<Product>(db.Products);
          if (Products.Count > 0) {
            Entity = Products[0];
          }
        }
      }
      catch (Exception) {
        // Ignore design-time errors
      }
    }
    #endregion

    #region AddRecord Method
    public void AddRecord() {
      SetModifyMode();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      Entity = new Product {
        ProductID = -99,
        ProductNumber = "Test-1",
        Color = "Red",
        ListPrice = 99,
        StandardCost = 50,
        ModifiedDate = DateTime.Now,
        SellStartDate = DateTime.Now,
        Size = "1 foot"
      };
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit() {
      SetListMode();

      IsAddMode = false;
      Message = string.Empty;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData() {
      if (IsAddMode) {
        InsertData();
      }
      else {
        UpdateData();
      }

      SetListMode();
    }
    #endregion

    #region Insert Data
    public void InsertData()
    {
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          db.Products.Add(_Entity);
          db.SaveChanges();

          Products.Add(_Entity);
          Message = "Insert Successful";
        }
        catch (Exception ex) {
          Message = ex.Message;
        }
      }
    }
    #endregion

    #region Update Data
    public void UpdateData()
    {
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        try {
          Product entity = db.Products.Find(_Entity.ProductID);
          if (entity != null) {
            db.Entry(entity).State = EntityState.Modified;
            db.SaveChanges();
            Message = "Update Successful";
          }
        }
        catch (Exception ex) {
          Message = ex.Message;
        }
      }
    }
    #endregion
  }
}
