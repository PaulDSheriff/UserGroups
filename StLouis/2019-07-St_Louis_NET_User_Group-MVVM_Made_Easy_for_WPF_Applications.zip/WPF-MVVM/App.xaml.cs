﻿using System.Windows;

namespace WPF_MVVM
{
  public partial class App : Application
  {
  }
}
