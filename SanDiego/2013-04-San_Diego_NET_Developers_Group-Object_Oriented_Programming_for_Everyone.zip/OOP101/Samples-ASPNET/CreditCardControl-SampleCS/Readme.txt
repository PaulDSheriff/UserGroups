This is a User Control that will allow you to accept credit cards quickly and easily. I have not put any credit card number validator in here, since you can easily find these algorithms all over the internet. Just do a search on ".NET Credit Card Validation" and you will find quite a few. Below is the one that I use on my sites.
http://www.codeproject.com/aspnet/creditcardvalidator.asp
