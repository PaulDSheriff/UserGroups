
Partial Class Interfaces_InterfaceSample2
  Inherits System.Web.UI.Page

  Private Const SQL As String = "SELECT * FROM oopUsers"

  Protected Sub btnSqlClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSqlClient.Click
    LoadUsers("SqlClient")
  End Sub

  Protected Sub btnOleDb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOleDb.Click
    LoadUsers("OleDb")
  End Sub

  Private Sub LoadUsers(ByVal DataProvider As String)
    Dim ds As New DataSet
    Dim da As IDbDataAdapter = Nothing

    Select Case DataProvider
      Case "SqlClient"
        da = New SqlClient.SqlDataAdapter(SQL, AppConfig.ConnectString)

      Case "OleDb"
        da = New OleDb.OleDbDataAdapter(SQL, ConfigurationManager.ConnectionStrings("SandboxOleDb").ConnectionString)

    End Select

    da.Fill(ds)

    grdUsers.DataSource = ds
    grdUsers.DataBind()
  End Sub
End Class
