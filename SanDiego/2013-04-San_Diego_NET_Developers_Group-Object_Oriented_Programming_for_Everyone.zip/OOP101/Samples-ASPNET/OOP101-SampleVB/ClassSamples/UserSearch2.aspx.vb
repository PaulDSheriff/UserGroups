
Partial Class ClassSamples_UserSearch2
    Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    If Not Page.IsPostBack Then
      Dim ds As DataSet

      ds = DataLayer.GetDataSet("SELECT * FROM oopUsers", _
        AppConfig.ConnectString)

      grdUsers.DataSource = ds
      grdUsers.DataBind()
    End If
  End Sub

  Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
    Dim sql As String = String.Empty
    Dim where As String = " WHERE "
    Dim ds As DataSet

    If txtFirstName.Text.Trim() <> String.Empty Then
      sql &= where & " FirstName LIKE '" & txtFirstName.Text & "%'"
      where = " AND "
    End If
    If txtLastName.Text.Trim() <> String.Empty Then
      sql &= where & " LastName LIKE '" & txtLastName.Text & "%'"
      where = " AND "
    End If
    If txtEmailAddress.Text.Trim() <> String.Empty Then
      sql &= where & " Email LIKE '%" & txtEmailAddress.Text & "%'"
      where = " AND "
    End If

    ds = DataLayer.GetDataSet("SELECT * FROM oopUsers " & sql, _
     AppConfig.ConnectString)

    grdUsers.DataSource = ds
    grdUsers.DataBind()
  End Sub
End Class
