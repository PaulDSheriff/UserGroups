
Partial Class ClassSamples_InstanceSharedSample
    Inherits System.Web.UI.Page

  Protected Sub btnInstance_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstance.Click
    Dim cmd1 As New MyCommandInstance
    Dim cmd2 As New MyCommandInstance

    cmd1.CommandText = "SELECT * FROM Products"
    cmd2.CommandText = "SELECT * FROM Users"

    System.Diagnostics.Debugger.Break()
    ' Look at each CommandText property
  End Sub

  Protected Sub btnShared_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShared.Click
    ' The following does not make sense
    Dim cmd1 As New MyCommandShared
    Dim cmd2 As New MyCommandShared
    'cmd1.CommandText = "SELECT * FROM Products" ' Not valid

    MyCommandShared.CommandText = "SELECT * FROM Products"
    MyCommandShared.CommandText = "SELECT * FROM Users"

    System.Diagnostics.Debugger.Break()
    ' Look at each CommandText property
  End Sub
End Class
