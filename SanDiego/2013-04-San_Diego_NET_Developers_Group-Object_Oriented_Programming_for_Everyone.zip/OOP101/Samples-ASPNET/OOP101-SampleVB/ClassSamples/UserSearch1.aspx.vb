Imports System.Data
Imports System.Data.SqlClient

Partial Class ClassSamples_UserSearch1
    Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    If Not Page.IsPostBack Then
      Dim ds As New DataSet
      Dim da As SqlClient.SqlDataAdapter

      da = New SqlClient.SqlDataAdapter("SELECT * FROM oopUsers", _
        "Server=Localhost;Database=Sandbox;uid=sa;pwd=P@ssw0rd")
      da.Fill(ds)

      grdUsers.DataSource = ds
      grdUsers.DataBind()
    End If
  End Sub

  Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
    Dim sql As String = String.Empty
    Dim where As String = " WHERE "
    Dim ds As New DataSet
    Dim da As SqlClient.SqlDataAdapter

    If txtFirstName.Text.Trim() <> String.Empty Then
      sql &= where & " FirstName LIKE '" & txtFirstName.Text & "%'"
      where = " AND "
    End If
    If txtLastName.Text.Trim() <> String.Empty Then
      sql &= where & " LastName LIKE '" & txtLastName.Text & "%'"
      where = " AND "
    End If
    If txtEmailAddress.Text.Trim() <> String.Empty Then
      sql &= where & " Email LIKE '%" & txtEmailAddress.Text & "%'"
      where = " AND "
    End If

    da = New SqlClient.SqlDataAdapter("SELECT * FROM oopUsers " & sql, _
      "Server=Localhost;Database=Sandbox;uid=sa;pwd=P@ssw0rd")
    da.Fill(ds)

    grdUsers.DataSource = ds
    grdUsers.DataBind()
  End Sub
End Class
