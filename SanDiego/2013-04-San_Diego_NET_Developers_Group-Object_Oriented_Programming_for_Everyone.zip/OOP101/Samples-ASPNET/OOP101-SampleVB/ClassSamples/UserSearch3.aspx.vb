
Partial Class ClassSamples_UserSearch3
    Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    Dim bo As Users

    If Not Page.IsPostBack Then
      bo = New Users

      grdUsers.DataSource = bo.GetAllUsers()
      grdUsers.DataBind()
    End If
  End Sub

  Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
    Dim bo As New Users
    Dim us As New UsersSearch

    us.FirstName = txtFirstName.Text.Trim()
    us.LastName = txtLastName.Text.Trim()
    us.Email = txtEmailAddress.Text.Trim()

    grdUsers.DataSource = bo.GetUsersByFilter(us)
    grdUsers.DataBind()
  End Sub
End Class
