This Sample Requires VS.NET 2005 with Service Pack 1

Also, be sure to change the Connection Strings in the various samples and in the Web.Config file to your server name and database where you install the SQL Scripts located in the \SQLScripts folder.
