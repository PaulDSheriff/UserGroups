
Partial Class Overloading_OverloadingSample2
  Inherits System.Web.UI.Page

  Protected Sub btnGetDataSet1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetDataSet1.Click
    GetDataSetSQL()
  End Sub

  Protected Sub btnGetDataSet2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetDataSet2.Click
    GetDataSetCmd()
  End Sub

  Private Sub GetDataSetSQL()
    Dim sql As String

    sql = "SELECT * FROM oopUsers"

    grdUsers.DataSource = DataLayer2.GetDataSet(sql, AppConfig.ConnectString)
    grdUsers.DataBind()
  End Sub

  Private Sub GetDataSetCmd()
    Dim cmd As SqlCommand

    cmd = New SqlCommand("SELECT * FROM oopUsers")
    cmd.Connection = New SqlConnection(AppConfig.ConnectString)
    cmd.Connection.Open()

    grdUsers.DataSource = DataLayer2.GetDataSet(cmd)
    grdUsers.DataBind()

    cmd.Connection.Close()
    cmd.Connection.Dispose()
  End Sub
End Class
