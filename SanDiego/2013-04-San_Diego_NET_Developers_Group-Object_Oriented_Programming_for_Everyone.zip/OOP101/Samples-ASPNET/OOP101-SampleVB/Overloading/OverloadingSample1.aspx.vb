
Partial Class Overloading_OverloadingSample1
  Inherits System.Web.UI.Page

  Private Const SQL As String = "SELECT * FROM oopUsers"

  Private Enum DataProviderEnum
    SqlClient
    OleDb
  End Enum

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

  End Sub

  Protected Sub btnSqlClient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSqlClient.Click
    LoadUsers(DataProviderEnum.SqlClient)
  End Sub

  Protected Sub btnOleDb_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOleDb.Click
    LoadUsers(DataProviderEnum.OleDb)
  End Sub

  '** OVERLOADED **
  Private Sub LoadUsers(ByVal DataProvider As String)
    Select Case DataProvider.ToLower()
      Case "sqlclient"
        LoadUsers(DataProviderEnum.SqlClient)

      Case "oledb"
        LoadUsers(DataProviderEnum.OleDb)

    End Select
  End Sub

  '** OVERLOADED **
  Private Sub LoadUsers(ByVal DataProvider As DataProviderEnum)
    Dim ds As New DataSet
    Dim da As IDbDataAdapter = Nothing

    Select Case DataProvider
      Case DataProviderEnum.SqlClient
        da = New SqlClient.SqlDataAdapter(SQL, AppConfig.ConnectString)

      Case DataProviderEnum.OleDb
        da = New OleDb.OleDbDataAdapter(SQL, ConfigurationManager.ConnectionStrings("SandboxOleDb").ConnectionString)

    End Select

    da.Fill(ds)

    grdUsers.DataSource = ds
    grdUsers.DataBind()
  End Sub
End Class
