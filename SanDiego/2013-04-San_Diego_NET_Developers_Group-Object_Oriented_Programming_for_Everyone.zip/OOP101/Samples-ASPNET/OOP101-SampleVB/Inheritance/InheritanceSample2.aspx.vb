
Partial Class Inheritance_InheritanceSample2
  Inherits System.Web.UI.Page

  Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    lblMsg.Text = "Hello World"
  End Sub

  Private Sub InheritanceSample1_PreInit(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreInit
    Me.Theme = "Blue"
  End Sub
End Class
