
Partial Class Inheritance_InheritanceSample1
    Inherits System.Web.UI.Page

  Protected Sub btnPerson_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPerson.Click
    Dim p As New Person

    p.FirstName = "John"
    p.LastName = "Doe"

    ' Salary is not available
    'p.Salary = Convert.ToDecimal(50000.0)
  End Sub

  Protected Sub btnEmployee_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmployee.Click
    Dim pe As New Employee

    pe.FirstName = "John"
    pe.LastName = "Doe"
    pe.Salary = Convert.ToDecimal(50000.0)
  End Sub

  Protected Sub btnPerson2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPerson2.Click
    Dim p As New Person2

    p.FirstName = "John"
    p.LastName = "Doe"

    lblName.Text = p.FullName
  End Sub

  Protected Sub btnEmployee2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEmployee2.Click
    Dim pe As New Employee2

    pe.FirstName = "John"
    pe.LastName = "Doe"
    pe.Salary = Convert.ToDecimal(50000.0)

    lblName.Text = pe.FullName
  End Sub
End Class
