Public Class TestClass2
  Implements ITest

  Public Function InformUser() As String Implements ITest.InformUser
    Return "Hello from TestClass2"
  End Function
End Class
