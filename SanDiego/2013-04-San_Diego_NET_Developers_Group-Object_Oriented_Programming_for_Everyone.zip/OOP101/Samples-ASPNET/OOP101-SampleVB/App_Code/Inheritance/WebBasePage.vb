Imports System.Configuration

Public Class WebBasePage
  Inherits System.Web.UI.Page

  Private mUserTrack As Boolean = False

  Protected Property UserTrack() As Boolean
    Get
      Return mUserTrack
    End Get
    Set(ByVal value As Boolean)
      mUserTrack = value
    End Set
  End Property

  Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
    ' Do something before

    ' Set Default value for UserTrack Property
    mUserTrack = Convert.ToBoolean(ConfigurationManager.AppSettings("UserTrack"))


    ' Call Page Event
    MyBase.OnLoad(e)


    ' Do something After

    ' Check UserTrack property
    ' User could change it in Page_Load()
    If mUserTrack Then
      ' Call TrackUsers method
    End If
  End Sub

  Protected Overrides Sub OnPreInit(ByVal e As System.EventArgs)
    ' Try moving this after the MyBase.OnPreInit() call
    Me.Theme = ConfigurationManager.AppSettings("Theme")

    MyBase.OnPreInit(e)
  End Sub
End Class