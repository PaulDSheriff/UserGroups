Public Class Employee2
  Inherits Person2

  Private mSalary As Decimal

  Public Property Salary() As Decimal
    Get
      Return mSalary
    End Get
    Set(ByVal Value As Decimal)
      mSalary = Value
    End Set
  End Property

  Protected Overrides Sub CreateFullName()
    MyBase.FullName = MyBase.FirstName & " " & MyBase.LastName
  End Sub
End Class