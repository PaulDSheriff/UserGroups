Public Class EventSampler1
  Public Event Before(ByVal message As String)
  Public Event After(ByVal message As String)

  Public Sub Process()
    RaiseEvent Before("Before the Process")

    For index As Integer = 1 To 10000000

    Next

    RaiseEvent After("After the Process")
  End Sub
End Class
