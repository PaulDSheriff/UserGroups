<Serializable()> Public Class PDSAAddress
	Public Enum PDSAAddressTypeEnum As Integer
		US
		Canadian
		UK
		Other
	End Enum

	Private mObjectId As Guid = Guid.NewGuid
	Private mType As PDSAAddressTypeEnum = PDSAAddressTypeEnum.US
  Private mAddress1 As String = String.Empty
  Private mAddress2 As String = String.Empty
  Private mAddress3 As String = String.Empty
  Private mCity As String = String.Empty
  Private mVillage As String = String.Empty
  Private mStateId As Integer = Integer.MinValue
  Private mStateCode As String = String.Empty
  Private mStateName As String = String.Empty
  Private mCountryId As Integer = Integer.MinValue
  Private mCountryCode As String = String.Empty
  Private mCountryName As String = String.Empty
  Private mPostalCode As String = String.Empty
  Private mPostalCodeExt As String = String.Empty

  Public ReadOnly Property ObjectId() As Guid
    Get
      Return Me.mObjectId
    End Get
  End Property

  Public Property Type() As PDSAAddressTypeEnum
    Get
      Return Me.mType
    End Get
    Set(ByVal Value As PDSAAddressTypeEnum)
      Me.mType = Value
    End Set
  End Property

  Public Property Address1() As String
    Get
      Return Me.mAddress1
    End Get
    Set(ByVal Value As String)
      Me.mAddress1 = Value
    End Set
  End Property

  Public Property Address2() As String
    Get
      Return Me.mAddress2
    End Get
    Set(ByVal Value As String)
      Me.mAddress2 = Value
    End Set
  End Property

  Public Property Address3() As String
    Get
      Return Me.mAddress3
    End Get
    Set(ByVal Value As String)
      Me.mAddress3 = Value
    End Set
  End Property

  Public Property City() As String
    Get
      Return Me.mCity
    End Get
    Set(ByVal Value As String)
      Me.mCity = Value
    End Set
  End Property

  Public Property Village() As String
    Get
      Return Me.mVillage
    End Get
    Set(ByVal Value As String)
      Me.mVillage = Value
    End Set
  End Property

  Public Property StateId() As Integer
    Get
      Return Me.mStateId
    End Get
    Set(ByVal Value As Integer)
      Me.mStateId = Value
    End Set
  End Property

  Public Property StateCode() As String
    Get
      Return Me.mStateCode
    End Get
    Set(ByVal Value As String)
      Me.mStateCode = Value
    End Set
  End Property

  Public Property StateName() As String
    Get
      Return Me.mStateName
    End Get
    Set(ByVal Value As String)
      Me.mStateName = Value
    End Set
  End Property

  Public Property CountryId() As Integer
    Get
      Return Me.mCountryId
    End Get
    Set(ByVal Value As Integer)
      Me.mCountryId = Value
    End Set
  End Property

  Public Property CountryCode() As String
    Get
      Return Me.mCountryCode
    End Get
    Set(ByVal Value As String)
      Me.mCountryCode = Value
    End Set
  End Property

  Public Property CountryName() As String
    Get
      Return Me.mCountryName
    End Get
    Set(ByVal Value As String)
      Me.mCountryName = Value
    End Set
  End Property

  Public Property PostalCode() As String
    Get
      Return Me.mPostalCode
    End Get
    Set(ByVal Value As String)
      Me.mPostalCode = Value
    End Set
  End Property

  Public Property PostalCodeExt() As String
    Get
      Return Me.mPostalCodeExt
    End Get
    Set(ByVal Value As String)
      Me.mPostalCodeExt = Value
    End Set
  End Property

  Public Overridable Function Validate() As Boolean
    Dim isValid As Boolean = True

    ' Require Address1
    If Me.mAddress1.Length = 0 Then
      isValid = False
    End If

    ' Require City
    If Me.mCity.Length = 0 Then
      isValid = False
    End If

    'Require State for Canada and US
    If Me.mType = PDSAAddressTypeEnum.Canadian Or Me.mType = PDSAAddressTypeEnum.US Then
      If Me.mStateName.Length = 0 And _
       Me.mStateCode.Length = 0 And _
       Me.mStateId > 0 Then
        isValid = False
      End If
    End If

    ' Require Postal Code
    If Me.mPostalCode.Length = 0 Then
      isValid = False
    End If

    Return isValid
  End Function

  Public Function GetFullAddress() As String
    'Returns an strAddr in the following format
    '1234 Street
    'PO Box 1234
    'Route(4)
    'City, State 90210-1234

    Dim addr As String

    addr = Me.mAddress1

    If Me.mAddress2.Length > 0 Then
      addr &= vbCrLf & Me.mAddress2
    End If

    If Me.mAddress3.Length > 0 Then
      addr &= vbCrLf & Me.mAddress3
    End If

    addr &= vbCrLf & Me.mCity

    If Me.mType <> PDSAAddressTypeEnum.Other Then
      If Me.mStateName.Trim() <> "" Then
        addr &= ", " & Me.mStateName
      Else
        addr &= ", " & Me.mStateCode
      End If
    End If

    addr &= "  " & Me.mPostalCode

    If Me.mType <> PDSAAddressTypeEnum.Other And Me.mPostalCodeExt.Trim() <> String.Empty Then
      addr &= " - " & Me.mPostalCodeExt
    End If

    Return addr
  End Function

	Public Overrides Function ToString() As String
		Return GetFullAddress()
	End Function
End Class
