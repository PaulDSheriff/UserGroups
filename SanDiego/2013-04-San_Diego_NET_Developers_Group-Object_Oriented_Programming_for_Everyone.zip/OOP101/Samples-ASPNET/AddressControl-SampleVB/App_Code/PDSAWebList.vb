Imports System.Web.UI.WebControls

Public Class PDSAWebList
  Public Shared Sub DropDownFindByText(ByRef ddl As DropDownList, ByVal value As String)
    Dim di As ListItem

    di = ddl.Items.FindByText(value)
    If Not (di Is Nothing) Then
      di.Selected = True
    End If
  End Sub

  Public Overloads Shared Sub DropDownFindByValue(ByRef ddl As DropDownList, ByVal value As Integer)
    Dim di As ListItem

    di = ddl.Items.FindByValue(value.ToString())
    If Not (di Is Nothing) Then
      di.Selected = True
    End If
  End Sub

  Public Overloads Shared Sub DropDownFindByValue(ByRef ddl As DropDownList, ByVal value As String)
    Dim di As ListItem

    di = ddl.Items.FindByValue(value)
    If Not (di Is Nothing) Then
      di.Selected = True
    End If
  End Sub
End Class
