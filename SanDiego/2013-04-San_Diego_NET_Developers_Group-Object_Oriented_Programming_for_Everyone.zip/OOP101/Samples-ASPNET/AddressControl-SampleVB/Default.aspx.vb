
Partial Class _Default
    Inherits System.Web.UI.Page

  Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
    Session("PDSAAddress") = Me.UcAddress1.GetUserData()

    Response.Redirect("AddressDisplaySample.aspx")
  End Sub
End Class
