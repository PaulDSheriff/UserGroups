Partial Class UserControls_ucAddressDisplay
	Inherits System.Web.UI.UserControl

	Public Sub SetUserData(ByVal address As PDSAAddress)
		Dim sb As New StringBuilder(1024)

		sb.Append(address.Address1)
		sb.Append("<br />")
		If address.Address2.Trim() <> String.Empty Then
			sb.Append(address.Address2)
			sb.Append("<br />")
		End If
		If address.Address3.Trim() <> String.Empty Then
			sb.Append(address.Address3)
			sb.Append("<br />")
		End If
		If address.City.Trim() <> String.Empty Then
			sb.Append(address.City)
		End If
		If address.Village.Trim() <> String.Empty Then
			sb.Append(address.Village)
		End If
		If address.StateName.Trim() <> String.Empty Then
			sb.Append(", " & address.StateName)
		ElseIf address.StateCode.Trim() <> String.Empty Then
			sb.Append(", " & address.StateCode)
		End If
		If address.PostalCode.Trim() <> String.Empty Then
			sb.Append(" " & address.PostalCode)
			If address.PostalCodeExt <> String.Empty Then
				sb.Append("-" & address.PostalCodeExt)
			End If
			sb.Append("<br />")
		End If
		If address.CountryName.Trim() <> String.Empty Then
			sb.Append(address.CountryName)
			sb.Append("<br />")
		ElseIf address.CountryCode.Trim() <> String.Empty Then
			sb.Append(address.CountryCode)
			sb.Append("<br />")
		End If

		lblAddress.Text = sb.ToString()
	End Sub
End Class
