Imports System.Data

Partial Class UserControls_ucCreditCard
	Inherits System.Web.UI.UserControl

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		If Not Page.IsPostBack Then
			CardTypesLoad()
			MonthLoad()
			YearLoad()
		End If
	End Sub

	Private Sub CardTypesLoad()
		Dim ds As New DataSet

		ds.ReadXml(Server.MapPath("~/Xml-Common/CreditCardTypes.xml"))

		ddlCreditCards.DataTextField = "Name"
		ddlCreditCards.DataValueField = "Name"
		ddlCreditCards.DataSource = ds
		ddlCreditCards.DataBind()
	End Sub

	Private Sub MonthLoad()
    Dim index As Integer

    For index = 1 To 12
      ddlMonth.Items.Add(index.ToString() & "-" & GetMonthName(index))
    Next
	End Sub

	Private Sub YearLoad()
    Dim index As Integer

    For index = Now.Year To (Now.Year + 12)
      ddlYear.Items.Add(index.ToString())
    Next
	End Sub

	Private Function GetMonthName(ByVal Value As Integer) As String
		Dim dtfi As New System.Globalization.DateTimeFormatInfo
		Dim arr() As String

		arr = dtfi.MonthNames

		Return arr(Value - 1)
	End Function

	Public Function GetUserData() As PDSACreditCard
		Dim cc As New PDSACreditCard
    Dim ccNum As String

    ccNum = txtCardNumber.Text.Trim()
    ccNum = ccNum.Replace(" ", "")
    ccNum = ccNum.Replace("-", "")
    ccNum = ccNum.Replace("/", "")
    ccNum = ccNum.Replace("\", "")
    ccNum = ccNum.Replace(".", "")

    cc.CreditCardNumber = ccNum
		cc.CreditCardType = ddlCreditCards.SelectedItem.Text
		cc.CVCode = txtCVCode.Text
		cc.NameOnCard = txtName.Text
		cc.ExpMonth = ddlMonth.SelectedItem.Text
		cc.ExpYear = ddlYear.SelectedItem.Text
		cc.BillingPostalCode = txtZipCode.Text

		Return cc
	End Function

	Public Sub SetUserData(ByVal cc As PDSACreditCard)
    Dim ccNum As String

    ccNum = cc.CreditCardNumber.Trim()

    If ccNum.Length > 4 Then
      txtCardNumber.Text = "**********" & ccNum.Substring(ccNum.Length - 4)
    Else
      If ccNum.Length = 0 Then
        txtCardNumber.Text = ""
      Else
        txtCardNumber.Text = "*********************"
      End If
    End If
		PDSAWebList.DropDownFindByText(ddlCreditCards, cc.CreditCardType)
		txtName.Text = cc.NameOnCard
		txtCVCode.Text = cc.CVCode
		PDSAWebList.DropDownFindByText(ddlMonth, cc.ExpMonth)
		PDSAWebList.DropDownFindByText(ddlYear, cc.ExpYear)
		txtZipCode.Text = cc.BillingPostalCode
	End Sub
End Class
