
Partial Class _Default
    Inherits System.Web.UI.Page

	Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
		Dim cc As PDSACreditCard

		cc = ucCC.GetUserData()

		Session("PDSACC") = cc

		Response.Redirect("CCDisplay.aspx")
	End Sub
End Class
