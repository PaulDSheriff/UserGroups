<Serializable()> Public Class PDSACreditCard
  Private mCreditCardType As String = "Visa"
  Private mNameOnCard As String = String.Empty
  Private mCreditCardNumber As String = String.Empty
  Private mExpMonth As String = String.Empty
  Private mExpYear As String = String.Empty
  Private mCVCode As String = String.Empty
  Private mBillingPostalCode As String = String.Empty

  Public Property BillingPostalCode() As String
    Get
      Return mBillingPostalCode
    End Get
    Set(ByVal Value As String)
      mBillingPostalCode = Value
    End Set
  End Property

  Public Property CreditCardType() As String
    Get
      Return mCreditCardType
    End Get
    Set(ByVal Value As String)
      mCreditCardType = Value
    End Set
  End Property

  Public Property NameOnCard() As String
    Get
      Return mNameOnCard
    End Get
    Set(ByVal Value As String)
      mNameOnCard = Value
    End Set
  End Property

  Public Property CreditCardNumber() As String
    Get
      Return mCreditCardNumber
    End Get
    Set(ByVal Value As String)
      mCreditCardNumber = Value
    End Set
  End Property

  Public Property ExpMonth() As String
    Get
      Return mExpMonth
    End Get
    Set(ByVal Value As String)
      mExpMonth = Value
    End Set
  End Property

  Public Property ExpYear() As String
    Get
      Return mExpYear
    End Get
    Set(ByVal Value As String)
      mExpYear = Value
    End Set
  End Property

  Public Property CVCode() As String
    Get
      Return mCVCode
    End Get
    Set(ByVal Value As String)
      mCVCode = Value
    End Set
  End Property
End Class