
Partial Class CCDisplay
    Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
		Dim cc As PDSACreditCard

		If Session("PDSACC") IsNot Nothing Then
			cc = CType(Session("PDSACC"), PDSACreditCard)

			ucCCDisplay.SetUserData(cc)
		End If
	End Sub
End Class
