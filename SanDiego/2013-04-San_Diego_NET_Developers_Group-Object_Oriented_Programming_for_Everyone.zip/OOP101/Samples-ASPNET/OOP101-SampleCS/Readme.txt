Be sure to change the Connection Strings in the various samples and in the Web.Config file to your server name and database where you install the SQL Scripts located in the \SQLScripts folder.
