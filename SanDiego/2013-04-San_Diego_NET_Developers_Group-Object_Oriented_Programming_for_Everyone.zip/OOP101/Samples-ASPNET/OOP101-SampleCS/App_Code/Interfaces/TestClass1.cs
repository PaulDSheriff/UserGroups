public class TestClass1 : ITest
{
  public string InformUser()
  {
    return "Hello from TestClass1";
  }

}