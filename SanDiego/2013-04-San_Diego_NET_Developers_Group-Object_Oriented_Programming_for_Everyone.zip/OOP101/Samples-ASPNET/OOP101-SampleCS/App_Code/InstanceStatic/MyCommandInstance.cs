public class MyCommandInstance
{
  private string mCommandText = string.Empty;

  public string CommandText
  {
    get { return mCommandText; }
    set { mCommandText = value; }
  }
}