﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Windows

Partial Public Class frmInterface2
  Inherits Window

  Private Const SQL As String = "SELECT * FROM oopUsers"

  Protected Sub btnSqlClient_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUsers("SqlClient")
  End Sub

  Protected Sub btnOleDbClient_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUsers("OleDb")
  End Sub

  Private Sub LoadUsers(ByVal DataProvider As String)
    Dim dt As New DataTable()
    Dim da As IDbDataAdapter = Nothing

    Select Case DataProvider
      Case "SqlClient"
        da = New System.Data.SqlClient.SqlDataAdapter(SQL, AppConfig.ConnectString)
        DirectCast(da, SqlDataAdapter).Fill(dt)

        Exit Select
      Case "OleDb"
        da = New System.Data.OleDb.OleDbDataAdapter(SQL, AppConfig.ConnectStringOleDb)
        DirectCast(da, OleDbDataAdapter).Fill(dt)

        Exit Select
    End Select


    lstUsers.DataContext = dt
  End Sub
End Class