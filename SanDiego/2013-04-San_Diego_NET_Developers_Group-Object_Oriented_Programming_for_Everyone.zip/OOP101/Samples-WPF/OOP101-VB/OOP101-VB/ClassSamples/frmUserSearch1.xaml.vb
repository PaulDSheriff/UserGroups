﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows

Partial Public Class frmUserSearch1
  Inherits Window

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    UserLoad()
  End Sub

  Private Sub UserLoad()
    Dim dt As New DataTable()
    Dim da As SqlDataAdapter = Nothing

    da = New SqlDataAdapter("SELECT * FROM oopUsers", "Server=Localhost;Database=Sandbox;Integrated Security=Yes")
    da.Fill(dt)

    lstUsers.DataContext = dt
  End Sub

  Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    UserSearch()
  End Sub

  Private Sub UserSearch()
    Dim sql As String = String.Empty
    Dim where As String = " WHERE "
    Dim dt As New DataTable()
    Dim da As SqlDataAdapter = Nothing

    If txtSearchFirstName.Text.Trim() <> String.Empty Then
      sql += (where & " FirstName LIKE '") + txtSearchFirstName.Text & "%'"
      where = " AND "
    End If
    If txtSearchLastName.Text.Trim() <> String.Empty Then
      sql += (where & " LastName LIKE '") + txtSearchLastName.Text & "%'"
      where = " AND "
    End If
    If txtSearchEmail.Text.Trim() <> String.Empty Then
      sql += (where & " Email LIKE '%") + txtSearchEmail.Text & "%'"
      where = " AND "
    End If

    da = New SqlDataAdapter("SELECT * FROM oopUsers " & sql, "Server=Localhost;Database=Sandbox;Integrated Security=Yes")
    da.Fill(dt)

    lstUsers.DataContext = dt
  End Sub
End Class