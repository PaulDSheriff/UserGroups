﻿Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Windows

Partial Public Class frmEnums
  Inherits Window

  Private Const SQL As String = "SELECT * FROM oopUsers"

  Private Enum DataProviderEnum
    SqlClient
    OleDb
  End Enum

  Protected Sub btnSqlClient_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUsers(DataProviderEnum.SqlClient)
  End Sub

  Private Sub btnOleDbClient_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    LoadUsers(DataProviderEnum.OleDb)
  End Sub

  Private Sub LoadUsers(ByVal DataProvider As DataProviderEnum)
    Dim dt As New DataTable()
    Dim da As IDbDataAdapter = Nothing

    Select Case DataProvider
      Case DataProviderEnum.SqlClient
        da = New System.Data.SqlClient.SqlDataAdapter(SQL, AppConfig.ConnectString)
        DirectCast(da, SqlDataAdapter).Fill(dt)

        Exit Select
      Case DataProviderEnum.OleDb
        da = New System.Data.OleDb.OleDbDataAdapter(SQL, AppConfig.ConnectStringOleDb)
        DirectCast(da, OleDbDataAdapter).Fill(dt)

        Exit Select
    End Select

    lstUsers.DataContext = dt
  End Sub

End Class