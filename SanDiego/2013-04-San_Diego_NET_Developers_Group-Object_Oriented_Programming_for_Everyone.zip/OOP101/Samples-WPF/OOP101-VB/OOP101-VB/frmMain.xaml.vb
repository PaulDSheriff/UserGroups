﻿Imports System.Windows

Partial Public Class frmMain
  Inherits Window

  Private Sub Button_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmUserSearch1()

    frm.Show()
  End Sub

  Private Sub Button_Click_1(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmUserSearch2()

    frm.Show()
  End Sub

  Private Sub Button_Click_2(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmUserSearch3()

    frm.Show()
  End Sub

  Private Sub Button_Click_4(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmInstanceShared()

    frm.Show()
  End Sub

  Private Sub Button_Click_3(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmEnums()

    frm.Show()
  End Sub

  Private Sub Button_Click_5(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmInheritance1()

    frm.Show()
  End Sub

  Private Sub Button_Click_6(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmInheritance2()

    frm.Show()
  End Sub

  Private Sub Button_Click_7(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmInterface1()

    frm.Show()
  End Sub

  Private Sub Button_Click_8(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmInterface2()

    frm.Show()
  End Sub

  Private Sub Button_Click_9(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmOverloading1()

    frm.Show()
  End Sub

  Private Sub Button_Click_10(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmOverloading2()

    frm.Show()
  End Sub

  Private Sub Button_Click_11(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim frm As New frmEventSample()

    frm.Show()
  End Sub
End Class