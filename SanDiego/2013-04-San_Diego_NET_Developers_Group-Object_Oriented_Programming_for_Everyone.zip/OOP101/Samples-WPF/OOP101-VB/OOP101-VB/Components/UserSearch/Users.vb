Imports System.Data

Public Class User
  Private _FirstName As String
  Private _LastName As String
  Private _Email As String

  Public Property FirstName() As String
    Get
      Return _FirstName
    End Get
    Set(value As String)
      _FirstName = value
    End Set
  End Property

  Public Property LastName() As String
    Get
      Return _LastName
    End Get
    Set(value As String)
      _LastName = value
    End Set
  End Property

  Public Property Email() As String
    Get
      Return _Email
    End Get
    Set(value As String)
      _Email = value
    End Set
  End Property
End Class

Public Class Users
  Public Function GetAllUsers() As DataSet
    Dim ds As DataSet

    ds = DataLayer.GetDataSet("SELECT * FROM oopUsers", _
      AppConfig.ConnectString)

    Return ds
  End Function

  Public Function GetUsersByFilter(ByVal uSearch As UsersSearch) As DataSet
    Dim sql As String = String.Empty
    Dim where As String = " WHERE "
    Dim ds As DataSet

    If uSearch.FirstName.Trim() <> String.Empty Then
      sql &= where & " FirstName LIKE '" & uSearch.FirstName & "%'"
      where = " AND "
    End If
    If uSearch.LastName.Trim() <> String.Empty Then
      sql &= where & " LastName LIKE '" & uSearch.LastName & "%'"
      where = " AND "
    End If
    If uSearch.Email.Trim() <> String.Empty Then
      sql &= where & " Email LIKE '%" & uSearch.Email & "%'"
      where = " AND "
    End If

    ds = DataLayer.GetDataSet("SELECT * FROM oopUsers " & sql, _
     AppConfig.ConnectString)

    Return ds
  End Function

  Public Function GetUserCollectionByFilter(userSearch As UsersSearch) As List(Of User)
    Dim sql As String = String.Empty
    Dim where As String = " WHERE "
    Dim dt As DataTable = Nothing
    Dim ret As New List(Of User)()

    If userSearch.FirstName.Trim() <> String.Empty Then
      sql += where & " FirstName LIKE '" & Convert.ToString(userSearch.FirstName) & "%'"
      where = " AND "
    End If
    If userSearch.LastName.Trim() <> String.Empty Then
      sql += where & " LastName LIKE '" & Convert.ToString(userSearch.LastName) & "%'"
      where = " AND "
    End If
    If userSearch.Email.Trim() <> String.Empty Then
      sql += where & " Email LIKE '%" & Convert.ToString(userSearch.Email) & "%'"
      where = " AND "
    End If

    dt = DataLayer.GetDataTable("SELECT * FROM oopUsers " & sql, AppConfig.ConnectString)

    For Each dr As DataRow In dt.Rows
      Dim usr As New User()

      usr.FirstName = dr("FirstName").ToString()
      usr.LastName = dr("LastName").ToString()
      usr.Email = dr("Email").ToString()

      ret.Add(usr)
    Next

    Return ret
  End Function
End Class