Imports System.Data.SqlClient
Imports System.Data

Public Class DataLayer2
  Public Shared Function GetDataSet(ByVal sql As String, _
   ByVal connectString As String) As DataSet
    Dim cmd As SqlCommand
    Dim cnn As SqlConnection

    ' Create Command Object
    cmd = New SqlCommand(sql)
    ' Create Connection Object
    cnn = New SqlConnection(connectString)
    ' Assign Connection to Command Object
    cmd.Connection = cnn

    ' Call Overloaded GetDataSet method
    Return GetDataSet(cmd)
  End Function

  Public Shared Function GetDataTable(ByVal sql As String, _
      ByVal connectString As String) As DataTable
    Return GetDataSet(sql, connectString).Tables(0)
  End Function

  Public Shared Function GetDataSet(ByVal cmd As SqlCommand) As DataSet
    Dim ds As New DataSet
    Dim da As SqlDataAdapter

    ' Create Data Adapter
    da = New SqlClient.SqlDataAdapter(cmd)
    da.Fill(ds)

    Return ds
  End Function

  Public Shared Function GetDataTable(ByVal cmd As SqlCommand) As DataTable
    Return GetDataSet(cmd).Tables(0)
  End Function

  Public Shared Function ExecuteSQL(ByVal cmd As IDbCommand) As Integer
    Dim ret As Integer = 0

    ret = cmd.ExecuteNonQuery()

    Return ret
  End Function

  Public Shared Function ExecuteSQL( _
   ByVal sql As String, _
   ByVal connectString As String) As Integer
    Dim cmd As SqlCommand = Nothing
    Dim ret As Integer

    ' Create Command & Connection Objects
    cmd = New SqlCommand(sql)
    cmd.Connection = New SqlConnection(connectString)
    cmd.Connection.Open()

    ' Execute SQL
    ret = ExecuteSQL(cmd)
    cmd.Connection.Close()
    cmd.Connection.Dispose()

    Return ret
  End Function
End Class