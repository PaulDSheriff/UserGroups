﻿Imports System.Data.SqlClient
Imports System.Windows

Partial Public Class frmOverloading2
  Inherits Window

  Protected Sub btnGetDataTable1_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    GetDataTableSQL()
  End Sub

  Protected Sub btnGetDataTable2_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    GetDataTableCmd()
  End Sub

  Private Sub GetDataTableSQL()
    Dim sql As String = Nothing

    sql = "SELECT * FROM oopUsers"

    lstUsers.DataContext = DataLayer2.GetDataTable(sql, AppConfig.ConnectString)
  End Sub

  Private Sub GetDataTableCmd()
    Dim cmd As SqlCommand = Nothing

    cmd = New SqlCommand("SELECT * FROM oopUsers")
    cmd.Connection = New SqlConnection(AppConfig.ConnectString)
    cmd.Connection.Open()

    lstUsers.DataContext = DataLayer2.GetDataTable(cmd)

    cmd.Connection.Close()
    cmd.Connection.Dispose()
  End Sub
End Class