﻿Imports System.Windows.Controls

Partial Public Class ucSearchCriteria
  Inherits UserControl

  Public Function GetInfo() As UsersSearch
    Dim ret As New UsersSearch()

    ret.Email = txtSearchEmail.Text.Trim()
    ret.FirstName = txtSearchFirstName.Text.Trim()
    ret.LastName = txtSearchLastName.Text.Trim()

    Return ret
  End Function
End Class