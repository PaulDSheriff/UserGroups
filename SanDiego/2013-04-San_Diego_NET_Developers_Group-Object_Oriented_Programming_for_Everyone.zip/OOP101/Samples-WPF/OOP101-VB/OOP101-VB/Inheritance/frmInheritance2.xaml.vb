﻿Imports System.Windows

Partial Public Class frmInheritance2
  Inherits MyWindow

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    lblDesignMode.Text = MyBase.IsInDesignMode().ToString()
  End Sub

  Private Sub btnLoad_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim fileName As String

    fileName = (MyBase.GetCurrentDirectory() & "\Dictionaries\") + txtXamlName.Text

    MyBase.LoadSamplesResource(fileName)
  End Sub
End Class