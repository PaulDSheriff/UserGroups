﻿using System;
using System.Data;
using Common.Library;
using TimeTrack.EntityClasses;

namespace TimeTrack.DataClasses
{
  /// <summary>
  /// Class to read/write employee data
  /// </summary>
  public partial class EmployeeData : DataClassBase
  {
    #region Public Properties
    public Employee Entity { get; set; }
    #endregion

    #region GetEmployee Method
    public Employee GetEmployee(Employee entity)
    {
      Employee ret = new Employee();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT EmployeeId, FirstName, LastName, LoginId, Password FROM dbo.Employee WHERE EmployeeId = @EmployeeId";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Parameters.Add(DataLayer.CreateParameter("@EmployeeId", entity.EmployeeId));
      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        if (dt.Rows.Count > 0)
          ret = DataRowToEntity(dt.Rows[0]);
      }

      return ret;
    }
    #endregion

    #region BuildCollection Method
    public Employees BuildCollection()
    {
      Employees ret = new Employees();
      DataTable dt;

      RowsAffected = 0;
      SQL = "SELECT EmployeeId, FirstName, LastName, LoginId, Password FROM dbo.Employee ORDER BY LastName";

      CommandObject = DataLayer.CreateCommand(SQL);
      CommandObject.Connection = DataLayer.CreateConnection(base.ConnectString);
      dt = DataLayer.GetDataTable(CommandObject);
      if (dt != null)
      {
        RowsAffected = dt.Rows.Count;
        foreach (DataRow dr in dt.Rows)
        {
          ret.Add(DataRowToEntity(dr));
        }
      }

      return ret;
    }
    #endregion

    #region DataRowToEntity Method
    public Employee DataRowToEntity(DataRow dr)
    {
      Employee ret = new Employee();

      ret.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);
      ret.FirstName = dr["FirstName"].ToString();
      ret.LastName = dr["LastName"].ToString();
      ret.LoginId = dr["LoginId"].ToString();
      ret.Password = dr["Password"].ToString();

      return ret;
    }
    #endregion
  }
}
