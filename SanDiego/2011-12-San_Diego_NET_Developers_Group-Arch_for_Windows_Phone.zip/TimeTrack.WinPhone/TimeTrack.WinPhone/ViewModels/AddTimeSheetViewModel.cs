﻿using System;
using System.Collections.ObjectModel;
using Common.Library;
using TimeTrack.EntityClasses;
using TimeTrack.WinPhone.TimeSheetServiceReference;

namespace TimeTrack.WinPhone
{
	/// <summary>
	/// ViewModel class for adding Time Sheets
	/// </summary>
  public class AddTimeSheetViewModel : ViewModelBase
  {
    #region Constructor
    public AddTimeSheetViewModel()
    {
      TaskDate = DateTime.Now.ToShortDateString();
      Hours = 1;
      Description = string.Empty;
      ValidationFailures = new ObservableCollection<ValidationMessage>();
      IsValidationAreaVisible = false;
      IsMessageVisible = false;
    }
    #endregion

    #region Private Variables
    private Customer _SelectedCustomer;
    private Project _SelectedProject;
    private Employee _SelectedEmployee;
    private string _TaskDate;
    private decimal _Hours;
    private string _Description;

    private ObservableCollection<ValidationMessage> _ValidationFailures;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the Selected Customer
    /// </summary>
    public Customer SelectedCustomer
    {
      get { return _SelectedCustomer; }
      set
      {
        _SelectedCustomer = value;
        RaisePropertyChanged("SelectedCustomer");
      }
    }

    /// <summary>
    /// Get/Set the Selected Project
    /// </summary>
    public Project SelectedProject
    {
      get { return _SelectedProject; }
      set
      {
        _SelectedProject = value;
        RaisePropertyChanged("SelectedProject");
      }
    }


    /// <summary>
    /// Get/Set the Selected Employee
    /// </summary>
    public Employee SelectedEmployee
    {
      get { return _SelectedEmployee; }
      set
      {
        _SelectedEmployee = value;
        RaisePropertyChanged("SelectedEmployee");
      }
    }

    /// <summary>
    /// Get/Set the Task Date
    /// </summary>
    public string TaskDate
    {
      get { return _TaskDate; }
      set
      {
        _TaskDate = value;
        RaisePropertyChanged("TaskDate");
      }
    }

    /// <summary>
    /// Get/Set the Hours
    /// </summary>
    public decimal Hours
    {
      get { return _Hours; }
      set
      {
        _Hours = value;
        RaisePropertyChanged("Hours");
      }
    }

    /// <summary>
    /// Get/Set the Description
    /// </summary>
    public string Description
    {
      get { return _Description; }
      set
      {
        _Description = value;
        RaisePropertyChanged("Description");
      }
    }
    
    public ObservableCollection<ValidationMessage> ValidationFailures
    {
      get { return _ValidationFailures; }
      set
      {
        _ValidationFailures = value;
        RaisePropertyChanged("ValidationFailures");
      }
    }
    #endregion

    #region Init Method
    /// <summary>
    /// Initialize to a valid start state
    /// </summary>
    public void Init()
    {
      SelectedCustomer = new Customer();
      SelectedCustomer.CustomerId = -1;
      SelectedProject = new Project();
      SelectedProject.ProjectId = -1;
      SelectedEmployee = new Employee();
      SelectedEmployee.EmployeeId = -1;

      TaskDate = DateTime.Now.ToShortDateString();
      Hours = 1;
      Description = string.Empty;

      ValidationFailures.Clear();
      IsValidationAreaVisible = false;
    }
    #endregion

    #region PrepareForNew Method
    /// <summary>
    /// Call after entering a Time Sheet Entry to setup for a new one
    /// </summary>
    public void PrepareForNew()
    {
      TaskDate = DateTime.Now.ToShortDateString();
      Hours = 1;
      Description = string.Empty;

      ValidationFailures.Clear();
      IsValidationAreaVisible = false;
    }
    #endregion

    #region Validate Method
    /// <summary>
    /// Validate Time Sheet Data
    /// This method might belong in a validation class instead of here
    /// Just here for simplicity
    /// </summary>
    /// <returns>True if values are valid, false if not</returns>
    public bool Validate()
    {
      DateTime dateValue;
      decimal decValue;

      ValidationFailures.Clear();
      
      if (SelectedCustomer.CustomerName.Trim() == string.Empty)
        ValidationFailures.Add(new ValidationMessage("A Customer Must Be Selected", "CustomerName"));
      if (SelectedProject.ProjectName.Trim() == string.Empty)
        ValidationFailures.Add(new ValidationMessage("A Project Must Be Selected", "ProjectName"));
      if (SelectedEmployee.LastName.Trim() == string.Empty)
        ValidationFailures.Add(new ValidationMessage("A Employee Must Be Selected", "LastName"));
      if (TaskDate.Trim() == string.Empty)
        ValidationFailures.Add(new ValidationMessage("A Task Date Must Be Filled In", "TaskDate"));
      else
      {
        if (!DateTime.TryParse(TaskDate, out dateValue))
          ValidationFailures.Add(new ValidationMessage("Enter A Valid Task Date", "TaskDate"));
      }
      if (!decimal.TryParse(Hours.ToString(), out decValue))
        ValidationFailures.Add(new ValidationMessage("Hours Must Be A Decimal Number", "Hours"));
      else
      {
        if (decValue <= 0)
          ValidationFailures.Add(new ValidationMessage("Hours Must Be Greater Than 0", "Hours"));
        if (decValue > 12)
          ValidationFailures.Add(new ValidationMessage("Hours Must Be Less Than Or Equal To 12", "Hours"));
      }
      if(Description.Trim() == string.Empty)
        ValidationFailures.Add(new ValidationMessage("A Description Must Be Entered", "Description"));
      else
        if(Description.Trim().Length < 4)
          ValidationFailures.Add(new ValidationMessage("A Description Must Have More Than 4 Characters", "Description"));

      IsValidationAreaVisible = (ValidationFailures.Count > 0);

      return !IsValidationAreaVisible;
    }
    #endregion

    #region Insert Method
    public void Insert()
    {
      TimeSheetServicesClient client = new TimeSheetServicesClient();
      TimeSheet entity = new TimeSheet();

      entity.CustomerId = SelectedCustomer.CustomerId;
      entity.Description = Description;
      entity.EmployeeId = SelectedEmployee.EmployeeId;
      entity.Hours = Hours;
      entity.ProjectId = SelectedProject.ProjectId;
      entity.TaskDate = Convert.ToDateTime(TaskDate);

      client.InsertCompleted += new EventHandler<InsertCompletedEventArgs>(client_InsertCompleted);
      client.InsertAsync(entity);
      client.CloseAsync();
    }

    void client_InsertCompleted(object sender, InsertCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Success)
        MessageToDisplay = "Insert Successful";
      else
        MessageToDisplay = e.Result.ErrorMessage;

      IsMessageVisible = true;
    }
    #endregion
  }
}
