﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Common.Library;

using TimeTrack.EntityClasses;
using TimeTrack.WinPhone.CustomerServiceReference;

namespace TimeTrack.WinPhone
{
	/// <summary>
	/// ViewModel class for working with the Customer view
	/// </summary>
  public class CustomerViewModel : ViewModelBase
  {
    public CustomerViewModel()
    {
      MessageToDisplay = "Please wait while loading customers...";
    }

    #region Private Variables
    private ObservableCollection<Customer> _DataCollection;
    private IEnumerable<Customer> _FilteredDataCollection;
    #endregion

    #region Public Properties
    public ObservableCollection<Customer> DataCollection 
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }

    public IEnumerable<Customer> FilteredDataCollection
    {
      get { return _FilteredDataCollection; }
      set
      {
        _FilteredDataCollection = value;
        RaisePropertyChanged("FilteredDataCollection");
      }
    }
    #endregion

    #region GetCustomers Method
    public void GetCustomers()
    {
      CustomerServicesClient client = new CustomerServicesClient();

      // Reset View Model Variables
      IsNoRecordsVisible = false;
      
      client.GetCustomersCompleted += new EventHandler<GetCustomersCompletedEventArgs>(client_GetCustomersCompleted);
      client.GetCustomersAsync();
      client.CloseAsync();
    }

    void client_GetCustomersCompleted(object sender, GetCustomersCompletedEventArgs e)
    {
      CustomerResponse ret;

      ret = (CustomerResponse)e.Result;
      if (ret.Status == OperationResult.Success)
      {
        DataCollection = ret.DataCollection;
        FilteredDataCollection = DataCollection;
        IsMessageVisible = false;
      }
      else if (ret.Status == OperationResult.NoRecords)
      {
        MessageToDisplay = "No customers found.";
        IsNoRecordsVisible = true;
      }
    }
    #endregion

    #region FilterCustomers Method
    public void FilterCustomers(string filter)
    {
      FilteredDataCollection = 
        from cust in DataCollection 
        where cust.CustomerName.ToLower().StartsWith(filter.ToLower()) 
        orderby cust.CustomerName 
        select cust;
    }
    #endregion
  }
}
