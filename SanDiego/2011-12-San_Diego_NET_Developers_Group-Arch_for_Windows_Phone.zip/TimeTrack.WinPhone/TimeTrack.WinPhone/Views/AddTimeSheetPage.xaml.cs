﻿using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace TimeTrack.WinPhone
{
  public partial class AddTimeSheetPage : PhoneApplicationPage
  {
    public AddTimeSheetViewModel _ViewModel = null;

    #region Constructor
    public AddTimeSheetPage()
    {
      InitializeComponent();
      
      // Ensure TimeSheet View Model object is valid
      (Application.Current as App).InitTimeSheetViewModel();

      // Get Application-Wide AddTimeSheetViewModel instance
      _ViewModel = (Application.Current as App).TimeSheetModel;

      // Set ViewModel object to Page's Data Context
      this.DataContext = _ViewModel;
    }
    #endregion

    #region Event Procedures
    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/CustomerLookupPage.xaml", UriKind.Relative));
    }

    private void btnProject_Click(object sender, RoutedEventArgs e)
    {
      if (_ViewModel.SelectedCustomer == null)
        MessageBox.Show("Select a Customer First", "Select Customer", MessageBoxButton.OK);
      else
        NavigationService.Navigate(new Uri("/Views/ProjectLookupPage.xaml", UriKind.Relative));
    }

    private void btnEmployee_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/EmployeeLookupPage.xaml", UriKind.Relative));
    }

    private void btnDesc_Click(object sender, RoutedEventArgs e)
    {
      NavigationService.Navigate(new Uri("/Views/AddDescriptionPage.xaml", UriKind.Relative));
    }

    private void Reset_Click(object sender, EventArgs e)
    {
      _ViewModel.Init();
    }
    #endregion

    #region Insert/Validate Method
    private void Insert_Click(object sender, EventArgs e)
    {
      // Force text boxes to update source
      // Because Application Bar does not switch focus
      txtDate.GetBindingExpression(TextBox.TextProperty).UpdateSource();
      txtHours.GetBindingExpression(TextBox.TextProperty).UpdateSource();
      txtDesc.GetBindingExpression(TextBox.TextProperty).UpdateSource();
      // Make Keyboard Go Away
      btnDesc.Focus();
      // Now perform validation
      if (_ViewModel.Validate())
      {
        // Insert new Time Sheet entry
        _ViewModel.Insert();
        // Reset Time Sheet Data
        _ViewModel.PrepareForNew();
      }
    }
    #endregion
  }
}