﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;

namespace TimeTrack.WinPhone
{
  public partial class AddDescriptionPage : PhoneApplicationPage
  {
    public AddDescriptionPage()
    {
      InitializeComponent();

      this.DataContext = (Application.Current as App).TimeSheetModel;
    }
    
    // Return the Textual Description back to first page
    protected override void OnNavigatedFrom(System.Windows.Navigation.NavigationEventArgs e)
    {
      if (e.Content is AddTimeSheetPage)
        (e.Content as AddTimeSheetPage)._ViewModel.Description = txtDesc.Text;
      base.OnNavigatedFrom(e);
    }

    private void ApplicationBarIconButton_Click(object sender, EventArgs e)
    {
      NavigationService.GoBack();
    }
  }
}