﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using TimeTrack.EntityClasses;

namespace TimeTrack.WinPhone
{
  public partial class DisplayTimeSheetsPage : PhoneApplicationPage
  {
    private DisplayTimeSheetsViewModel _ViewModel = null;

    #region Constructor
    public DisplayTimeSheetsPage()
    {
      InitializeComponent();

      // Ensure TimeSheet View Model object is valid
      (Application.Current as App).InitTimeSheetViewModel();

      // Grab the Instance of the ViewModel
      _ViewModel = (DisplayTimeSheetsViewModel)this.Resources["viewModel"];
    }
    #endregion

    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      // Store currently selected customer into ViewModel if applicable
      if ((Application.Current as App).TimeSheetModel.SelectedCustomer.CustomerId != -1)
      {
        _ViewModel.SelectedCustomer = (Application.Current as App).TimeSheetModel.SelectedCustomer;
        // Perform search on selected customer
        PerformSearch();
      }
    }

    #region Customers Click Event
    private void btnCustomers_Click(object sender, RoutedEventArgs e)
    {
      ResetUI();
      NavigationService.Navigate(new Uri("/Views/CustomerLookupPage.xaml", UriKind.Relative));
    }
    #endregion

    #region Search Click Event
    private void Search_Click(object sender, EventArgs e)
    {
      PerformSearch();
    }

    private void PerformSearch()
    {
      if (_ViewModel.SelectedCustomer == null || _ViewModel.SelectedCustomer.CustomerId == -1)
      {
        lstData.ItemTemplate = (DataTemplate)this.Resources["tmplWithCustomer"];
        _ViewModel.GetAllTimeSheets();
      }
      else
      {
        lstData.ItemTemplate = (DataTemplate)this.Resources["tmplProjectOnly"];
        _ViewModel.GetTimeSheetsByCustomer((Application.Current as App).TimeSheetModel.SelectedCustomer);
      }
    }
    #endregion

    #region Reset Click Event
    private void Reset_Click(object sender, EventArgs e)
    {
      (Application.Current as App).TimeSheetModel.SelectedCustomer = new Customer();
      (Application.Current as App).TimeSheetModel.SelectedCustomer.CustomerId = -1;
      _ViewModel.SelectedCustomer = (Application.Current as App).TimeSheetModel.SelectedCustomer;
      ResetUI();
    }
    #endregion

    #region ResetUI Method
    private void ResetUI()
    {
      _ViewModel.DataCollection = new System.Collections.ObjectModel.ObservableCollection<TimeSheet>();
      _ViewModel.IsMessageVisible = false;
      lstData.SelectedIndex = -1;      
    }
    #endregion
  }
}