﻿using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;

using TimeTrack.EntityClasses;

namespace TimeTrack.WinPhone
{
  public partial class ProjectLookupPage : PhoneApplicationPage
  {
    private ProjectViewModel _ViewModel = null;

    #region Constructor
    public ProjectLookupPage()
    {
      InitializeComponent();

      // Grab the Instance of the ViewModel
      _ViewModel = (ProjectViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region Loaded Event
    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      _ViewModel.GetProjectsByCustomers((Application.Current as App).TimeSheetModel.SelectedCustomer);
    }
    #endregion

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      // Get Selected Customer and Store into Application Level
      (Application.Current as App).TimeSheetModel.SelectedProject = (Project)lstData.SelectedItem;

      NavigationService.GoBack();
    }
    #endregion

    #region TextChanged Event
    private void txtName_TextChanged(object sender, TextChangedEventArgs e)
    {
      _ViewModel.FilterProjects(txtName.Text.Trim());
    }
    #endregion
  }
}