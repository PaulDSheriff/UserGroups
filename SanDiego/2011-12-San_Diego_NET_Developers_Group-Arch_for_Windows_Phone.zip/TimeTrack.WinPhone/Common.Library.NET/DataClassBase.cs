﻿using System.Configuration;
using System.Data.SqlClient;

namespace Common.Library
{
  /// <summary>
  /// Class that all Data Classes will inherit from
	/// Provides properties such as ConnectString, SQL, RowsAffected and a CommandObject for SQL Server
  /// </summary>
  public class DataClassBase
  {
    #region Constructors
    public DataClassBase()
    {
      Init();
    }

    public DataClassBase(string connectString)
    {
      Init();

      ConnectString = connectString;
    }
    #endregion

    #region Init Method
    protected void Init()
    {
      ConnectString = string.Empty;
      SQL = string.Empty;
      RowsAffected = 0;
      CommandObject = null;
    }
    #endregion

    #region Public Properties
    public string ConnectString { get; set; }
    public string SQL { get; set; }
    public int RowsAffected { get; set; }
    public SqlCommand CommandObject { get; set; }
    #endregion

    #region GetConnectString Method
    public string GetConnectString(string connectStringName)
    {
      return ConfigurationManager.ConnectionStrings[connectStringName].ConnectionString;
    }
    #endregion
  }
}
