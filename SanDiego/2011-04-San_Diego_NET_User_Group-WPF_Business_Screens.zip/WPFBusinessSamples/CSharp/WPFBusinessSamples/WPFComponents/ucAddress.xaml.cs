﻿using System.Windows.Controls;

namespace WPFComponents
{
  /// <summary>
  /// Interaction logic for ucAddress.xaml
  /// </summary>
  public partial class ucAddress : UserControl
  {
    public ucAddress()
    {
      InitializeComponent();
    }
  }
}
