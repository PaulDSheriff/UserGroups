﻿using System.Windows;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for winGridLayout2.xaml
  /// </summary>
  public partial class winGridLayout2 : Window
  {
    public winGridLayout2()
    {
      InitializeComponent();
    }
  }
}
