﻿using System.Windows;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for winDockPanelLayout.xaml
  /// </summary>
  public partial class winDockPanelLayout : Window
  {
    public winDockPanelLayout()
    {
      InitializeComponent();
    }
  }
}
