﻿using System.Windows;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for winGridLayout.xaml
  /// </summary>
  public partial class winGridLayout : Window
  {
    public winGridLayout()
    {
      InitializeComponent();
    }
  }
}
