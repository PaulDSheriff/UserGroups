﻿using System.Windows;

namespace WPFBusinessSamples
{
  /// <summary>
  /// Interaction logic for winMenus.xaml
  /// </summary>
  public partial class winMenus : Window
  {
    public winMenus()
    {
      InitializeComponent();
    }
  }
}
