﻿Public Class winWindowNoBorder
  Private Sub Button_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Me.Close()
  End Sub

End Class
