﻿Public Class winChild
  Private Sub btnClose_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Me.Close()
  End Sub

End Class
