﻿Public Class winStatusBar
  Private Sub btnHelp_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    MessageBox.Show("Help")
  End Sub

End Class
