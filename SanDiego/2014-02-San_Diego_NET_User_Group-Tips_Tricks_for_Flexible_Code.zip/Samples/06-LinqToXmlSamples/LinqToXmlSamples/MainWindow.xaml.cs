﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

using CommonLibrary;

namespace LinqToXmlSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region State Loading
    private void btnLoadStates_Click(object sender, RoutedEventArgs e)
    {
      USStateLoad();
    }

    private void USStateLoad()
    {
      XElement xelem;

      xelem = XElement.Load(FileCommon.GetCurrentDirectory() + @"\Xml\USStates.xml");

      // Fill a list of Product objects
      IEnumerable<USState> nodes =
        from node in xelem.Elements("USState")
        orderby node.Element("StateCode").Value
        select new USState
        {
          StateCode = node.Element("StateCode").GetAs<string>(),
          StateName = node.Element("StateName").GetAs<string>(),
          Capital = node.Element("Capital").GetAs<string>()
        };

      // Expand 'nodes' and look at ToString() override
      System.Diagnostics.Debugger.Break();

      lstData.DisplayMemberPath = "StateCode";
      lstData.DataContext = nodes;
    }
    #endregion

    #region Product Loading
    private void btnLoadProducts_Click(object sender, RoutedEventArgs e)
    {
      ProductLoad();
    }

    private void ProductLoad()
    {
      XElement xelem;

      xelem = XElement.Load(FileCommon.GetCurrentDirectory() + @"\Xml\Product.xml");

      // Fill a list of Product objects
      IEnumerable<Product> nodes =
        from node in xelem.Elements("Product")
        orderby node.Element("ProductName").Value
        select new Product
        {
          ProductId = node.Element("ProductId").GetAs<int>(),
          ProductName = node.Element("ProductName").GetAs<string>(),
          IntroductionDate = node.Element("IntroductionDate").
                                GetAs<DateTime>(default(DateTime)),
          Cost = node.Element("Cost").GetAs<decimal>(),
          Price = node.Element("Price").GetAs<decimal>(),
          IsDiscontinued = node.Element("IsDiscontinued").GetAs<bool>()
        };

      // Expand 'nodes' and look at ToString() override
      System.Diagnostics.Debugger.Break();

      lstData.DisplayMemberPath = "ProductName";
      lstData.DataContext = nodes;
    }
    #endregion
  }
}
