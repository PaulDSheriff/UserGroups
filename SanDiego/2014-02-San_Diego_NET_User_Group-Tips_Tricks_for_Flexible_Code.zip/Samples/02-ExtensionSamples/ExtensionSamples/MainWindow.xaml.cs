﻿using System;
using System.Windows;

using CommonLibrary;

namespace ExtensionSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void DemoExtensionMethods()
    {
      string value = "Reverse Me";

      value = value.Reverse();
    }
        
    private void btnReverseString_Click(object sender, RoutedEventArgs e)
    {
      tbStringResult.Text = txtString.Text.Reverse();
    }

    private void btnConvertBoolean_Click(object sender, RoutedEventArgs e)
    {
      tbStringResult.Text = txtString.Text.ToBoolean().ToString();
    }

    private void btnIsValidEmail_Click(object sender, RoutedEventArgs e)
    {
      tbStringResult.Text = txtString.Text.IsValidEmail().ToString();
    }

    private void btnIsAllLowerCase_Click(object sender, RoutedEventArgs e)
    {
      tbStringResult.Text = txtString.Text.IsAllLowerCase().ToString();
    }

    private void btnIsAllUpperCase_Click(object sender, RoutedEventArgs e)
    {
      tbStringResult.Text = txtString.Text.IsAllUpperCase().ToString();
    }

    private void btnMonthStart_Click(object sender, RoutedEventArgs e)
    {
      tbDateResult.Text = Convert.ToDateTime(dpDate.SelectedDate).MonthStart().ToShortDateString();
    }

    private void btnMonthEnd_Click(object sender, RoutedEventArgs e)
    {
      tbDateResult.Text = Convert.ToDateTime(dpDate.SelectedDate).MonthEnd().ToShortDateString();
    }

    private void btnQuarterStart_Click(object sender, RoutedEventArgs e)
    {
      tbDateResult.Text = Convert.ToDateTime(dpDate.SelectedDate).QuarterStart().ToShortDateString();
    }

    private void btnQuarterEnd_Click(object sender, RoutedEventArgs e)
    {
      tbDateResult.Text = Convert.ToDateTime(dpDate.SelectedDate).QuarterEnd().ToShortDateString();
    }

    private void btnYearStart_Click(object sender, RoutedEventArgs e)
    {
      tbDateResult.Text = Convert.ToDateTime(dpDate.SelectedDate).YearStart().ToShortDateString();
    }

    private void btnYearEnd_Click(object sender, RoutedEventArgs e)
    {
      tbDateResult.Text = Convert.ToDateTime(dpDate.SelectedDate).YearEnd().ToShortDateString();
    }
  }
}
