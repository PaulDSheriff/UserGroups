﻿
using ExceptionLayer;

namespace ExceptionLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Exception Manager
      InitializeExceptionManager();
    }

    protected void InitializeExceptionManager()
    {
      // Add a 'File' Publisher
      PDSAExceptionManager.Instance.Publishers.Add(new PDSAExceptionToFile(@"D:\Samples\Exceptions.txt"));

      // Add an 'email' publisher
      PDSAEmailSettings settings = new PDSAEmailSettings();
      settings.FromEmail = "PSheriff@pdsa.com";
      settings.ToEmail = "PSheriff@pdsa.com";
      settings.Subject = "Exception from the Flexible Code Samples";
      settings.SMTPServer = "192.168.10.39";
      PDSAExceptionManager.Instance.Publishers.Add(new PDSAExceptionToEMail(settings));
    }
  }
}
