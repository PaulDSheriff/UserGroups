﻿
namespace ConfigurationLayer
{
  public abstract class PDSAConfigurationBase
  {
    #region Constructor
    public PDSAConfigurationBase(string location)
    {
      Location = location;
    }
    #endregion

    public string Location { get; set; }

    #region Abstract Methods
    public virtual string GetSetting(string key)
    {
      return GetSetting(key, null);
    }


    public abstract string GetSetting(string key, string defaultValue);
    #endregion
  }
}
