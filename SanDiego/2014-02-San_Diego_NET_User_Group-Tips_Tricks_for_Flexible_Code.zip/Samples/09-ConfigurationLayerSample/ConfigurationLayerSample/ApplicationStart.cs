﻿
using ConfigurationLayer;

namespace ConfigurationLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Configuration Manager
      InitializeConfigurationManager();
    }

    protected void InitializeConfigurationManager()
    {
      // To use the XML reader, initialize Instance like the following:
      //PDSAConfigurationManager.Instance = new PDSAConfigurationManager(new PDSAConfigurationXml(@"D:\Samples\MySettings.xml"));

      // To use the Registry reader, initialize Instance like the following:
      //PDSAConfigurationManager.Instance = new PDSAConfigurationManager(new PDSAConfigurationRegistry(@"Software\MyApp"));

      // To use the .Config file reader, initialize Instance like the following:
      PDSAConfigurationManager.Instance = new PDSAConfigurationManager(new PDSAConfigurationConfig(string.Empty));
    }
  }
}
