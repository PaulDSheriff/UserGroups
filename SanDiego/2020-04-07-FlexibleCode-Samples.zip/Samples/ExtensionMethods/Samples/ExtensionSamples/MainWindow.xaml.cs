﻿using System;
using System.Windows;

using CommonLibrary;

namespace ExtensionSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DatePickerControl.SelectedDate = DateTime.Now;
    }

    private void ReverseString_Click(object sender, RoutedEventArgs e)
    {
      StringResult.Text = StringValue.Text.Reverse();
    }

    private void ConvertBoolean_Click(object sender, RoutedEventArgs e)
    {
      StringResult.Text = StringValue.Text.ToBoolean().ToString();
    }

    private void IsValidEmail_Click(object sender, RoutedEventArgs e)
    {
      StringResult.Text = StringValue.Text.IsValidEmail().ToString();
    }

    private void IsAllLowerCase_Click(object sender, RoutedEventArgs e)
    {
      StringResult.Text = StringValue.Text.IsAllLowerCase().ToString();
    }

    private void IsAllUpperCase_Click(object sender, RoutedEventArgs e)
    {
      StringResult.Text = StringValue.Text.IsAllUpperCase().ToString();
    }

    private void MonthStart_Click(object sender, RoutedEventArgs e)
    {
      DateResult.Text = DatePickerControl.SelectedDate.Value.MonthStart().ToShortDateString();
    }

    private void MonthEnd_Click(object sender, RoutedEventArgs e)
    {
      DateResult.Text = DatePickerControl.SelectedDate.Value.MonthEnd().ToShortDateString();
    }

    private void QuarterStart_Click(object sender, RoutedEventArgs e)
    {
      DateResult.Text = DatePickerControl.SelectedDate.Value.QuarterStart().ToShortDateString();
    }

    private void QuarterEnd_Click(object sender, RoutedEventArgs e)
    {
      DateResult.Text = DatePickerControl.SelectedDate.Value.QuarterEnd().ToShortDateString();
    }

    private void YearStart_Click(object sender, RoutedEventArgs e)
    {
      DateResult.Text = DatePickerControl.SelectedDate.Value.YearStart().ToShortDateString();
    }

    private void YearEnd_Click(object sender, RoutedEventArgs e)
    {
      DateResult.Text = DatePickerControl.SelectedDate.Value.YearEnd().ToShortDateString();
    }
  }
}
