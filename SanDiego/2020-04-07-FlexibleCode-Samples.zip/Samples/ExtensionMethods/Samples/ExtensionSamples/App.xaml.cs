﻿using System.Windows;

namespace ExtensionSamples
{
  public partial class App : Application
  {
  }
}
