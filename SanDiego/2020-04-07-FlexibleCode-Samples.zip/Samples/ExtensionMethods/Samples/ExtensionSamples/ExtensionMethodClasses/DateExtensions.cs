﻿using System;
using System.Globalization;

namespace CommonLibrary
{
  /// <summary>
  /// This class contains Extension Methods for DateTime
  /// </summary>
  public static class DateExtensions
  {
    /// <summary>
    /// Returns the first day of the month for the date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime MonthStart(this DateTime value)
    {
      return new DateTime(value.Year, value.Month, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
    }

    /// <summary>
    /// Returns the last day of the month for the date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime MonthEnd(this DateTime value)
    {
      int lastDay;

      lastDay = DateTime.DaysInMonth(value.Year, value.Month);

      return new DateTime(value.Year, value.Month, lastDay, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
    }

    /// <summary>
    /// Returns a Date that is the first day of the quarter for the given date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime QuarterStart(this DateTime value)
    {
      int month = 1;

      switch (value.Month) {
        case 1:
        case 2:
        case 3:
          month = 1;
          break;
        case 4:
        case 5:
        case 6:
          month = 4;
          break;
        case 7:
        case 8:
        case 9:
          month = 7;
          break;
        case 10:
        case 11:
        case 12:
          month = 10;
          break;
      }

      return new DateTime(value.Year, month, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar); ;
    }

    /// <summary>
    /// Returns a Date that is the last day of the quarter for the given date value passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DataTime</returns>
    public static DateTime QuarterEnd(this DateTime value)
    {
      int month = 1;
      int day = 31;

      switch (value.Month) {
        case 1:
        case 2:
        case 3:
          month = 3;
          day = 31;
          break;
        case 4:
        case 5:
        case 6:
          month = 6;
          day = 30;
          break;
        case 7:
        case 8:
        case 9:
          month = 9;
          day = 30;
          break;
        case 10:
        case 11:
        case 12:
          month = 12;
          day = 31;
          break;

        default:
          break;
      }

      return new DateTime(value.Year, month, day, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
    }

    /// <summary>
    /// Returns the first day of the year for the given date passed in.
    /// </summary>
    /// <param name="value">A Date Value</param>
    /// <returns>DateTime</returns>
    public static DateTime YearStart(this DateTime value)
    {
      return new DateTime(value.Year, 1, 1, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
    }

    /// <summary>
    /// Returns the last day of the year for the given date value passed in.
    /// </summary>
    /// <param name="value">DateTime</param>
    /// <returns>DateTime</returns>
    public static DateTime YearEnd(this DateTime value)
    {
      return new DateTime(value.Year, 12, 31, value.Hour, value.Minute, value.Second, value.Millisecond, CultureInfo.CurrentCulture.Calendar);
    }
  }
}
