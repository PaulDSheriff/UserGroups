﻿using System.Windows;

namespace GenericsSamples
{
  public partial class App : Application
  {
  }
}
