﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace GenericsSamples
{
  public partial class GenericControl : UserControl
  {
    public GenericControl()
    {
      InitializeComponent();
    }

    private void HardCodedGeneric_Click(object sender, RoutedEventArgs e)
    {
      HardCodedGenericsSample();
    }

    private void HardCodedGenericsSample()
    {
      object value = "1";

      int i = ConvertTo<int>(value, default);
      System.Diagnostics.Debug.WriteLine(i);

      value = "1/1/2014";
      DateTime dt = ConvertTo<DateTime>(value, default);
      System.Diagnostics.Debug.WriteLine(dt);

      value = null;
      DateTime dtNull = ConvertTo<DateTime>(value, default);
      System.Diagnostics.Debug.WriteLine(dtNull);

      value = null;
      dtNull = ConvertTo<DateTime>(value, DateTime.Now);
      System.Diagnostics.Debug.WriteLine(dtNull);
    }

    private void Generic_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = GetProducts();
    }

    public List<Product> GetProducts()
    {
      List<Product> ret = new List<Product>();
      Product entity;
      SqlDataAdapter da;
      DataTable dt = new DataTable();

      da = new SqlDataAdapter("SELECT * FROM SalesLT.Product",
        "Server=Localhost;Database=AdventureWorksLT;Integrated Security=Yes");

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows) {
        entity = new Product
        {
          ProductID = Convert.ToInt32(dr["ProductID"]),
          Name = dr["Name"].ToString(),
          ProductNumber = dr["ProductNumber"].ToString(),
          StandardCost = ConvertTo<decimal>(dr["StandardCost"], default),
          ListPrice = ConvertTo<decimal>(dr["ListPrice"], 1),
          SellStartDate = ConvertTo<DateTime>(dr["SellStartDate"], DateTime.Now)
        };

        ret.Add(entity);
      }

      return ret;
    }

    public T ConvertTo<T>(object value, T defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return (T)Convert.ChangeType(defaultValue, typeof(T));
      else
        return (T)Convert.ChangeType(value, typeof(T));
    }
  }
}