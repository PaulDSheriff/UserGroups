﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace GenericsSamples
{
  public partial class ListControl : UserControl
  {
    public ListControl()
    {
      InitializeComponent();
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
      List<int> values = new List<int>();
      values.Add(1);
      values.Add(2);
      values.Add(3);
      values.Add(4);
      values.Add(5);
            
      // Simplify the adding of new elements
      List<int> values2 = new List<int>
      {
        1,
        2,
        3,
        4,
        5
      };

      Result.Text = "** values list **" + Environment.NewLine;
      Result.Text += values[0].ToString() + Environment.NewLine;
      Result.Text += values[1].ToString() + Environment.NewLine;
      Result.Text += values[2].ToString() + Environment.NewLine;
      Result.Text += values[3].ToString() + Environment.NewLine;
      Result.Text += values[4].ToString() + Environment.NewLine;
      Result.Text += Environment.NewLine;

      Result.Text += "Count: " + values.Count.ToString() + Environment.NewLine;

      Result.Text += Environment.NewLine;
      Result.Text += "** values2 list **" + Environment.NewLine;
      values2.ForEach (delegate (int value) {
        Result.Text += value.ToString() + Environment.NewLine;
      });

      values.Clear();
    }

    private void AddRange_Click(object sender, RoutedEventArgs e)
    {
      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };

      list.AddRange(new List<Product>
      {
        new Product { ProductID = 4, Name = "Product 4", ProductNumber = "PROD-04", StandardCost = 4, ListPrice = 40, SellStartDate = DateTime.Now.AddDays(-4) },
        new Product { ProductID = 5, Name = "Product 5", ProductNumber = "PROD-05", StandardCost = 5, ListPrice = 50, SellStartDate = DateTime.Now.AddDays(-5) },
        new Product { ProductID = 6, Name = "Product 6", ProductNumber = "PROD-06", StandardCost = 6, ListPrice = 60, SellStartDate = DateTime.Now.AddDays(-6) }
      });

      lstData.DataContext = list;
    }

    private void Insert_Click(object sender, RoutedEventArgs e)
    {
      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };

      list.Insert(2, new Product { ProductID = 4, Name = "Product 4", ProductNumber = "PROD-04", StandardCost = 4, ListPrice = 40, SellStartDate = DateTime.Now.AddDays(-4) });

      lstData.DataContext = list;
    }

    private void InsertRange_Click(object sender, RoutedEventArgs e)
    {
      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };

      list.InsertRange(1, new List<Product>
      {
        new Product { ProductID = 4, Name = "Product 4", ProductNumber = "PROD-04", StandardCost = 4, ListPrice = 40, SellStartDate = DateTime.Now.AddDays(-4) },
        new Product { ProductID = 5, Name = "Product 5", ProductNumber = "PROD-05", StandardCost = 5, ListPrice = 50, SellStartDate = DateTime.Now.AddDays(-5) },
        new Product { ProductID = 6, Name = "Product 6", ProductNumber = "PROD-06", StandardCost = 6, ListPrice = 60, SellStartDate = DateTime.Now.AddDays(-6) }
      });

      lstData.DataContext = list;
    }

    private void Contains_Click(object sender, RoutedEventArgs e)
    {
      // Create list of integers
      List<int> values = new List<int>
      {
        1,
        2,
        3,
        4,
        5
      };

      Result.Text = "int List Contains 3? " + values.Contains(3) + Environment.NewLine;

      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };
      
      Result.Text += "Product list contains specific product? " + list.Contains(list[1]) + Environment.NewLine;
    }

    private void Find_Click(object sender, RoutedEventArgs e)
    {
      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };

      Result.Text = "Product list contains specific product? " + list.Find(p => p.ProductNumber == "PROD-02").ProductID.ToString() + Environment.NewLine;
    }

    private void Remove_Click(object sender, RoutedEventArgs e)
    {
      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };

      list.Remove(list[1]);
      lstData.DataContext = list;
    }

    private void RemoveAt_Click(object sender, RoutedEventArgs e)
    {
      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };

      list.RemoveAt(2);
      lstData.DataContext = list;
    }

    private void RemoveRange_Click(object sender, RoutedEventArgs e)
    {
      List<Product> list = new List<Product>
      {
        new Product { ProductID = 1, Name = "Product 1", ProductNumber = "PROD-01", StandardCost = 1, ListPrice = 10, SellStartDate = DateTime.Now.AddDays(-1) },
        new Product { ProductID = 2, Name = "Product 2", ProductNumber = "PROD-02", StandardCost = 2, ListPrice = 20, SellStartDate = DateTime.Now.AddDays(-2) },
        new Product { ProductID = 3, Name = "Product 3", ProductNumber = "PROD-03", StandardCost = 3, ListPrice = 30, SellStartDate = DateTime.Now.AddDays(-3) }
      };

      list.RemoveRange(1, 2);
      lstData.DataContext = list;
    }
  }
}
