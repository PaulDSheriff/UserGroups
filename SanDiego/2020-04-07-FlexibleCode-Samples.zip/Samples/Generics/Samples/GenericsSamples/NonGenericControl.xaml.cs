﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace GenericsSamples
{
  public partial class NonGenericControl : UserControl
  {
    public NonGenericControl()
    {
      InitializeComponent();
    }

    private void HardCodedNonGeneric_Click(object sender, RoutedEventArgs e)
    {
      HardCodedNonGenericsSample();
    }

    private void HardCodedNonGenericsSample()
    {
      object value = "1";

      int i = ConvertToInt(value, default(int));
      System.Diagnostics.Debug.WriteLine(i);

      value = "1/1/2020";
      DateTime dt = ConvertToDateTime(value, default(DateTime));
      System.Diagnostics.Debug.WriteLine(dt);

      value = null;
      DateTime dtNull = ConvertToDateTime(value, default(DateTime));
      System.Diagnostics.Debug.WriteLine(dtNull);
    }

    private void NonGeneric_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = GetProductsNonGeneric();
    }

    public List<Product> GetProductsNonGeneric()
    {
      List<Product> ret = new List<Product>();
      Product entity;
      SqlDataAdapter da;
      DataTable dt = new DataTable();

      da = new SqlDataAdapter("SELECT * FROM SalesLT.Product",
        "Server=Localhost;Database=AdventureWorksLT;Integrated Security=Yes");

      da.Fill(dt);

      foreach (DataRow dr in dt.Rows) {
        entity = new Product
        {
          ProductID = ConvertToInt(dr["ProductID"], 0),
          Name = ConvertToString(dr["Name"], string.Empty),
          ProductNumber = ConvertToString(dr["ProductNumber"], default(string)),
          StandardCost = ConvertToDecimal(dr["StandardCost"], default(decimal)),
          ListPrice = ConvertToDecimal(dr["ListPrice"], default(decimal)),
          SellStartDate = ConvertToDateTime(dr["SellStartDate"], default(DateTime))
        };

        ret.Add(entity);
      }

      return ret;
    }

    public int ConvertToInt(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToInt32(defaultValue);
      else
        return Convert.ToInt32(value);
    }

    public DateTime ConvertToDateTime(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToDateTime(defaultValue);
      else
        return Convert.ToDateTime(value);
    }

    public string ConvertToString(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToString(defaultValue);
      else
        return Convert.ToString(value);
    }

    public Decimal ConvertToDecimal(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToDecimal(defaultValue);
      else
        return Convert.ToDecimal(value);
    }

    public bool ConvertToBoolean(object value, object defaultValue)
    {
      if (value == null || value.Equals(DBNull.Value))
        return Convert.ToBoolean(defaultValue);
      else
        return Convert.ToBoolean(value);
    }
  }
}