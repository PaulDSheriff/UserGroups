﻿Sample 01
-------------------------
Loading and processing documents using LINQ to XML
Build XML Documents

Sample 02
-------------------------
Get all Nodes, Select Single Node
Where, OrderBy, Join
Read Config File
Load Classes

Sample 03
-------------------------
Sum, Min, Max, Average, Count
