﻿namespace Common.Library.Configuration
{
  public class ConfigurationValue
  {
    /// <summary>
    /// Get/Set ConfigurationValueId
    /// </summary>
    public int ConfigurationValueId { get; set; }

    /// <summary>
    /// Get/Set ConfigKey
    /// </summary>
    public string ConfigKey { get; set; }

    /// <summary>
    /// Get/Set ConfigValue
    /// </summary>
    public string ConfigValue { get; set; }

    /// <summary>
    /// Get/Set Description
    /// </summary>
    public string Description { get; set; }
  }
}
