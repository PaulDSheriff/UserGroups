namespace Common.Library.Configuration
{
  /// <summary>
  /// Class to handle reading configuration settings using a specific service such as .config file, Registry, XML, or database table
  /// </summary>
  public class ConfigurationManager
  {
    #region Constructors
    public ConfigurationManager()
    {
    }

    public ConfigurationManager(ConfigurationBase reader)
    {
      _ConfigReader = reader;
    }
    #endregion

    #region Instance
    private static ConfigurationManager _Instance = null;

    public static ConfigurationManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ConfigurationManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Configuration Reader Property
    private ConfigurationBase _ConfigReader = null;

    public ConfigurationBase ConfigurationReader
    {
      get { return _ConfigReader; }
      set { _ConfigReader = value; }
    }
    #endregion

    #region GetSetting Methods
    public virtual string GetSetting(string key)
    {
      return GetSetting(key, string.Empty);
    }

    public virtual string GetSetting(string key, string defaultValue)
    {
      if (ConfigurationReader == null)
        return defaultValue;
      else
        return ConfigurationReader.GetSetting(key, defaultValue);
    }
    #endregion
  }
}