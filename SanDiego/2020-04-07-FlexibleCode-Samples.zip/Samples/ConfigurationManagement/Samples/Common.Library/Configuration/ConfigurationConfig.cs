using System.Configuration;

namespace Common.Library.Configuration
{
  /// <summary>
  /// Class for reading .Config files
  /// </summary>
  public class ConfigurationConfig : ConfigurationBase
  {
    #region Constructor
    public ConfigurationConfig()
      : base(string.Empty)
    {
    }

    public ConfigurationConfig(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      string ret;

      ret = System.Configuration.ConfigurationManager.AppSettings[key];
      if (ret == null) { 
        ret = defaultValue;
      }

      return ret;
    }
    #endregion
  }
}