using System.Collections.Generic;
using Common.Library.DataLayer;
using System.Linq;

namespace Common.Library.Configuration
{
  /// <summary>
  /// Class for reading from database table
  /// </summary>
  public class ConfigurationDatabase : ConfigurationBase
  {
    #region Constructors  
    public ConfigurationDatabase(string location)
      : base(location)
    {
    }
    #endregion

    public static List<ConfigurationValue> ConfigurationValues { get; set; }

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      string ret;

      if (ConfigurationDatabase.ConfigurationValues == null) {
        ConfigurationDatabase.ConfigurationValues = DataHelper.GetCollection<ConfigurationValue>(base.Location, "SELECT * FROM ConfigurationValue");
      }

      var value = ConfigurationDatabase.ConfigurationValues.Find(c => c.ConfigKey == key);
      if (value != null) {
        ret = value.ConfigValue;
      }
      else {
        ret = defaultValue;
      }

      return ret;
    }
    #endregion
  }
}