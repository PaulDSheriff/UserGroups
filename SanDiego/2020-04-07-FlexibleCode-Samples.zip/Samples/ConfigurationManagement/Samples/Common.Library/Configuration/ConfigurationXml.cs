using System.Xml;

namespace Common.Library.Configuration
{
  /// <summary>
  /// Class for reading XML files
  /// </summary>
  public class ConfigurationXml : ConfigurationBase
  {
    #region Constructors
    public ConfigurationXml(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      XmlDocument xd;
      XmlNode xn;
      string xPathQuery;
      string ret = defaultValue;

      xd = new XmlDocument();
      xd.Load(base.Location);

      xPathQuery = string.Format("/configuration/appSettings/add[@key='{0}']", key);

      xn = xd.SelectSingleNode(xPathQuery);

      if (xn != null)
      {
        ret = xn.Attributes["value"].Value;
      }

      return ret;
    }
    #endregion
  }
}