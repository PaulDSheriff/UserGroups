﻿namespace Common.Library.Configuration
{
  /// <summary>
  /// Base class for all configuration classes
  /// </summary>
  public abstract class ConfigurationBase
  {
    #region Constructor
    public ConfigurationBase(string location)
    {
      Location = location;
    }
    #endregion

    /// <summary>
    /// Get/Set the location of the configuration settings 
    /// </summary>
    public string Location { get; set; }

    #region Abstract Methods
    public virtual string GetSetting(string key)
    {
      return GetSetting(key, null);
    }
    
    public abstract string GetSetting(string key, string defaultValue);
    #endregion
  }
}
