﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace Common.Library.DataLayer
{
  public class DataHelper
  {
    public static List<T> GetCollection<T>(string connString, string sql)
    {
      List<T> ret = new List<T>();

      // Create a connection
      using (SqlConnection cnn = new SqlConnection(connString)) {
        // Create command object
        using (SqlCommand cmd = new SqlCommand(sql, cnn)) {
          // Open the connection
          cnn.Open();
          // Execute command to get data reader
          using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
            ret = ToList<T>(dr);
          }
        }
      }

      return ret;
    }

    public static List<T> ToList<T>(IDataReader rdr)
    {
      List<T> ret = new List<T>();
      T entity;
      Type typ = typeof(T);
      List<ColumnMapper> columns = new List<ColumnMapper>();
      string name;
      PropertyInfo col;

      // Get all the properties in Entity Class
      PropertyInfo[] props = typ.GetProperties();

      // Get all ColumnAttribute's
      var attrs = props.Where(p => p.GetCustomAttributes(typeof(ColumnAttribute), false).Any()).ToArray();

      // Loop through one time to map columns to properties
      // NOTES:
      //   Assumes your column names are the same name as your class property names
      //   or the [Column()] attribute is used on your class
      //
      //   Any properties not in the data reader column list are not set
      //   Could implement caching here based on the Type passed in so you only need to perform this loop once
      for (int index = 0; index < rdr.FieldCount; index++) {
        // Get name from data reader
        name = rdr.GetName(index);
        // See if column name maps directly to property name
        col = props.FirstOrDefault(c => c.Name == name);

        // Column!=Property -> See if the column name is in a ColumnAttribute
        if (col == null) {
          for (int i = 0; i < attrs.Length; i++) {
            var tmp = attrs[i].GetCustomAttribute(typeof(ColumnAttribute));
            if (tmp != null && ((ColumnAttribute)tmp).Name == name) {
              col = props.FirstOrDefault(c => c.Name == attrs[i].Name);
              break;
            }
          }
        }

        if (col != null) {
          columns.Add(new ColumnMapper
          {
            ColumnName = name,
            ColumnProperty = col
          });
        }
      }

      // Loop through all records
      while (rdr.Read()) {
        // Create new instance of Entity
        entity = Activator.CreateInstance<T>();

        // Loop through columns to assign data
        for (int i = 0; i < columns.Count; i++) {
          if (rdr[columns[i].ColumnName].Equals(DBNull.Value)) {
            columns[i].ColumnProperty.SetValue(entity, null, null);
          }
          else {
            columns[i].ColumnProperty.SetValue(entity, rdr[columns[i].ColumnName], null);
          }
        }

        ret.Add(entity);
      }

      return ret;
    }
  }
}
