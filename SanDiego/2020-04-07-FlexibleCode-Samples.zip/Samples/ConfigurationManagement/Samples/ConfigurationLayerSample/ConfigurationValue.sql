CREATE TABLE [dbo].[ConfigurationValue](
	[ConfigurationValueId] [int] IDENTITY(1,1) NOT NULL,
	[ConfigKey] [nvarchar](50) NOT NULL,
	[ConfigValue] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](200) NULL
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[ConfigurationValue] ON 
GO
INSERT [dbo].[ConfigurationValue] ([ConfigurationValueId], [ConfigKey], [ConfigValue], [Description]) VALUES (1, N'DefaultStateCode', N'IA', N'State Code Default')
GO
INSERT [dbo].[ConfigurationValue] ([ConfigurationValueId], [ConfigKey], [ConfigValue], [Description]) VALUES (2, N'EmpType', N'30', N'Employee Type')
GO
SET IDENTITY_INSERT [dbo].[ConfigurationValue] OFF
GO
/****** Object:  Index [PK_pdsaApplicationSetting]    Script Date: 3/23/2020 8:52:48 AM ******/
ALTER TABLE [dbo].[ConfigurationValue] ADD  CONSTRAINT [PK_pdsaApplicationSetting] PRIMARY KEY NONCLUSTERED 
(
	[ConfigurationValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
