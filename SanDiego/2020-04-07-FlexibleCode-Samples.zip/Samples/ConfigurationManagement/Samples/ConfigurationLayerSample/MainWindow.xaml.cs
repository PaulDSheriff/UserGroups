﻿using System.Diagnostics;
using System.Windows;
using Common.Library.Configuration;

namespace ConfigurationLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void GetSettingConfigFileButton_Click(object sender, RoutedEventArgs e)
    {
      ConfigurationManager mgr =
        new ConfigurationManager(new ConfigurationConfig());

      ResultText.Text = mgr.GetSetting(KeyValue.Text);
    }

    private void GetSettingButton_Click(object sender, RoutedEventArgs e)
    {
      // See the code in ApplicationStart.cs to see the initialization
      ResultText.Text = ConfigurationManager.Instance.GetSetting(KeyValue.Text, "NOTHING");
    }

    private void GetSettingDefaultButton_Click(object sender, RoutedEventArgs e)
    {
      ResultText.Text = ConfigurationManager.Instance.GetSetting(KeyValue.Text, DefaultValue.Text);
    }

    private void AppConfigButton_Click(object sender, RoutedEventArgs e)
    {
      // See the code in AppConfig.cs to see the implementation of this
      Debug.WriteLine(AppConfig.Instance.EmpType);
      Debug.WriteLine(AppConfig.Instance.DefaultStateCode);

      Debugger.Break();
    }
  }
}
