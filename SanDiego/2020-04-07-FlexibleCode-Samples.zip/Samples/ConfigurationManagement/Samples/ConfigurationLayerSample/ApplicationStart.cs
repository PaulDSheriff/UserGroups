﻿using Common.Library.Configuration;

namespace ConfigurationLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Configuration Manager
      InitializeConfigurationManager();
    }

    protected void InitializeConfigurationManager()
    {
      //**************************************************************
      // Create Configuration Manager and use the Xml Provider
      //**************************************************************
      //ConfigurationManager.Instance =
      //  new ConfigurationManager(
      //    new ConfigurationXml(
      //      Common.Library.FileCommon.GetCurrentDirectory() + @"\Settings.xml"));

      //**************************************************************
      // Create Configuration Manager and use the Registry Provider
      //**************************************************************
      //ConfigurationManager.Instance =
      // new ConfigurationManager(
      //  new ConfigurationRegistry(@"Software\MyApp"));

      //*********************************************************************
      // Create Configuration Manager and use the Configuration File Provider
      //*********************************************************************
      //ConfigurationManager.Instance =
      // new ConfigurationManager(
      //   new ConfigurationConfig());

      //*********************************************************************
      // Create Configuration Manager and use the Database Provider
      //*********************************************************************
      ConfigurationManager.Instance =
       new ConfigurationManager(
         new ConfigurationDatabase(AppSettings.ConnectionString));
    }
  }
}
