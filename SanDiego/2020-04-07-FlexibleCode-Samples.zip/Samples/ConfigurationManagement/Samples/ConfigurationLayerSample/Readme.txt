﻿Configuration Management Samples
---------------------------------------------
These sample illustrate how to retrieve configuration settings from different locations
  - .config files
  - XML files
  - The Windows Registry
  - Database table

ConfigurationBase.cs - Base class for all other providers
ConfigurationConfig.cs - Provider to read from a .config file
ConfigurationDatabase.cs - Provider to read from a database table named ConfiguationValue
ConfigurationManager.cs - Class you use to read settings from one of the providers
ConfigurationValue.cs - Holds settings read from the ConfigurationValue table
ConfigurationXml.cs - Provider to read from an XML file

ConfigurationValue.sql - SQL Script to create the ConfigurationValue table.
Settings.reg - File to add entries to registry for this sample.
Settings.xml - XML file with configuration values. Same configuration as .config files.