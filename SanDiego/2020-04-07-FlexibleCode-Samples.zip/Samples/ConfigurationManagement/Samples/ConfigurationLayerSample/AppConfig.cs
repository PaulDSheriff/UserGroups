﻿using System;
using Common.Library.Configuration;

namespace ConfigurationLayerSample
{
  public class AppConfig
  {
    #region Instance Property
    private static AppConfig _Instance = null;

    public static AppConfig Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new AppConfig();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public int EmpType
    {
      get { return Convert.ToInt32(ConfigurationManager.Instance.GetSetting("EmpType")); }
    }

    public string DefaultStateCode
    {
      get { return ConfigurationManager.Instance.GetSetting("DefaultStateCode"); }
    }
  }
}
