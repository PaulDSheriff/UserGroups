﻿using System.Configuration;

namespace ConfigurationLayerSample
{
  public static class AppSettings
  {
    public static string ConnectionString
    {
      get { return ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString; }
    }
  }
}
