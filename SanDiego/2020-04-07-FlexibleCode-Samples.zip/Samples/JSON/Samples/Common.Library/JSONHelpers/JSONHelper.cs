﻿using System;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Common.Library
{
  public class JSONHelper
  {
    /// <summary>
    /// Pass in a file name where you previously stored your JSON serialized object and this method will de-serialize it and return it as that object. 
    /// </summary>
    /// <typeparam name="T">The type to cast to</typeparam>
    /// <param name="fileName">The file name</param>
    /// <returns>A type</returns>
    public static T LoadFromFile<T>(string fileName)
    {
      T ret = default;
      string value;

      try {
        value = File.ReadAllText(fileName);

        ret = (T)JSONToObject(typeof(T), value);
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }

      return ret;
    }

    public static string SaveToFile<T>(object value, string fileName)
    {
      string ret = string.Empty;

      try {
        ret = ObjectToJSON(value);

        File.WriteAllText(fileName, ret);
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }

      return ret;
    }
   
    /// <summary>
    /// Converts a JSON string into a specific type
    /// </summary>
    /// <param name="typ">The type to convert to</param>
    /// <param name="json">The JSON string to convert</param>
    /// <returns>A type</returns>
    public static object JSONToObject(Type typ, string json)
    {
      JsonSerializerSettings settings = new JsonSerializerSettings()
      {
        ContractResolver = new CamelCasePropertyNamesContractResolver()
      };

      return JsonConvert.DeserializeObject(json, typ, settings);
    }

    /// <summary>
    /// Pass in a specific object and this method will return the corresponding JSON string back
    /// </summary>
    /// <example>
    /// string value = ObjectToJSON(entity);
    /// </example>
    /// <param name="value">An object to serialize</param>
    /// <returns>Your object in a JSON string format</returns>
    public static string ObjectToJSON(object value)
    {
      JsonSerializerSettings settings = new JsonSerializerSettings()
      {
        ContractResolver = new CamelCasePropertyNamesContractResolver()
      };

      return JsonConvert.SerializeObject(value, settings);
    }
  }
}
