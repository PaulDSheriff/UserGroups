﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Common.Library;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace JSONSamples
{
  public partial class ReadJSONControl : UserControl
  {
    public ReadJSONControl()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      FileName.Text = FileCommon.GetCurrentDirectory() + @"\JSONFiles\Product.json";
    }

    private void JSONAll_Click(object sender, RoutedEventArgs e)
    {
      string value;

      try {
        // Read raw JSON from file
        value = File.ReadAllText(FileName.Text);

        // Set JSON options
        JsonSerializerSettings settings = new JsonSerializerSettings()
        {
          ContractResolver = new CamelCasePropertyNamesContractResolver()
        };

        // Deserialize list of products
        lstData.DataContext = JsonConvert.DeserializeObject(value, typeof(List<Product>), settings);
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }
    }

    private void JSONGeneric_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = JSONHelper.LoadFromFile<List<Product>>(FileName.Text);
    }
  }
}
