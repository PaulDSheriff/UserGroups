﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Common.Library;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace JSONSamples
{
  public partial class SaveJSONControl : UserControl
  {
    public SaveJSONControl()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      FileName.Text = @"D:\Samples\Product.json";
    }

    private void JSONSave_Click(object sender, RoutedEventArgs e)
    {
      Product prod = new Product
      {
        ProductID = 1,
        Name = "Product 1",
        ProductNumber = "PROD-01",
        StandardCost = 50,
        ListPrice = 100,
        SellStartDate = DateTime.Now
      };

      try {
        JsonSerializerSettings settings = new JsonSerializerSettings()
        {
          ContractResolver = new CamelCasePropertyNamesContractResolver()
        };

        string value = JsonConvert.SerializeObject(prod, settings);

        File.WriteAllText(FileName.Text, value);
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }
    }

    private void JSONSaveGeneric_Click(object sender, RoutedEventArgs e)
    {
      Product prod = new Product
      {
        ProductID = 2,
        Name = "Product 2",
        ProductNumber = "PROD-02",
        StandardCost = 20,
        ListPrice = 200,
        SellStartDate = DateTime.Now
      };

      JSONHelper.SaveToFile<Product>(prod, FileName.Text);
    }

    private void JSONRead_Click(object sender, RoutedEventArgs e)
    {
      Product prod = JSONHelper.LoadFromFile<Product>(FileName.Text);

      System.Diagnostics.Debug.WriteLine(prod.Name);

      System.Diagnostics.Debugger.Break();
    }
  }
}
