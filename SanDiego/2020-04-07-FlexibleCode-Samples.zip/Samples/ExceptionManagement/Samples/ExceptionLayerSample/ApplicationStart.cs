﻿using Common.Library.ExceptionManagement;

namespace ExceptionLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Exception Manager
      InitializeExceptionManager();
    }

    protected void InitializeExceptionManager()
    {
      //**************************************************************
      // Create Exception Manager and Add 'File' Publisher
      //**************************************************************
      ExceptionManager.Instance.Publishers.Add(
        new ExceptionToFile(Common.Library.FileCommon.GetCurrentDirectory() +
                                 @"\Exceptions.txt"));

      //**************************************************************
      // Create Exception Manager and Add 'Database' Publisher
      //**************************************************************
      ExceptionManager.Instance.Publishers.Add(
        new ExceptionToDB("Server=Localhost;Database=Sandbox;Integrated Security=Yes"));

      //**************************************************************
      // Create Exception Manager and Add 'Email' Publisher
      //**************************************************************
      Common.Library.EmailSettings settings = new Common.Library.EmailSettings
      {
        FromEmail = "PSheriff@pdsa.com",
        ToEmail = "PSheriff@pdsa.com",
        Subject = "Exception from the Exception Layer Samples"
      };

      ExceptionManager.Instance.Publishers.Add(
        new ExceptionToEMail(settings));
    }
  }
}
