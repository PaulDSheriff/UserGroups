﻿using System;
using System.Collections.Specialized;
using System.Windows;
using Common.Library.ExceptionManagement;

namespace ExceptionLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void PublishButton_Click(object sender, RoutedEventArgs e)
    {
      ExceptionManager.Instance.Publish(
        new ApplicationException("This is an exception"));

      MessageBox.Show("Exception Published");
    }

    private void PublishWithExtrasButton_Click(object sender, RoutedEventArgs e)
    {
      // Create extra values to publish
      NameValueCollection nvc = new NameValueCollection
      {
        { "DefaultStateCode", "CA" },
        { "EmpType", "20" }
      };

      ExceptionManager.Instance.Publish(
        new ApplicationException("This is an exception"), nvc);

      MessageBox.Show("Exception Published");
    }
  }
}
