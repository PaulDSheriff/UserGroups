using System;
using System.Collections.Generic;
using System.Collections.Specialized;

namespace Common.Library.ExceptionManagement
{
  /// <summary>
  /// Class for publishing exceptions
  /// </summary>
  public class ExceptionManager
  {
    #region Constructors
    public ExceptionManager()
    {      
    }
    #endregion

    #region Instance property
    private static ExceptionManager _Instance = null;

    public static ExceptionManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ExceptionManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Publishers Collection Property
    private List<ExceptionPublisherBase> _Publishers = 
      new List<ExceptionPublisherBase>();

    public List<ExceptionPublisherBase> Publishers
    {
      get { return _Publishers; }
      set { _Publishers = value; }
    }
    #endregion

    #region Publish Methods
    public virtual void Publish(Exception ex)
    {
      Publish(ex, null);
    }

    public virtual void Publish(Exception ex, NameValueCollection AdditionalInfo)
    {
      foreach (ExceptionPublisherBase item in Publishers)
      {
        item.Publish(ex, AdditionalInfo);
      }
    }
    #endregion
  }
}