using System;
using System.IO;

namespace Common.Library.ExceptionManagement
{
  /// <summary>
  /// Class for publishing exceptions to a file
  /// </summary>
  public class ExceptionToFile : ExceptionPublisherBase
  {
    #region Constructors
    public ExceptionToFile(string fileName)
    {
      _FileName = fileName;
    }
    #endregion

    #region Private Variables
    private string _FileName = string.Empty;
    #endregion

    #region PublishException Method
    protected override void PublishException()
    {
      if (string.IsNullOrEmpty(_FileName))
      {
        _FileName = Environment.CurrentDirectory + @"\" + Environment.UserName + "-Error.log";
      }

      try
      {
        //  Write to File Here
        File.AppendAllText(_FileName, ExceptionInfo.ToString());
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Error in FWExceptionToFile publisher", ex);
      }
    }
    #endregion
  }
}