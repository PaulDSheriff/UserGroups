using System;
using System.Net.Mail;

namespace Common.Library.ExceptionManagement
{
  /// <summary>
  /// Class for publishing exceptions to email
  /// </summary>
  public class ExceptionToEMail : ExceptionPublisherBase
  {
    #region Constructors
    /// <summary>
    /// Create an instance of an email exception publisher
    /// </summary>
    /// <param name="settings">An instance of FWEmailSettings</param>
    public ExceptionToEMail(EmailSettings settings)
    {
      _Settings = settings;
    }
    #endregion

    #region Private Variables
    private EmailSettings _Settings = null;
    #endregion

    #region PublishException Method
    protected override void PublishException()
    {
      SmtpClient smtp = null;

      _Settings.ToEmail = _Settings.ToEmail.Replace(";", ",");
      try
      {
        smtp = new SmtpClient();

        // TODO: Uncomment out the following when you are hooked up to email
        //  Send Exception via Email
        //smtp.Send(_Settings.FromEmail,
        //          _Settings.ToEmail,
        //          _Settings.Subject,
        //          ExceptionInfo.ToString());
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Error in FWExceptionToEmail publisher.", ex);
      }
      finally
      {
        if (smtp != null)
        {
          smtp.Dispose();
        }
      }
    }
    #endregion
  }
}