using System;
using System.IO;

namespace Common.Library.ExceptionManagement
{
  /// <summary>
  /// Class for publishing exceptions to a SQL Table
  /// </summary>
  public class ExceptionToDB : ExceptionPublisherBase
  {
    #region Constructors
    public ExceptionToDB(string connectString)
    {
      _ConnectString = connectString;
    }
    #endregion

    #region Private Variables
    private string _ConnectString = string.Empty;
    #endregion

    #region PublishException Method
    protected override void PublishException()
    {
      if (string.IsNullOrEmpty(_ConnectString))
      {
        _ConnectString = "Server=localhost;Database=Sandbox;Integrated Security=Yes";
      }

      try
      {
        //  TODO: Write to database table here
        
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Error in FWExceptionToDB publisher", ex);
      }
    }
    #endregion
  }
}