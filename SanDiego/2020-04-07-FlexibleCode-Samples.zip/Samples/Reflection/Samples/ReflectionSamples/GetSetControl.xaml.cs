﻿using System;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace ReflectionSamples
{
  public partial class GetSetControl : UserControl
  {
    public GetSetControl()
    {
      InitializeComponent();
    }

    private void InvokeMember_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();
      typeof(Product).InvokeMember("Name",
        BindingFlags.SetProperty,
          Type.DefaultBinder, entity,
           new Object[] { "10 Speed Bike" });

      MessageBox.Show(entity.Name);
    }

    private void SetValue_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      // NOTE: This method is more efficient
      typeof(Product).GetProperty("Name").
        SetValue(entity, "12 Speed Bike", null);

      MessageBox.Show(entity.Name);
    }

    private void InvokeMemberGet_Click(object sender, RoutedEventArgs e)
    {
      object value;
      Product entity = new Product
      {
        Name = "Red Biking Helmet"
      };

      value = typeof(Product).InvokeMember("Name",
        BindingFlags.GetProperty,
          Type.DefaultBinder, entity, null);

      MessageBox.Show(value.ToString());
    }

    private void GetValue_Click(object sender, RoutedEventArgs e)
    {
      object value;
      Product entity = new Product
      {
        Name = "Black Biking Shorts"
      };

      // NOTE: This method is more efficient
      value = typeof(Product).GetProperty("Name").GetValue(entity);

      MessageBox.Show(value.ToString());
    }
  }
}
