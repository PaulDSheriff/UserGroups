﻿using System.Windows;

namespace ReflectionSamples
{
  public partial class App : Application
  {
  }
}
