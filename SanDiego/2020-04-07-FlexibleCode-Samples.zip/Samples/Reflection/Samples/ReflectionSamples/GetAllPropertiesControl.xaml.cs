﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace ReflectionSamples
{
  public partial class GetAllPropertiesControl : UserControl
  {
    public GetAllPropertiesControl()
    {
      InitializeComponent();
    }

    private void GetAllProperties_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      Type t = entity.GetType();
      PropertyInfo[] props = t.GetProperties();
      // The line below is the same as the line above
      //PropertyInfo[] props = t.GetProperties(BindingFlags.Public | BindingFlags.Instance);

      // Show how to loop through all properties
      foreach (PropertyInfo prp in props) {
        Debug.WriteLine("Name: " + prp.Name);
        Debug.WriteLine("Type: " + prp.PropertyType);
        Debug.WriteLine("Can Read?: " + prp.CanRead);
        Debug.WriteLine("Can Write?: " + prp.CanWrite);
        Debug.WriteLine("*****************************");
      }

      lstData.DataContext = props;
    }

    private void GetAllNonPublicProperties_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      Type t = entity.GetType();
      PropertyInfo[] props = t.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);

      // Show how to loop through all properties
      foreach (PropertyInfo prp in props) {
        Debug.WriteLine("Name: " + prp.Name);
        Debug.WriteLine("Type: " + prp.PropertyType);
        Debug.WriteLine("Can Read?: " + prp.CanRead);
        Debug.WriteLine("Can Write?: " + prp.CanWrite);
        Debug.WriteLine("*****************************");
      }

      lstData.DataContext = props;
    }
  }
}
