﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using Common.Library.DataLayer;

namespace ReflectionSamples
{
  public partial class MapDataControl : UserControl
  {
    public MapDataControl()
    {
      InitializeComponent();
    }

    private void HardCoded_Click(object sender, RoutedEventArgs e)
    {
      GetProductsHardCoded();
    }

    public void GetProductsHardCoded()
    {
      List<Product> products = new List<Product>();

      // Create a connection
      using (SqlConnection cnn = new SqlConnection(AppSettings.ConnectionString)) {
        // Create command object
        using (SqlCommand cmd = new SqlCommand("SELECT ProductID, Name, ProductNumber, StandardCost, ListPrice, SellStartDate FROM SalesLT.Product", cnn)) {
          // Open the connection
          cnn.Open();

          // Execute command to get data reader
          using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)) {
            while (dr.Read()) {
              products.Add(new Product
              {
                ProductID = dr.GetInt32(dr.GetOrdinal("ProductID")),
                Name = dr.GetString(dr.GetOrdinal("Name")),
                ProductNumber = dr.GetString(dr.GetOrdinal("ProductNumber")),
                StandardCost = dr.GetDecimal(dr.GetOrdinal("StandardCost")),
                ListPrice = dr.GetDecimal(dr.GetOrdinal("ListPrice")),
                SellStartDate = dr.GetDateTime(dr.GetOrdinal("SellStartDate"))
              });
            }
          }
        }
      }

      lstData.DataContext = products;
    }

    private void Reflection_Click(object sender, RoutedEventArgs e)
    {
      ReflectionSample();
    }

    private void ReflectionSample()
    {
      List<Product> products;

      products = DataHelper.GetCollection<Product>(
        AppSettings.ConnectionString, 
        "SELECT ProductID, Name, ProductNumber, StandardCost, ListPrice, SellStartDate FROM SalesLT.Product");

      lstData.DataContext = products;
    }
  }
}
