﻿using System.Configuration;

namespace Common.Library.DataLayer
{
  public static class AppSettings
  {
    public static string ConnectionString
    {
      get { return ConfigurationManager.ConnectionStrings["AdvWorks"].ConnectionString; }
    }
  }
}
