﻿using System.Linq;
using System.Xml.Linq;

namespace Common.Library.MessageResources
{
  /// <summary>
  /// "Cass for reading from XML files
  /// </summary>
  public class MessageResourceXml : MessageResourceBase
  {
    #region Constructors
    public MessageResourceXml()
      : base()
    {
    }

    public MessageResourceXml(string location)
      : base(location)
    {
    }

    public MessageResourceXml(string location, string language)
      : base(location, language)
    {
    }
    #endregion

    public override string GetMessage(string key, string language, string defaultMessage)
    {
      string ret = defaultMessage;

      XElement doc = XElement.Load(Location);

      XElement elem = (from node in doc.Elements("Message")
                       where node.Element("Language").Value == language
                       && node.Element("Key").Value == key
                       select node).SingleOrDefault();

      if (elem != null)
        ret = elem.Element("Value").Value;

      return ret;
    }
  }
}
