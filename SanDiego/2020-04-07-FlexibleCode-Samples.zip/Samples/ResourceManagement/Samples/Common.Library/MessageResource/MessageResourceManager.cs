﻿namespace Common.Library.MessageResources
{
  /// <summary>
  /// Manager class for reading messages / resources
  /// </summary>
  public class MessageResourceManager
  {
    #region Constructors
    public MessageResourceManager()
    {
    }

    public MessageResourceManager(MessageResourceBase reader)
    {
      MessageReader = reader;
    }
    #endregion

    #region Instance
    private static MessageResourceManager _Instance = null;

    public static MessageResourceManager Instance
    {
      get {
        if (_Instance == null)
          _Instance = new MessageResourceManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public MessageResourceBase MessageReader { get; set; }

    #region GetMessage Methods
    public virtual string GetMessage(string key)
    {
      if (MessageReader == null) {
        return string.Empty;
      }
      else {
        return GetMessage(key, MessageReader.Language, string.Empty);
      }
    }

    public virtual string GetMessage(string key, string defaultValue)
    {
      if (MessageReader == null) {
        return string.Empty;
      }
      else {
        return GetMessage(key, MessageReader.Language, defaultValue);
      }
    }

    public virtual string GetMessage(string key, string language, string defaultValue)
    {
      if (MessageReader == null) {
        return defaultValue;
      }
      else {
        return MessageReader.GetMessage(key, language, defaultValue);
      }
    }
    #endregion
  }
}
