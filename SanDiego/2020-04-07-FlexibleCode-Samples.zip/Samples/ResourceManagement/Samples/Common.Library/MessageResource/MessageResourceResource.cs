﻿using System;
using System.Linq;
using System.Reflection;
using System.Resources;

namespace Common.Library.MessageResources
{
  /// <summary>
  /// Class for reading from Resource file
  /// </summary>
  public class MessageResourceResource : MessageResourceBase
  {
    #region Constructors
    public MessageResourceResource()
      : base()
    {
    }
    public MessageResourceResource(string location)
      : base(location)
    {
    }
    public MessageResourceResource(string location, string language)
      : base(location, language)
    {
    }
    #endregion

    public ResourceManager ResourceManager { get; set; }

    protected virtual void SetResourceManager()
    {
      if (ResourceManager == null) {
        Assembly assm = Assembly.GetEntryAssembly();
        if (assm == null) {
          assm = Assembly.GetCallingAssembly();
        }
        if (assm != null) {
          if (string.IsNullOrEmpty(Location)) {
           Location = assm.GetName().Name + ".Properties.Resources";
          }          
          ResourceManager = new ResourceManager(Location, assm);
        }
      }
    }

    public override string GetMessage(string key, string language, string defaultMessage)
    {
      string ret = defaultMessage;

      try {
        // If the language changes, reset the Resource manager
        if (language != Language) {
          ResourceManager = null;
          Location = null;
          Language = language;
          // Set UI Culture
          System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(Language);
        }

        SetResourceManager();

        ret = ResourceManager.GetString(key);
        if (string.IsNullOrEmpty(ret)) {
          ret = defaultMessage;
        }
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.Write(ex.Message);
      }

      return ret;
    }
  }
}
