﻿using System;

namespace Common.Library.MessageResources
{
  /// <summary>
  /// Base class for all Message/Resource classes
  /// </summary>
  public abstract class MessageResourceBase
  {
    public const string DEFAULT_LANGUAGE = "en-US";

    #region Constructors
    public MessageResourceBase()
    {
      Location = string.Empty;
      Language = DEFAULT_LANGUAGE;
    }

    public MessageResourceBase(string location)
    {
      Location = location;
      Language = DEFAULT_LANGUAGE;
    }

    public MessageResourceBase(string location, string language)
    {
      Location = location;
      Language = language;
    }
    #endregion

    public string Location { get; set; }
    public string Language { get; set; }

    public virtual string GetMessage(string key)
    {
      return GetMessage(key, Language, string.Format("Message {0} Not Found.", key));
    }

    public virtual string GetMessage(string key, string language)
    {
      return GetMessage(key, language, string.Format("Message {0} Not Found.", key));
    }

    public abstract string GetMessage(string key, string language, string defaultMessage);
  }
}
