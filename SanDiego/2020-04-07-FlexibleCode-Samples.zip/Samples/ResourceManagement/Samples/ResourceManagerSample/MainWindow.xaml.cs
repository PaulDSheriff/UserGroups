﻿using System.Windows;
using Common.Library.MessageResources;

namespace ResourceManagerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void GetMessageButton_Click(object sender, RoutedEventArgs e)
    {
      ResultText.Text =
        MessageResourceManager.Instance.GetMessage(KeyValue.Text, LanguageValue.Text, "");
    }

    private void GetMessageDefaultButton_Click(object sender, RoutedEventArgs e)
    {
      ResultText.Text =
        MessageResourceManager.Instance.GetMessage(KeyValue.Text, LanguageValue.Text, DefaultValue.Text);
    }
  }
}
