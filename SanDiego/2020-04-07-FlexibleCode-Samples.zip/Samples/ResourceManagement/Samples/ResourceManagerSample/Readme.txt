﻿Message/Resource (Localization) System
--------------------------------------
This sample shows how to build a system to read messages, labels and other UI items to display via a messaging/resource system.

Initialize which source of messages you wish to use in the ApplicationStart class.
  Call the ApplicationStart.Instance.Initialize() method from the App.OnStartUp() method.

There are two message providers; Resource and Xml provided in this sample.
Both these message providers inherit from the MessageResourceBase class.

There are three languages you can try
en-US
es
fr