﻿using Common.Library.MessageResources;

namespace ResourceManagerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Message Resource Manager
      InitializeMessageResourceManager();
    }

    protected void InitializeMessageResourceManager()
    {
      //**************************************************************
      // Create Message Manager and Default to 'Resource' Provider
      // The resources will come from the current project
      //**************************************************************
      MessageResourceManager.Instance =
        new MessageResourceManager(new MessageResourceResource());

      //**************************************************************
      // Create Message Manager and Pass in Resource Name
      //**************************************************************
      //MessageResourceManager.Instance =
      //  new MessageResourceManager(
      //    new MessageResourceResource("ResourceManagerSample.Properties.Resources"));

      //**************************************************************
      // Create Message Manager and Default to 'XML' Provider
      //**************************************************************
      //MessageResourceManager.Instance =
      //  new MessageResourceManager(
      //    new MessageResourceXml(Common.Library.FileCommon.GetCurrentDirectory() + @"\Xml\Messages.xml"));
    }
  }
}
