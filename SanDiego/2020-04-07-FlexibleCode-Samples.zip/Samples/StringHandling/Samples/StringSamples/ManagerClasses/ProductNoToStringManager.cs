﻿using System.Collections.Generic;

namespace StringSamples
{
  public class ProductNoToStringManager
  {
    #region GetAll Method
    public List<ProductNoToString> GetAll()
    {
      return new List<ProductNoToString>
      {
        new ProductNoToString {
        ProductID = 680,
        Name = "HL Road Frame - Black, 58",
        ProductNumber = "FR-R92B-58",
        Color = "Black",
        StandardCost = 1059.31M,
        ListPrice = 1431.50M
        },
        new ProductNoToString {
        ProductID = 706,
        Name = "HL Road Frame - Red, 58",
        ProductNumber = "FR-R92R-58",
        Color = "Red",
        StandardCost = 1059.31M,
        ListPrice = 1431.50M
        },
        new ProductNoToString {
        ProductID = 707,
        Name = "Sport-100 Helmet, Red",
        ProductNumber = "HL-U509-R",
        Color = "Red",
        StandardCost = 13.08M,
        ListPrice = 34.99M
        },
        new ProductNoToString {
        ProductID = 708,
        Name = "Sport-100 Helmet, Black",
        ProductNumber = "HL-U509",
        Color = "Black",
        StandardCost = 13.09M,
        ListPrice = 34.99M
        },
        new ProductNoToString {
        ProductID = 709,
        Name = "Mountain Bike Socks, M",
        ProductNumber = "SO-B909-M",
        Color = "White",
        StandardCost = 3.40M,
        ListPrice = 9.50M
        },
        new ProductNoToString {
        ProductID = 710,
        Name = "Mountain Bike Socks, L",
        ProductNumber = "SO-B909-L",
        Color = "White",
        StandardCost = 3.40M,
        ListPrice = 9.50M
        },
        new ProductNoToString {
        ProductID = 711,
        Name = "Sport-100 Helmet, Blue",
        ProductNumber = "HL-U509-B",
        Color = "Blue",
        StandardCost = 13.09M,
        ListPrice = 34.99M
        },
        new ProductNoToString {
        ProductID = 712,
        Name = "AWC Logo Cap",
        ProductNumber = "CA-1098",
        Color = "Multi",
        StandardCost = 6.92M,
        ListPrice = 8.99M
        },
        new ProductNoToString {
        ProductID = 713,
        Name = "Long-Sleeve Logo Jersey, S",
        ProductNumber = "LJ-0192-S",
        Color = "Multi",
        StandardCost = 38.49M,
        ListPrice = 49.99M
        },
        new ProductNoToString {
        ProductID = 714,
        Name = "Long-Sleeve Logo Jersey, M",
        ProductNumber = "LJ-0192-M",
        Color = "Multi",
        StandardCost = 38.49M,
        ListPrice = 49.99M
        },
        new ProductNoToString {
        ProductID = 715,
        Name = "Long-Sleeve Logo Jersey, L",
        ProductNumber = "LJ-0192-L",
        Color = "Multi",
        StandardCost = 38.49M,
        ListPrice = 49.99M
        },
        new ProductNoToString {
        ProductID = 716,
        Name = "Long-Sleeve Logo Jersey, XL",
        ProductNumber = "LJ-0192-X",
        Color = "Multi",
        StandardCost = 38.49M,
        ListPrice = 49.99M
        },
        new ProductNoToString {
        ProductID = 717,
        Name = "HL Road Frame - Red, 62",
        ProductNumber = "FR-R92R-62",
        Color = "Red",
        StandardCost = 868.63M,
        ListPrice = 1431.50M
        },
        new ProductNoToString {
        ProductID = 718,
        Name = "HL Road Frame - Red, 44",
        ProductNumber = "FR-R92R-44",
        Color = "Red",
        StandardCost = 868.63M,
        ListPrice = 1431.50M
        },
        new ProductNoToString {
        ProductID = 719,
        Name = "HL Road Frame - Red, 48",
        ProductNumber = "FR-R92R-48",
        Color = "Red",
        StandardCost = 868.63M,
        ListPrice = 1431.50M
        },
        new ProductNoToString {
        ProductID = 720,
        Name = "HL Road Frame - Red, 52",
        ProductNumber = "FR-R92R-52",
        Color = "Red",
        StandardCost = 868.63M,
        ListPrice = 1431.50M
        },
        new ProductNoToString {
        ProductID = 721,
        Name = "HL Road Frame - Red, 56",
        ProductNumber = "FR-R92R-56",
        Color = "Red",
        StandardCost = 868.63M,
        ListPrice = 1431.50M
        },
        new ProductNoToString {
        ProductID = 722,
        Name = "LL Road Frame - Black, 58",
        ProductNumber = "FR-R38B-58",
        Color = "Black",
        StandardCost = 204.63M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 723,
        Name = "LL Road Frame - Black, 60",
        ProductNumber = "FR-R38B-60",
        Color = "Black",
        StandardCost = 204.63M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 724,
        Name = "LL Road Frame - Black, 62",
        ProductNumber = "FR-R38B-62",
        Color = "Black",
        StandardCost = 204.63M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 725,
        Name = "LL Road Frame - Red, 44",
        ProductNumber = "FR-R38R-44",
        Color = "Red",
        StandardCost = 187.16M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 726,
        Name = "LL Road Frame - Red, 48",
        ProductNumber = "FR-R38R-48",
        Color = "Red",
        StandardCost = 187.16M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 727,
        Name = "LL Road Frame - Red, 52",
        ProductNumber = "FR-R38R-52",
        Color = "Red",
        StandardCost = 187.16M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 728,
        Name = "LL Road Frame - Red, 58",
        ProductNumber = "FR-R38R-58",
        Color = "Red",
        StandardCost = 187.16M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 729,
        Name = "LL Road Frame - Red, 60",
        ProductNumber = "FR-R38R-60",
        Color = "Red",
        StandardCost = 187.16M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 730,
        Name = "LL Road Frame - Red, 62",
        ProductNumber = "FR-R38R-62",
        Color = "Red",
        StandardCost = 187.16M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 731,
        Name = "ML Road Frame - Red, 44",
        ProductNumber = "FR-R72R-44",
        Color = "Red",
        StandardCost = 352.14M,
        ListPrice = 594.83M
        },
        new ProductNoToString {
        ProductID = 732,
        Name = "ML Road Frame - Red, 48",
        ProductNumber = "FR-R72R-48",
        Color = "Red",
        StandardCost = 352.14M,
        ListPrice = 594.83M
        },
        new ProductNoToString {
        ProductID = 733,
        Name = "ML Road Frame - Red, 52",
        ProductNumber = "FR-R72R-52",
        Color = "Red",
        StandardCost = 352.14M,
        ListPrice = 594.83M
        },
        new ProductNoToString {
        ProductID = 734,
        Name = "ML Road Frame - Red, 58",
        ProductNumber = "FR-R72R-58",
        Color = "Red",
        StandardCost = 352.14M,
        ListPrice = 594.83M
        },
        new ProductNoToString {
        ProductID = 735,
        Name = "ML Road Frame - Red, 60",
        ProductNumber = "FR-R72R-60",
        Color = "Red",
        StandardCost = 352.14M,
        ListPrice = 594.83M
        },
        new ProductNoToString {
        ProductID = 736,
        Name = "LL Road Frame - Black, 44",
        ProductNumber = "FR-R38B-44",
        Color = "Black",
        StandardCost = 204.63M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 737,
        Name = "LL Road Frame - Black, 48",
        ProductNumber = "FR-R38B-48",
        Color = "Black",
        StandardCost = 204.63M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 738,
        Name = "LL Road Frame - Black, 52",
        ProductNumber = "FR-R38B-52",
        Color = "Black",
        StandardCost = 204.63M,
        ListPrice = 337.22M
        },
        new ProductNoToString {
        ProductID = 739,
        Name = "HL Mountain Frame - Silver, 42",
        ProductNumber = "FR-M94S-42",
        Color = "Silver",
        StandardCost = 747.20M,
        ListPrice = 1364.50M
        },
        new ProductNoToString {
        ProductID = 740,
        Name = "HL Mountain Frame - Silver, 44",
        ProductNumber = "FR-M94S-44",
        Color = "Silver",
        StandardCost = 706.81M,
        ListPrice = 1364.50M
        },
        new ProductNoToString {
        ProductID = 741,
        Name = "HL Mountain Frame - Silver, 48",
        ProductNumber = "FR-M94S-52",
        Color = "Silver",
        StandardCost = 706.81M,
        ListPrice = 1364.50M
        },
        new ProductNoToString {
        ProductID = 742,
        Name = "HL Mountain Frame - Silver, 46",
        ProductNumber = "FR-M94S-46",
        Color = "Silver",
        StandardCost = 747.20M,
        ListPrice = 1364.50M
        },
        new ProductNoToString {
        ProductID = 743,
        Name = "HL Mountain Frame - Black, 42",
        ProductNumber = "FR-M94B-42",
        Color = "Black",
        StandardCost = 739.04M,
        ListPrice = 1349.60M
        },
        new ProductNoToString {
        ProductID = 744,
        Name = "HL Mountain Frame - Black, 44",
        ProductNumber = "FR-M94B-44",
        Color = "Black",
        StandardCost = 699.09M,
        ListPrice = 1349.60M
        }
      };
    }
    #endregion
  }
}
