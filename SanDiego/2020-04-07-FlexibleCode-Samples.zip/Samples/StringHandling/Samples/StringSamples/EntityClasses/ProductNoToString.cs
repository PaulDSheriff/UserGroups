﻿using System.Diagnostics;

namespace StringSamples
{
  // [DebuggerDisplay("{Name} ({ProductID})")]
  public class ProductNoToString
  {
    public int ProductID { get; set; }
    public string Name { get; set; }
    public string ProductNumber { get; set; }
    public string Color { get; set; }
    public decimal? StandardCost { get; set; }
    public decimal? ListPrice { get; set; }
  }
}
