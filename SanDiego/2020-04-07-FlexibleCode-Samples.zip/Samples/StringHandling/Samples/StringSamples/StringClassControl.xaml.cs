﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;

namespace StringSamples
{
  public partial class StringClassControl : UserControl
  {
    public StringClassControl()
    {
      InitializeComponent();
    }

    #region Static Methods
    private void StringFormat_Click(object sender, RoutedEventArgs e)
    {
      string value;

      value = string.Format("Hello {0}, you have just won {1}", "Tom", 20.ToString("c"));

      Result.Text = value;
    }

    private void StringIsNullOrEmpty_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value;

      // The following does not work because 'value' is unassigned
      //result = string.IsNullOrEmpty(value);

      value = null;
      result += "string.IsNullOrEmpty(null) = " + string.IsNullOrEmpty(value) + Environment.NewLine;

      value = "";
      result += "string.IsNullOrEmpty(\"\") = " + string.IsNullOrEmpty(value) + Environment.NewLine;

      value = " ";
      result += "string.IsNullOrEmpty(\" \") = " + string.IsNullOrEmpty(value) + Environment.NewLine;

      value = "Some Text";
      result += "string.IsNullOrEmpty(\"Some Text\") = " + string.IsNullOrEmpty(value) + Environment.NewLine;

      Result.Text = result;
    }

    private void StringIsNullOrWhiteSpace_Click(object sender, RoutedEventArgs e)
    {
      string result = "";

      string value = null;
      result += "string.IsNullOrWhiteSpace(null) = " + string.IsNullOrWhiteSpace(value) + Environment.NewLine;

      value = "";
      result += "string.IsNullOrWhiteSpace(\"\") = " + string.IsNullOrWhiteSpace(value) + Environment.NewLine;

      value = " ";
      result += "string.IsNullOrWhiteSpace(\" \") = " + string.IsNullOrWhiteSpace(value) + Environment.NewLine;

      value = "    ";
      result += "string.IsNullOrWhiteSpace(\"   \") = " + string.IsNullOrWhiteSpace(value) + Environment.NewLine;

      Result.Text = result;
    }

    private void StringJoin_Click(object sender, RoutedEventArgs e)
    {
      string[] parts = { "Bike", "Helmet", "Wheel", "Spokes", "Chain" };

      string value = string.Join(",", parts);

      Result.Text = value;
    }
    #endregion

    #region String Object Methods
    private void Contains_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.Contains(\"Wheel\") = " + value.Contains("Wheel").ToString() + Environment.NewLine;
      result += "value.Contains(\"Whee\") = " + value.Contains("Whee").ToString() + Environment.NewLine;
      result += "value.Contains(\"Drums\") = " + value.Contains("Drums").ToString() + Environment.NewLine;

      Result.Text = result;
    }

    private void StartsWith_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.StartsWith(\"Bike\") = " + value.StartsWith("Bike").ToString() + Environment.NewLine;
      result += "value.StartsWith(\"Chain\") = " + value.StartsWith("Chain").ToString() + Environment.NewLine;

      Result.Text = result;
    }

    private void EndsWith_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.EndsWith(\"Chain\") = " + value.EndsWith("Chain").ToString() + Environment.NewLine;
      result += "value.EndsWith(\"Bike\") = " + value.EndsWith("Bike").ToString() + Environment.NewLine;

      Result.Text = result;
    }

    private void IndexOf_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.IndexOf(\",\") = " + value.IndexOf(",").ToString() + Environment.NewLine;
      result += "value.IndexOf(\"Helmet\") = " + value.IndexOf("Helmet").ToString() + Environment.NewLine;
      result += "value.IndexOf(\"Bike\") = " + value.IndexOf("Bike").ToString() + Environment.NewLine;

      Result.Text = result;
    }

    private void LastIndexOf_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.LastIndexOf(\",\") = " + value.LastIndexOf(",").ToString() + Environment.NewLine;
      result += "value.LastIndexOf(\"Helmet\") = " + value.LastIndexOf("Helmet").ToString() + Environment.NewLine;
      result += "value.LastIndexOf(\"Bike\") = " + value.LastIndexOf("Bike").ToString() + Environment.NewLine;

      Result.Text = result;
    }

    private void Insert_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.Insert(5, \"Clothes,\") = " + value.Insert(5, "Clothes,") + Environment.NewLine;

      Result.Text = result;
    }

    private void Remove_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.Remove(5, 7) = " + value.Remove(5, 7) + Environment.NewLine;

      Result.Text = result;
    }

    private void Replace_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.Replace(\"Wheel\", \"Clothes\") = " + value.Replace("Wheel", "Clothes") + Environment.NewLine;

      Result.Text = result;
    }

    private void Substring_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.Substring(5, 6) = " + value.Substring(5, 6) + Environment.NewLine;

      Result.Text = result;
    }

    private void Split_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      string[] parts = value.Split(",".ToCharArray());

      foreach (string part in parts) {
        result += part + Environment.NewLine;
      }

      Result.Text = result;
    }

    private void ToLower_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.ToLower() = " + value.ToLower() + Environment.NewLine;
      result += "value.ToLowerInvariant() = " + value.ToLowerInvariant() + Environment.NewLine;

      Result.Text = result;
    }

    private void ToUpper_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "Bike,Helmet,Wheel,Spokes,Chain";

      result += "value.ToUpper() = " + value.ToUpper() + Environment.NewLine;
      result += "value.ToUpperInvariant() = " + value.ToUpperInvariant() + Environment.NewLine;

      Result.Text = result;
    }

    private void Trim_Click(object sender, RoutedEventArgs e)
    {
      string result = "";
      string value = "   Bike,Helmet,Wheel,Spokes,Chain   ";

      Result.FontFamily = new System.Windows.Media.FontFamily("Courier New");

      result += "value              = " + value + Environment.NewLine;
      result += "value.Trim()       = " + value.Trim() + Environment.NewLine;
      result += "value.TrimEnd()    = " + value.TrimEnd() + Environment.NewLine;
      result += "value.TrimStart()  = " + value.TrimStart() + Environment.NewLine;

      Result.Text = result;
    }
    #endregion

    #region ToString Override Method
    private void ToString_Click(object sender, RoutedEventArgs e)
    {
      List<ProductNoToString> productsNoToString = new ProductNoToStringManager().GetAll();

      Result.Text = "No Override: " + productsNoToString[0].ToString();

      // Hover over 'productsNoToString' variable
      System.Diagnostics.Debugger.Break();

      List<Product> products = new ProductManager().GetAll();

      Result.Text += Environment.NewLine;
      Result.Text += "With Override: " + products[0].ToString();

      // Hover over 'products' variable
      System.Diagnostics.Debugger.Break();
    }
    #endregion
  }
}
