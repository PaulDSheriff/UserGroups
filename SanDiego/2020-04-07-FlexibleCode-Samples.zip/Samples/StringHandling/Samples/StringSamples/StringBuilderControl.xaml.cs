﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace StringSamples
{
	public partial class StringBuilderControl : UserControl
  {
    public StringBuilderControl()
    {
      InitializeComponent();
    }
				
		private void DisplayMessage(string msg)
		{
			tbMessage.Text = msg;
		}

		private void CreateButton_Click(object sender, RoutedEventArgs e)
		{
			CreateSample(Sentence.Text);
		}

		private void CreateSample(string value)
		{
			// Create string and put in initial value
			StringBuilder sb = new StringBuilder(value);

			DisplayMessage(sb.ToString());
		}

		private void Create2Button_Click(object sender, RoutedEventArgs e)
		{
			CreateSample2(Sentence.Text);
		}

		private void CreateSample2(string value)
		{
			// Allocate 100 bytes of storage to start
			StringBuilder sb = new StringBuilder(value, 100);

			DisplayMessage(sb.ToString());
		}

		private void Create3Button_Click(object sender, RoutedEventArgs e)
		{
			CreateSample3();
		}

		private void CreateSample3()
		{
			// Allocate 100 bytes of storage to start and 200 maximum
			StringBuilder sb = new StringBuilder(100, 200);

			DisplayMessage(sb.ToString());
		}

		private void AppendButton_Click(object sender, RoutedEventArgs e)
		{
			AppendSample(Sentence.Text);
		}

		private void AppendSample(string value)
		{
			StringBuilder sb = new StringBuilder();

			sb.Append(value);

			DisplayMessage(sb.ToString());
		}

		private void CapacityButton_Click(object sender, RoutedEventArgs e)
		{
			CapacitySample(Sentence.Text);
		}

		private void CapacitySample(string value)
		{
			StringBuilder sb = new StringBuilder(value);

			sb.Append(Environment.NewLine);
			sb.Append("Length is: " + sb.Length.ToString());
			sb.Append(Environment.NewLine);
			sb.Append("Capacity is: " + sb.Capacity.ToString());
			sb.Append(Environment.NewLine);
			sb.Append("Maximum Capacity is: " + sb.MaxCapacity.ToString());

			DisplayMessage(sb.ToString());
		}

		private void AppendFormatButton_Click(object sender, RoutedEventArgs e)
		{
			AppendFormatSample(Sentence.Text);
		}

		private void AppendFormatSample(string value)
		{
			StringBuilder sb = new StringBuilder(value);

			sb.Append(Environment.NewLine);
			sb.AppendFormat("{0}: {1}", "Capacity is", sb.Capacity);
			sb.Append(Environment.NewLine);
			sb.AppendFormat("{0}: {1}", "Length is", sb.Length);

			DisplayMessage(sb.ToString());
		}

		private void CharsButton_Click(object sender, RoutedEventArgs e)
		{
			CharsSample(Sentence.Text);
		}

		private void CharsSample(string value)
		{
			StringBuilder sb = new StringBuilder(value);

			// Change some individual characters
			sb[0] = Convert.ToChar(",");
			sb[10] = Convert.ToChar(".");

			DisplayMessage(sb.ToString());
		}

		private void InsertButton_Click(object sender, RoutedEventArgs e)
		{
			InsertSample(Sentence.Text);
		}

		private void InsertSample(string value)
		{
			StringBuilder sb = new StringBuilder(value);

			sb.Insert(0, "PREFIXED: ");

			DisplayMessage(sb.ToString());
		}

		private void RemoveButton_Click(object sender, RoutedEventArgs e)
		{
			RemoveSample(Sentence.Text);
		}

		private void RemoveSample(string value)
		{
			StringBuilder sb = new StringBuilder(value);

			sb.Remove(0, 10);
			sb.ToString().ToUpper().Replace("a", "g").Substring(0, 100);

			DisplayMessage(sb.ToString());
		}

		private void ReplaceButton_Click(object sender, RoutedEventArgs e)
		{
			ReplaceSample(Sentence.Text);
		}

		private void ReplaceSample(string value)
		{
			StringBuilder sb = new StringBuilder(value);

			// Change some values
			sb.Replace(".", ".PERIOD.");
			sb.Replace("This ", "Changed ");

			DisplayMessage(sb.ToString());
		}
	}
}
