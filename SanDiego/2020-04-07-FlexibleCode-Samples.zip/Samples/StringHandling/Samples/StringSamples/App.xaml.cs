﻿using System.Windows;

namespace StringSamples
{
  public partial class App : Application
  {
  }
}
