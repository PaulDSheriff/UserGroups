namespace AdventureWorks.MAUI.Views;

public partial class PhoneTypesListView : ContentPage
{
	public PhoneTypesListView()
	{
		InitializeComponent();
	}
}