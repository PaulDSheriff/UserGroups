namespace AdventureWorks.MAUI.ViewsPartial;

public partial class AddressView : ContentView
{
	public AddressView()
	{
		InitializeComponent();
	}
}