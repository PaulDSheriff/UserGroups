﻿HTML 5 Samples
--------------------------------------------
It is important to note that ViewState has been disabled for this entire application

InputTypes.aspx - Shows the use of the new HTML 5 input types with TextBox control
Attributes.aspx - Shows the use of the new HTML 5 attibutes with TextBox control
HTMLInputOnly.aspx - Shows the use of <input> type instead of TextBox control

ClientIdSample.aspx - Shows use of ClientID within jQuery
ClientIdModeSample.aspx - Shows use of page directive ClientIDMode

GridViewSample.aspx - Shows that GridView still works even though ViewState is disabled
  You won't be able to select a specific row or use SelectedIndexChanged event
  However, just add your own button and use CommandArgument to store your PK
  