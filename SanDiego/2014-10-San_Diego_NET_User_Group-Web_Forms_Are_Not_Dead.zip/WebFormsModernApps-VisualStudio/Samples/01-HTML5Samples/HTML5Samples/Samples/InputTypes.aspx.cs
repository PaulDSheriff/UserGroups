﻿using System;

namespace HTML5Samples
{
  public partial class InputTypes : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      System.Diagnostics.Debugger.Break();
    }
  }
}