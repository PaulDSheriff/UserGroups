'use strict';

$(document).ready(function () {
  personListComponent.get();
});

/**
 * Person List Component
 */
var personListComponent = (function () {
  /**
   * Private Variables
   */
  var _dataList = [];

  /**
   * Private Functions
   */
  function _get() {
    _dataList = [
      {
        personId: 1,
        firstName: 'Paul',
        lastName: 'Sheriff',
        emailAddress: 'psheriff@fairwaytech.com',
        phone: '(714) 999-9999'
      },
      {
        personId: 2,
        firstName: 'Bruce',
        lastName: 'Jones',
        emailAddress: 'bjones@fairwaytech.com',
        phone: '(714) 888-8888'
      },
      {
        personId: 3,
        firstName: 'Sheila',
        lastName: 'Cleveland',
        emailAddress: 'sheila@fairwaytech.com',
        phone: '(714) 777-7777'
      },
    ];

    // Create HTML table
    _renderData("#dataTmpl", "#people tbody");
  }

  function _renderData(templateId, insertInto) {
    // Get template from script element
    var template = $(templateId).html();
    // Call Mustache passing in the template and the
    // object with collection of data to display
    var html = Mustache.to_html(template, personListComponent);
    // Insert the rendered HTML into the DOM
    $(insertInto).html(html);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    "get": _get,
    "dataList": function () {
      return _dataList;
    }
  };
})();
