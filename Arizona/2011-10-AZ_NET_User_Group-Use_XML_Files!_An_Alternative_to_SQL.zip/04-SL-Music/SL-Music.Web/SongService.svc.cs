﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SL_Music.Web
{
	public class SongService : ISongService
	{
		public string GetSongXml()
		{
			string ret = string.Empty;
			string sql = string.Empty;
			SqlDataAdapter da;
			DataSet ds = new DataSet();

			sql = "SELECT *";
			sql += " FROM Songs";

			da = new SqlDataAdapter(sql,
				ConfigurationManager.ConnectionStrings["Music"].
					ConnectionString);

			da.Fill(ds);

			// Create Attribute based XML
			foreach (DataColumn item in ds.Tables[0].Columns)
				item.ColumnMapping = MappingType.Attribute;

			ds.DataSetName = "Songs";
			ds.Tables[0].TableName = "Song";
			ret = ds.GetXml();

			return ret;
		}
	}
}
