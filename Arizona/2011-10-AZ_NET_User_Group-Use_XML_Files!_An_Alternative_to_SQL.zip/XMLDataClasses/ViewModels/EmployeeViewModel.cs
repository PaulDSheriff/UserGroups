﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Common.Library;

namespace XMLDataClasses
{
	public class EmployeeViewModel : ViewModelBase
	{
		#region Private Variables
		private Employee _OriginalData = null;
		private EmployeeManager _ManagerObject = null;
		private Employee _DetailData = null;
		private ObservableCollection<Employee> _DataCollection = new ObservableCollection<Employee>();
		#endregion

		#region Public Properties
		public EmployeeManager ManagerObject
		{
			get { return _ManagerObject; }
			set
			{
				_ManagerObject = value;
				RaisePropertyChanged("ManagerObject");
			}
		}

		public Employee DetailData
		{
			get { return _DetailData; }
			set
			{
				_DetailData = value;
				RaisePropertyChanged("DetailData");
			}
		}

		public ObservableCollection<Employee> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region CreateOrGetManagerObject Method
		protected void CreateOrGetManagerObject()
		{
			// Maybe implement some caching here
			if (ManagerObject == null)
				ManagerObject = new EmployeeManager();
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
			// Create or Get Manager Object
			CreateOrGetManagerObject();

			// Hook the PropertyChanged Event from the Manager Object
			// In order to get the DataCollection
			ManagerObject.PropertyChanged += 
				new PropertyChangedEventHandler(ManagerObject_PropertyChanged);

			ManagerObject.LoadAll();
		}

		void ManagerObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "DataCollection")
			{
#if SILVERLIGHT
				foreach (Employee item in ManagerObject.DataCollection)
					DataCollection.Add(item);
#else
				DataCollection = new ObservableCollection<Employee>(ManagerObject.DataCollection);
#endif

				TotalRecords = DataCollection.Count;

				// Check for XML records, could mean the file does not exist
				if (TotalRecords == 0)
				{
					SetUIState(EditUIState.Exception);
					LastExceptionMessage = "No XML Records. This could mean the XML file does not exist in the User's Local Data Storage, or there are just no records in the XML file.";
				}
				else
					SetUIState(EditUIState.Normal);
			}
		}

		#endregion

		#region Save Method
		public void Save()
		{
			if (IsAddMode)
				Insert();
			else
				Update();
		}
		#endregion

		#region Insert Method
		public void Insert()
		{
			if (ManagerObject.Insert(DetailData))
			{
				DataCollection.Add(DetailData);
				SetUIState(EditUIState.Normal);
				TotalRecords = DataCollection.Count;
			}
		}
		#endregion

		#region Update Method
		public void Update()
		{
			if (ManagerObject.Update(DetailData))
			{
				SetUIState(EditUIState.Normal);
			}
		}
		#endregion

		#region Delete Method
		public void Delete()
		{
			if (ManagerObject.Delete(DetailData))
			{
				DataCollection.Remove(DetailData);
				if (DataCollection.Count > 0)
				{
					if (SelectedIndex != DataCollection.Count - 1)
						SelectedIndex--;
					if (SelectedIndex < 0)
						SelectedIndex = 0;

					DetailData = DataCollection[SelectedIndex];
				}
			}

			TotalRecords = DataCollection.Count;
		}
		#endregion

		#region AddData Method
		public void AddData()
		{
			// Create or Get the Manager Object
			CreateOrGetManagerObject();

			DetailData = new Employee();
			DetailData.EmployeeID = ManagerObject.GetNextEmployeeId();
      DetailData.FirstName = string.Empty;
      DetailData.LastName = string.Empty;
      DetailData.SSN = string.Empty;

			IsAddMode = true;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region EditData Method
		public void EditData()
		{
			CloneCurrent();
			IsAddMode = false;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region CancelEdit Method
		public void CancelEdit()
		{
			Undo();
			SetUIState(EditUIState.Normal);
		}
		#endregion

		#region CloneCurrent Method
		public void CloneCurrent()
		{
			if (DetailData != null)
			{
				_OriginalData = new Employee();

				_OriginalData.EmployeeID = DetailData.EmployeeID;
				_OriginalData.FirstName = DetailData.FirstName;
				_OriginalData.LastName = DetailData.LastName;
				_OriginalData.SSN = DetailData.SSN;
			}
		}
		#endregion

		#region Undo Method
		public void Undo()
		{
			if (_OriginalData != null)
			{
				DetailData.EmployeeID = _OriginalData.EmployeeID;
				DetailData.FirstName = _OriginalData.FirstName;
				DetailData.LastName = _OriginalData.LastName;
				DetailData.SSN = _OriginalData.SSN;
			}
		}
		#endregion
	}
}
