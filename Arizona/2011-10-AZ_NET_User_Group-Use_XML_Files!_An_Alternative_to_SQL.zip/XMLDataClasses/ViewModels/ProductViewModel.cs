﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Common.Library;

namespace XMLDataClasses
{
	public class ProductViewModel : ViewModelBase
	{
		#region Private Variables
		private Product _OriginalData = null;
		private ProductManager _ManagerObject = null;
		private Product _DetailData = null;
		private ObservableCollection<Product> _DataCollection = new ObservableCollection<Product>();
		#endregion

		#region Public Properties
		public ProductManager ManagerObject
		{
			get { return _ManagerObject; }
			set
			{
				_ManagerObject = value;
				RaisePropertyChanged("ManagerObject");
			}
		}

		public Product DetailData
		{
			get { return _DetailData; }
			set
			{
				_DetailData = value;
				RaisePropertyChanged("DetailData");
			}
		}

		public ObservableCollection<Product> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region CreateOrGetManagerObject Method
		protected void CreateOrGetManagerObject()
		{
			// Maybe implement some caching here
			if (ManagerObject == null)
				ManagerObject = new ProductManager();
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
			// Create or Get Manager Object
			CreateOrGetManagerObject();

			// Hook the PropertyChanged Event from the Manager Object
			// In order to get the DataCollection
			ManagerObject.PropertyChanged += 
				new PropertyChangedEventHandler(ManagerObject_PropertyChanged);

			ManagerObject.LoadAll();
		}

		void ManagerObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			if (e.PropertyName == "DataCollection")
			{
#if SILVERLIGHT
				foreach (Product item in ManagerObject.DataCollection)
					DataCollection.Add(item);
#else
				DataCollection = new ObservableCollection<Product>(ManagerObject.DataCollection);
#endif

				TotalRecords = DataCollection.Count;

				// Check for XML records, could mean the file does not exist
				if (TotalRecords == 0)
				{
					SetUIState(EditUIState.Exception);
					LastExceptionMessage = "No XML Records. This could mean the XML file does not exist in the User's Local Data Storage, or there are just no records in the XML file.";
				}
				else
					SetUIState(EditUIState.Normal);
			}
		}

		#endregion

		#region Save Method
		public void Save()
		{
			if (IsAddMode)
				Insert();
			else
				Update();
		}
		#endregion

		#region Insert Method
		public void Insert()
		{
			if (ManagerObject.Insert(DetailData))
			{
				DataCollection.Add(DetailData);
				SetUIState(EditUIState.Normal);
				TotalRecords = DataCollection.Count;
			}
		}
		#endregion

		#region Update Method
		public void Update()
		{
			if (ManagerObject.Update(DetailData))
			{
				SetUIState(EditUIState.Normal);
			}
		}
		#endregion

		#region Delete Method
		public void Delete()
		{
			if (ManagerObject.Delete(DetailData))
			{
				DataCollection.Remove(DetailData);
				if (DataCollection.Count > 0)
				{
					if (SelectedIndex != DataCollection.Count - 1)
						SelectedIndex--;
					if (SelectedIndex < 0)
						SelectedIndex = 0;

					DetailData = DataCollection[SelectedIndex];
				}
			}

			TotalRecords = DataCollection.Count;
		}
		#endregion

		#region AddData Method
		public void AddData()
		{
			// Create or Get the Manager Object
			CreateOrGetManagerObject();

			DetailData = new Product();
			DetailData.ProductId = ManagerObject.GetNextProductId();
			DetailData.IntroductionDate = DateTime.Now;

			IsAddMode = true;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region EditData Method
		public void EditData()
		{
			CloneCurrent();
			IsAddMode = false;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region CancelEdit Method
		public void CancelEdit()
		{
			Undo();
			SetUIState(EditUIState.Normal);
		}
		#endregion

		#region CloneCurrent Method
		public void CloneCurrent()
		{
			if (DetailData != null)
			{
				_OriginalData = new Product();

				_OriginalData.ProductId = DetailData.ProductId;
				_OriginalData.ProductName = DetailData.ProductName;
				_OriginalData.IntroductionDate = DetailData.IntroductionDate;
				_OriginalData.Price = DetailData.Price;
			}
		}
		#endregion

		#region Undo Method
		public void Undo()
		{
			if (_OriginalData != null)
			{
				DetailData.ProductId = _OriginalData.ProductId;
				DetailData.ProductName = _OriginalData.ProductName;
				DetailData.IntroductionDate = _OriginalData.IntroductionDate;
				DetailData.Price = _OriginalData.Price;
			}
		}
		#endregion
	}
}
