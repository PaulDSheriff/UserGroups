﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Xml.Linq;
using Common.Library;

using XMLDataClasses.ProductServiceReference;

namespace XMLDataClasses
{
	public class ProductManager : DataXmlBaseClass
	{
		public const string FILE_NAME = "Product.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "Product";

		#region Constructors
		public ProductManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this Constructor to use an XML file in local storage (Isolated, or User App Data Path)
		/// </summary>
		/// <param name="fileName">The XML File Name (no path)</param>
		public ProductManager(string fileName)
		{
			FileName = fileName;
			FolderName = string.Empty;
			FileLocation = XmlFileLocation.LocalStorage;
			TopElementName = TOP_ELEMENT_NAME;
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public ProductManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<Product> _DataCollection = new List<Product>();

		public List<Product> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region GetDataFromService Method
		ProductServiceClient _Client = null;

		protected override void GetDataFromService()
		{
			_Client = new ProductServiceClient();
			
			_Client.GetProductXmlCompleted += new EventHandler<GetProductXmlCompletedEventArgs>(_Client_GetProductXmlCompleted);
			_Client.GetProductXmlAsync();
		}

		void _Client_GetProductXmlCompleted(object sender, GetProductXmlCompletedEventArgs e)
		{
			XmlObject = XElement.Parse(e.Result);

			// Build Collection of Data
			BuildDataCollection();

#if SILVERLIGHT
			_Client.CloseAsync();
#else
			_Client.Close();
#endif
			_Client = null;
		}
		#endregion

		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Save to local storage
				Save();

				// Fill a list of Product objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 orderby elem.Attribute("ProductName").Value
									 select new Product
									 {
										 ProductId = Convert.ToInt32(GetValue(elem.Attribute("ProductId"), default(int))),
										 ProductName = Convert.ToString(GetValue(elem.Attribute("ProductName"), default(string))),
										 IntroductionDate = Convert.ToDateTime(GetValue(elem.Attribute("IntroductionDate"), default(DateTime))),
										 Price = Convert.ToDecimal(GetValue(elem.Attribute("Price"), default(decimal)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion

		#region Insert Method
		public bool Insert(Product entity)
		{
			// Create new Product element
			var newElem = new XElement(TopElementName,
				new XAttribute("ProductId", entity.ProductId),
				new XAttribute("ProductName", entity.ProductName),
				new XAttribute("IntroductionDate", entity.IntroductionDate),
				new XAttribute("Price", entity.Price));

			// Add to element collection
			XmlObject.Add(newElem);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Update Method
		public bool Update(Product entity)
		{
			// Find the product element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute("ProductId").Value == entity.ProductId.ToString()
									 select elem).SingleOrDefault();

			// Update the data
			XElem.Attribute("ProductName").Value = entity.ProductName;
			XElem.Attribute("IntroductionDate").Value = entity.IntroductionDate.ToString();
			XElem.Attribute("Price").Value = entity.Price.ToString();

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Delete Method
		public bool Delete(Product entity)
		{
			// Find the product element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute("ProductId").Value == entity.ProductId.ToString()
									 select elem).SingleOrDefault();
			// Delete the element
			XElem.Remove();

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region GetNextProductId Method
		public int GetNextProductId()
		{
			return GetNextId("ProductId");
		}
		#endregion

		#region GetLastUpdateDate Method
		public override DateTime GetLastUpdateDate()
		{
			// There is NO LastUpdated field in the Product's table
			return DateTime.Now;
		}
		#endregion
	}
}