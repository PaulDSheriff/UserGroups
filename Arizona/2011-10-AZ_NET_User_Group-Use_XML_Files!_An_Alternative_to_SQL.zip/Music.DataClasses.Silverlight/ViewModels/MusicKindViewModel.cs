﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Common.Library;

namespace Music.DataClasses
{
	public class MusicKindViewModel : ViewModelBase
	{
		#region Private Variables
		private MusicKind _OriginalData = null;
		private MusicKindManager _ManagerObject = null;
		private MusicKind _DetailData = null;
		private ObservableCollection<MusicKind> _DataCollection = new ObservableCollection<MusicKind>();
		#endregion

		#region Public Properties
		public MusicKindManager ManagerObject
		{
			get { return _ManagerObject; }
			set
			{
				_ManagerObject = value;
				RaisePropertyChanged("ManagerObject");
			}
		}
		
		public MusicKind DetailData
		{
			get { return _DetailData; }
			set
			{
				_DetailData = value;
				RaisePropertyChanged("DetailData");
			}
		}

		public ObservableCollection<MusicKind> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region CreateOrGetManagerObject Method
		protected MusicKindManager CreateOrGetManagerObject()
		{
			// Maybe implement some caching here
			if (ManagerObject == null)
			{
				ManagerObject = new MusicKindManager();
				ManagerObject.PropertyChanged += new PropertyChangedEventHandler(ManagerObject_PropertyChanged);
			}

			return ManagerObject;
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
			// Create or Get the Manager Object
			CreateOrGetManagerObject();
			// Get all Data
			ManagerObject.LoadAll();
		}

		void ManagerObject_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			// Get All MusicKinds in XML and Put into Observable collection
#if SILVERLIGHT
			// Put List<MusicKind> collection into Observable Collection
			// An ObserverableCollection in Silverlight 
			// does NOT have a constructor that accepts a List<T> like WPF
			foreach (MusicKind item in ManagerObject.DataCollection)
				DataCollection.Add(item);
#else
			DataCollection =
				new ObservableCollection<MusicKind>(ManagerObject.DataCollection);
#endif

			TotalRecords = DataCollection.Count;

			// Check for XML records, could mean the file does not exist
			if (TotalRecords == 0)
			{
				SetUIState(EditUIState.Exception);
				LastExceptionMessage = "No XML Records. This could mean the XML file does not exist in the User's Local Data Storage, or there are just no records in the XML file.";
			}
			else
				SetUIState(EditUIState.Normal);
		}
		#endregion

		#region Save Method
		public void Save()
		{
			if (IsAddMode)
				Insert();
			else
				Update();
		}
		#endregion

		#region Insert Method
		public void Insert()
		{
			if (ManagerObject.Insert(DetailData))
			{
				DataCollection.Add(DetailData);
				SetUIState(EditUIState.Normal);
				TotalRecords = DataCollection.Count;
			}
		}
		#endregion

		#region Update Method
		public void Update()
		{
			if (ManagerObject.Update(DetailData))
			{
				SetUIState(EditUIState.Normal);
			}
		}
		#endregion

		#region Delete Method
		public void Delete()
		{
			if (ManagerObject.Delete(DetailData))
			{
				DataCollection.Remove(DetailData);
				if (DataCollection.Count > 0)
				{
					if (SelectedIndex != DataCollection.Count - 1)
						SelectedIndex--;
					if (SelectedIndex < 0)
						SelectedIndex = 0;

					DetailData = DataCollection[SelectedIndex];
				}
			}

			TotalRecords = DataCollection.Count;
		}
		#endregion

		#region AddData Method
		public void AddData()
		{
			// Create or Get the Manager Object
			CreateOrGetManagerObject();

			DetailData = new MusicKind();
			DetailData.KindId = ManagerObject.GetNextId();
			DetailData.LastUpdated = DateTime.Now;

			IsAddMode = true;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region EditData Method
		public void EditData()
		{
			CloneCurrent();
			IsAddMode = false;
			SetUIState(EditUIState.Edit);
		}
		#endregion

		#region CancelEdit Method
		public void CancelEdit()
		{
			Undo();
			SetUIState(EditUIState.Normal);
		}
		#endregion

		#region CloneCurrent Method
		public void CloneCurrent()
		{
			if (DetailData != null)
			{
				_OriginalData = new MusicKind();

				_OriginalData.KindId = DetailData.KindId;
				_OriginalData.Kind = DetailData.Kind;
			}
		}
		#endregion

		#region Undo Method
		public void Undo()
		{
			if (_OriginalData != null)
			{
				DetailData.KindId = _OriginalData.KindId;
				DetailData.Kind = _OriginalData.Kind;
			
			}
		}
		#endregion
	}
}
