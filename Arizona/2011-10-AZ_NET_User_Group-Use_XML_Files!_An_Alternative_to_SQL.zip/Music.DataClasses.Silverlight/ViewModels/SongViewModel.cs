﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Common.Library;

namespace Music.DataClasses
{
  public class SongViewModel : ViewModelBase
  {
    #region Private Variables
    private Song _OriginalData = null;
    private Song _DetailData = null;
    private SongManager _ManagerObject = null;
    private ObservableCollection<Song> _DataCollection = new ObservableCollection<Song>();

    private MusicGenreManager _GenreManager = new MusicGenreManager();
    private ObservableCollection<MusicGenre> _GenreCollection = new ObservableCollection<MusicGenre>();

    private MusicKindManager _KindManager = new MusicKindManager();
    private ObservableCollection<MusicKind> _KindCollection = new ObservableCollection<MusicKind>();
    #endregion

    #region Public Properties
    public SongManager ManagerObject
    {
      get { return _ManagerObject; }
      set
      {
        _ManagerObject = value;
        RaisePropertyChanged("ManagerObject");
      }
    }

    public ObservableCollection<MusicGenre> GenreCollection
    {
      get { return _GenreCollection; }
      set
      {
        _GenreCollection = value;
        RaisePropertyChanged("GenreCollection");
      }
    }

    public ObservableCollection<MusicKind> KindCollection
    {
      get { return _KindCollection; }
      set
      {
        _KindCollection = value;
        RaisePropertyChanged("KindCollection");
      }
    }

    public Song DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }

    public ObservableCollection<Song> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region CreateOrGetManagerObject Method
    protected SongManager CreateOrGetManagerObject()
    {
      // Maybe implement some caching here
      if (ManagerObject == null)
      {
        ManagerObject = new SongManager();
        ManagerObject.PropertyChanged += new PropertyChangedEventHandler(ManagerObject_PropertyChanged);
      }

      return ManagerObject;
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      // Create or Get the Manager Object
      CreateOrGetManagerObject();
      // Get all Data
      ManagerObject.LoadAll();

      // Load FK Collections
      LoadGenres();
      LoadKinds();
    }

    #region Load FK Collections
    private void LoadGenres()
    {
      _GenreManager.PropertyChanged += new PropertyChangedEventHandler(_GenreManager_PropertyChanged);
      _GenreManager.LoadAllIfNewerData();
    }

    void _GenreManager_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "DataCollection")
        GenreCollection = new ObservableCollection<MusicGenre>(_GenreManager.DataCollection);
    }

    private void LoadKinds()
    {
      _KindManager.PropertyChanged += new PropertyChangedEventHandler(_KindManager_PropertyChanged);
      _KindManager.LoadAllIfNewerData();
    }

    void _KindManager_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (e.PropertyName == "DataCollection")
        KindCollection = new ObservableCollection<MusicKind>(_KindManager.DataCollection);
    }
    #endregion

    void ManagerObject_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
      // Get All Songs in XML and Put into Observable collection
#if SILVERLIGHT
      // Put List<Song> collection into Observable Collection
      // An ObserverableCollection in Silverlight 
      // does NOT have a constructor that accepts a List<T> like WPF
      foreach (Song item in ManagerObject.DataCollection)
        DataCollection.Add(item);
#else
			DataCollection =
				new ObservableCollection<Song>(ManagerObject.DataCollection);
#endif

      TotalRecords = DataCollection.Count;

      // Check for XML records, could mean the file does not exist
      if (TotalRecords == 0)
      {
        SetUIState(EditUIState.Exception);
        LastExceptionMessage = "No XML Records. This could mean the XML file does not exist in the User's Local Data Storage, or there are just no records in the XML file.";
      }
      else
        SetUIState(EditUIState.Normal);
    }
    #endregion

    #region Save Method
    public void Save()
    {
      if (IsAddMode)
        Insert();
      else
        Update();
    }
    #endregion

    #region Insert Method
    public void Insert()
    {
      if (ManagerObject.Insert(DetailData))
      {
        DataCollection.Add(DetailData);
        SetUIState(EditUIState.Normal);
        TotalRecords = DataCollection.Count;
      }
    }
    #endregion

    #region Update Method
    public void Update()
    {
      if (ManagerObject.Update(DetailData))
      {
        SetUIState(EditUIState.Normal);
      }
    }
    #endregion

    #region Delete Method
    public void Delete()
    {
      if (ManagerObject.Delete(DetailData))
      {
        DataCollection.Remove(DetailData);
        if (DataCollection.Count > 0)
        {
          if (SelectedIndex != DataCollection.Count - 1)
            SelectedIndex--;
          if (SelectedIndex < 0)
            SelectedIndex = 0;

          DetailData = DataCollection[SelectedIndex];
        }
      }

      TotalRecords = DataCollection.Count;
    }
    #endregion

    #region AddData Method
    public void AddData()
    {
      // Create or Get the Manager Object
      CreateOrGetManagerObject();

      DetailData = new Song();
      DetailData.SongId = ManagerObject.GetNextId();
      DetailData.DateAdded = DateTime.Now;

      IsAddMode = true;
      SetUIState(EditUIState.Edit);
    }
    #endregion

    #region EditData Method
    public void EditData()
    {
      CloneCurrent();
      IsAddMode = false;
      SetUIState(EditUIState.Edit);
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      Undo();
      SetUIState(EditUIState.Normal);
    }
    #endregion

    #region CloneCurrent Method
    public void CloneCurrent()
    {
      if (DetailData != null)
      {
        _OriginalData = new Song();

        _OriginalData.SongId = DetailData.SongId;
        _OriginalData.SongName = DetailData.SongName;
      }
    }
    #endregion

    #region Undo Method
    public void Undo()
    {
      if (_OriginalData != null)
      {
        DetailData.SongId = _OriginalData.SongId;
        DetailData.SongName = _OriginalData.SongName;

      }
    }
    #endregion
  }
}
