﻿using System;
using Common.Library;

namespace Music.DataClasses
{
	public class MusicKind : CommonBase
	{
		#region Private Variables
		private int _KindId;
		private string _Kind;
		private DateTime _LastUpdated;
		#endregion

		#region Public Properties
		public int KindId
		{
			get { return _KindId; }
			set
			{
				if (_KindId != value)
				{
					_KindId = value;
					RaisePropertyChanged("KindId");
				}
			}
		}

		public string Kind
		{
			get { return _Kind; }
			set
			{
				if (_Kind != value)
				{
					_Kind = value;
					RaisePropertyChanged("Kind");
				}
			}
		}

		public DateTime LastUpdated
		{
			get { return _LastUpdated; }
			set
			{
				if (_LastUpdated != value)
				{
					_LastUpdated = value;
					RaisePropertyChanged("LastUpdated");
				}
			}
		}
		#endregion
	}
}
