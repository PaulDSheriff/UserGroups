﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Xml.Linq;

using Common.Library;
using Music.DataClasses.MusicGenreServiceReference;

namespace Music.DataClasses
{
	public class MusicGenreManager : DataXmlBaseClass
	{
		public const string FILE_NAME = "MusicGenres.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "MusicGenre";

		#region Constructors
		public MusicGenreManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this Constructor to use an XML file in local storage (Isolated, or User App Data Path)
		/// </summary>
		/// <param name="fileName">The XML File Name (no path)</param>
		public MusicGenreManager(string fileName)
		{
			FileName = fileName;
			FolderName = string.Empty;
			FileLocation = XmlFileLocation.LocalStorage;
			TopElementName = TOP_ELEMENT_NAME;
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public MusicGenreManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<MusicGenre> _DataCollection = new List<MusicGenre>();

		public List<MusicGenre> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region GetDataFromService Method
		MusicGenreServiceClient _Client = null;

		protected override void GetDataFromService()
		{
			_Client = new MusicGenreServiceClient();

			_Client.GetMusicGenreXmlCompleted += new EventHandler<GetMusicGenreXmlCompletedEventArgs>(_Client_GetMusicGenreXmlCompleted);
			_Client.GetMusicGenreXmlAsync();	
		}

		void _Client_GetMusicGenreXmlCompleted(object sender, GetMusicGenreXmlCompletedEventArgs e)
		{
			XmlObject = XElement.Parse(e.Result);

			// Build Collection of Data
			BuildDataCollection();

#if SILVERLIGHT
			_Client.CloseAsync();
#else
			_Client.Close();
#endif
			_Client = null;
		}
		#endregion

		#region LoadAllIfNewerData Method
		public override void LoadAllIfNewerData()
		{
			DateTime lastUpdated = Convert.ToDateTime("1753-1-1");  // Minimum date in SQL Server
			int rows = int.MinValue;

			_Client = new MusicGenreServiceClient();
			if (DoesLocalDataExist())
			{
				// Load local data
				LoadAll();
				// Get count and last update date
				lastUpdated = GetLastUpdateDate();
				rows = GetCount();
			}

      // Check to see if we need to retrieve data from server
      // Could add code here to only check once a week, or something
      _Client.GetMusicGenreXmlIfChangedCompleted += new EventHandler<GetMusicGenreXmlIfChangedCompletedEventArgs>(_Client_GetMusicGenreXmlIfChangedCompleted);
			_Client.GetMusicGenreXmlIfChangedAsync(lastUpdated, rows);
		}

		void _Client_GetMusicGenreXmlIfChangedCompleted(object sender, GetMusicGenreXmlIfChangedCompletedEventArgs e)
		{
			// e.Result will be empty if data has NOT changed
			if (e.Result != string.Empty)
			{
				// Data has changed, so parse and save locally
				XmlObject = XElement.Parse(e.Result);

				// Build Collection of Data
				BuildDataCollection();
			}

#if SILVERLIGHT
			_Client.CloseAsync();
#else
			_Client.Close();
#endif
			_Client = null;
		}
		#endregion

		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Save to local storage
				Save();

				// Fill a list of MusicGenre objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 orderby elem.Attribute("Genre").Value
									 select new MusicGenre
									 {
										 GenreId = Convert.ToInt32(GetValue(elem.Attribute("GenreId"), default(int))),
										 Genre = Convert.ToString(GetValue(elem.Attribute("Genre"), default(string))),
										 LastUpdated = Convert.ToDateTime(GetValue(elem.Attribute("LastUpdated"), default(DateTime)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion

		#region Insert Method
		public bool Insert(MusicGenre entity)
		{
			// Create new MusicGenre element
			var newElem = new XElement(TopElementName,
				new XAttribute("GenreId", entity.GenreId),
				new XAttribute("Genre", entity.Genre),
				new XAttribute("LastUpdated", entity.LastUpdated));

			// Add to element collection
			XmlObject.Add(newElem);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Update Method
		public bool Update(MusicGenre entity)
		{
			// Find the MusicGenre element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									where elem.Attribute("GenreId").Value == entity.GenreId.ToString()
									select elem).SingleOrDefault();

			// Update the data
			SetValue(XElem, XElem.Attribute("GenreId"), "GenreId", entity.GenreId);
			SetValue(XElem, XElem.Attribute("Genre"), "Genre", entity.Genre);
			SetValue(XElem, XElem.Attribute("LastUpdated"), "LastUpdated", DateTime.Now);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Delete Method
		public bool Delete(MusicGenre entity)
		{
			// Find the MusicGenre element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute("GenreId").Value == entity.GenreId.ToString()
									select elem).SingleOrDefault();
			// Delete the element
			XElem.Remove();

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region GetNextId Method
		public override int GetNextId()
		{
			return GetNextId("GenreId");
		}
		#endregion

		#region GetLastUpdateDate Method
		public override DateTime GetLastUpdateDate()
		{
			return GetLastUpdateDate("LastUpdated");
		}
		#endregion
	}
}
