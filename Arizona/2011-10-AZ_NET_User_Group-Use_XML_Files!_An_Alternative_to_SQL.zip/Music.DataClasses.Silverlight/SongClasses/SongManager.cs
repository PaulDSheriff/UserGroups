﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Xml.Linq;

using Common.Library;
using Music.DataClasses.SongServiceReference;

namespace Music.DataClasses
{
	public class SongManager : DataXmlBaseClass
	{
		public const string FILE_NAME = "Songs.xml";
		public const string FOLDER_NAME = "Xml";
		public const string TOP_ELEMENT_NAME = "Song";

		#region Constructors
		public SongManager()
		{
			FileName = FILE_NAME;
			FolderName = FOLDER_NAME;
			FileLocation = XmlFileLocation.Project;
			TopElementName = TOP_ELEMENT_NAME;

			// Build the full path and file name to the XML file in the Project
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this Constructor to use an XML file in local storage (Isolated, or User App Data Path)
		/// </summary>
		/// <param name="fileName">The XML File Name (no path)</param>
		public SongManager(string fileName)
		{
			FileName = fileName;
			FolderName = string.Empty;
			FileLocation = XmlFileLocation.LocalStorage;
			TopElementName = TOP_ELEMENT_NAME;
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public SongManager(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			TopElementName = TOP_ELEMENT_NAME;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region DataCollection Property
		private List<Song> _DataCollection = new List<Song>();

		public List<Song> DataCollection
		{
			get { return _DataCollection; }
			set
			{
				_DataCollection = value;
				RaisePropertyChanged("DataCollection");
			}
		}
		#endregion

		#region GetDataFromService Method
		SongServiceClient _Client = null;

		protected override void GetDataFromService()
		{
			_Client = new SongServiceClient();

			_Client.GetSongXmlCompleted += new EventHandler<GetSongXmlCompletedEventArgs>(_Client_GetSongXmlCompleted);
			_Client.GetSongXmlAsync();	
		}

		void _Client_GetSongXmlCompleted(object sender, GetSongXmlCompletedEventArgs e)
		{
			XmlObject = XElement.Parse(e.Result);

			// Build Collection of Data
			BuildDataCollection();

#if SILVERLIGHT
			_Client.CloseAsync();
#else
			_Client.Close();
#endif
			_Client = null;
		}
		#endregion
		
		#region BuildDataCollection Method
		public override void BuildDataCollection()
		{
			if (XmlObject != null)
			{
				// Save to local storage
				Save();

				// Fill a list of Song objects
				var coll = from elem in XmlObject.Descendants(TopElementName)
									 orderby elem.Attribute("SongName").Value
									 select new Song
									 {
										 SongId = Convert.ToInt32(GetValue(elem.Attribute("SongId"), default(int))),
										 SongName = Convert.ToString(GetValue(elem.Attribute("SongName"), default(string))),
										 Artist = Convert.ToString(GetValue(elem.Attribute("Artist"), default(string))),
										 Album = Convert.ToString(GetValue(elem.Attribute("Album"), default(string))),
										 GenreId = Convert.ToInt32(GetValue(elem.Attribute("GenreId"), default(int))),
										 KindId = Convert.ToInt32(GetValue(elem.Attribute("KindId"), default(int))),
										 TrackNumber = Convert.ToString(GetValue(elem.Attribute("TrackNumber"), default(string))),
										 Rating = Convert.ToInt32(GetValue(elem.Attribute("Rating"), default(int))),
										 Year = Convert.ToInt32(GetValue(elem.Attribute("Year"), default(int))),
										 ReleaseDate = Convert.ToDateTime(GetValue(elem.Attribute("ReleaseDate"), default(DateTime))),
										 Size = Convert.ToString(GetValue(elem.Attribute("Size"), default(string))),
										 Plays = Convert.ToInt32(GetValue(elem.Attribute("Plays"), default(int))),
										 DateAdded = Convert.ToDateTime(GetValue(elem.Attribute("DateAdded"), default(DateTime)))
									 };

				// Assign to public property
				DataCollection = coll.ToList();
			}
		}
		#endregion

		#region Insert Method
		public bool Insert(Song entity)
		{
			// Create new Song element
			var newElem = new XElement(TopElementName,
				new XAttribute("SongId", entity.SongId),
				new XAttribute("SongName", entity.SongName),
				new XAttribute("Artist", entity.Artist),
				new XAttribute("Album", entity.Album),
				new XAttribute("GenreId", entity.GenreId),
				new XAttribute("KindId", entity.KindId),
				new XAttribute("TrackNumber", entity.TrackNumber),
				new XAttribute("Rating", entity.Rating),
				new XAttribute("Year", entity.Year),
				new XAttribute("ReleaseDate", entity.ReleaseDate),
				new XAttribute("Size", entity.Size),
				new XAttribute("Plays", entity.Plays),
				new XAttribute("DateAdded", DateTime.Now));

			// Add to element collection
			XmlObject.Add(newElem);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Update Method
		public bool Update(Song entity)
		{
			// Find the Song element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									where elem.Attribute("SongId").Value == entity.SongId.ToString()
									select elem).SingleOrDefault();

			// Update the data
			SetValue(XElem, XElem.Attribute("SongId"), "SongId", entity.SongId);
			SetValue(XElem, XElem.Attribute("SongName"), "SongName", entity.SongName);
			SetValue(XElem, XElem.Attribute("Artist"), "Artist", entity.Artist);
			SetValue(XElem, XElem.Attribute("Album"), "Album", entity.Album);
			SetValue(XElem, XElem.Attribute("GenreId"), "GenreId", entity.GenreId);
			SetValue(XElem, XElem.Attribute("KindId"), "KindId", entity.KindId);
			SetValue(XElem, XElem.Attribute("TrackNumber"), "TrackNumber", entity.TrackNumber);
			SetValue(XElem, XElem.Attribute("Rating"), "Rating", entity.Rating);
			SetValue(XElem, XElem.Attribute("Year"), "Year", entity.Year);
			SetValue(XElem, XElem.Attribute("ReleaseDate"), "ReleaseDate", entity.ReleaseDate);
			SetValue(XElem, XElem.Attribute("Size"), "Size", entity.Size);
			SetValue(XElem, XElem.Attribute("Plays"), "Plays", entity.Plays);
			SetValue(XElem, XElem.Attribute("DateAdded"), "DateAdded", entity.DateAdded);

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region Delete Method
		public bool Delete(Song entity)
		{
			return Delete(entity.SongId, "SongId");
		}
		#endregion

		#region GetNextId Method
		public override int GetNextId()
		{
			return GetNextId("SongId");
		}
		#endregion

		#region GetLastUpdateDate Method
		public override DateTime GetLastUpdateDate()
		{
			return GetLastUpdateDate("LastUpdated");
		}
		#endregion
	}
}