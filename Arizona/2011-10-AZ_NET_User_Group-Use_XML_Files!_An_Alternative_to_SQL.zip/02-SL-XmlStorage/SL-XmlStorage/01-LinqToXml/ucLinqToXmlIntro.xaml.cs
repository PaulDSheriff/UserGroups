﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

using System.Xml.Linq;
using XMLDataClasses;

namespace SL_XmlStorage
{
	public partial class ucLinqToXmlIntro : UserControl
	{
		public ucLinqToXmlIntro()
		{
			InitializeComponent();
		}

		XElement _Elements = null;
		string _FileName;

		private void GetOrCreateXml()
		{
			if (_Elements == null)
			{
				_FileName = "Xml/Product.xml";

				_Elements = XElement.Load(_FileName);
			}
		}

		private void btnReadAll_Click(object sender, RoutedEventArgs e)
		{
			ReadAll();
		}

		private void ReadAll()
		{
			XElement elements;
			string fileName;

			fileName = "Xml/Product.xml";

			elements = XElement.Load(fileName);

			// Create a list of Product objects from XElement object
			var products = from prod in elements.Descendants("Product")
										 orderby prod.Attribute("ProductName").Value
										 select prod;

			// Fill list box with data
			lstData.Visibility = System.Windows.Visibility.Collapsed;
			lstSimple.Visibility = System.Windows.Visibility.Visible;
			lstSimple.Items.Clear();
			foreach (var prod in products)
			{
				lstSimple.Items.Add(prod.Attribute("ProductName").Value);
			}
		}

		private void btnReadOne_Click(object sender, RoutedEventArgs e)
		{
			ReadOne();
		}

		private void ReadOne()
		{
			GetOrCreateXml();

			// Retrieve just a Single value
			// If not found then 'products' variable will be null
			var products = (from prod in _Elements.Descendants("Product")
											orderby prod.Attribute("ProductName").Value
											where prod.Attribute("ProductId").Value == "1"
											select prod).SingleOrDefault();

			if (products != null)
			{
				// Fill list box with data
				lstSimple.Visibility = System.Windows.Visibility.Visible;
				lstData.Visibility = System.Windows.Visibility.Collapsed;
				lstSimple.Items.Clear();

				lstSimple.Items.Add(products.Attribute("ProductName").Value);
			}
		}

		private void btnLoadClass_Click(object sender, RoutedEventArgs e)
		{
			LoadClass();
		}

		private void LoadClass()
		{
			GetOrCreateXml();

			// Create a list of Product objects from XElement object
			var products = from prod in _Elements.Descendants("Product")
										 orderby prod.Attribute("ProductName").Value
										 select new Product
										 {
											 ProductId = Convert.ToInt32(prod.Attribute("ProductId").Value),
											 ProductName = prod.Attribute("ProductName").Value,
											 IntroductionDate = Convert.ToDateTime(prod.Attribute("IntroductionDate").Value),
											 Price = Convert.ToDecimal(prod.Attribute("Price").Value)
										 };

			// Fill list box with data
			lstSimple.Visibility = System.Windows.Visibility.Collapsed;
			lstData.Visibility = System.Windows.Visibility.Visible;
			lstData.DataContext = products;
		}

		private void btnAggregate_Click(object sender, RoutedEventArgs e)
		{
			AggregateSample();
		}

		private void AggregateSample()
		{
			// Get XML from Cache or From Storage
			GetOrCreateXml();

			// Get The last product id
			var MaxID = (from prod in _Elements.Descendants("Product")
									 select Convert.ToInt32(prod.Attribute("ProductId").Value)).Max();

			// Fill list box with data
			lstSimple.Visibility = System.Windows.Visibility.Visible;
			lstData.Visibility = System.Windows.Visibility.Collapsed;
			lstSimple.Items.Clear();
			lstSimple.Items.Add((MaxID + 1).ToString());
		}

		private void btnAdd_Click(object sender, RoutedEventArgs e)
		{
			AddSample();
		}

		private void AddSample()
		{
			// Get XML from Cache or From Storage
			GetOrCreateXml();

			// Get The last product id
			var MaxID = (from prod in _Elements.Descendants("Product")
									 select Convert.ToInt32(prod.Attribute("ProductId").Value)).Max();

			// Create new Product element
			var newElem = new XElement("Product",
				new XAttribute("ProductId", MaxID + 1),
				new XAttribute("ProductName", "A New Product"),
				new XAttribute("IntroductionDate", DateTime.Now.ToShortDateString()),
				new XAttribute("Price", 150));

			// Add to element collection
			_Elements.Add(newElem);

			// Redisplay Products
			var products = from prod in _Elements.Descendants("Product")
										 orderby prod.Attribute("ProductName").Value
										 select prod;

			lstSimple.Items.Clear();
			foreach (var prod in products)
			{
				lstSimple.Items.Add(prod.Attribute("ProductName").Value);
			}
		}

		private void btnEdit_Click(object sender, RoutedEventArgs e)
		{
			EditSample();
		}

		private void EditSample()
		{
			// Get XML from Cache or From Storage
			GetOrCreateXml();

			// Get The last product id
			var MaxID = (from prod in _Elements.Descendants("Product")
									 select Convert.ToInt32(prod.Attribute("ProductId").Value)).Max();

			// Retrieve just a Single value
			// If not found then 'products' variable will be null
			var products = (from prod in _Elements.Descendants("Product")
											orderby prod.Attribute("ProductName").Value
											where prod.Attribute("ProductId").Value == MaxID.ToString()
											select prod).SingleOrDefault();

			if (products != null)
			{
				products.Attribute("ProductName").Value += " - CHANGED";

				// Redisplay Products
				var allproducts = from prod in _Elements.Descendants("Product")
													orderby prod.Attribute("ProductName").Value
													select prod;

				lstSimple.Items.Clear();
				foreach (var prod in allproducts)
				{
					lstSimple.Items.Add(prod.Attribute("ProductName").Value);
				}
			}
		}

		private void btnDelete_Click(object sender, RoutedEventArgs e)
		{
			DeleteSample();
		}

		private void DeleteSample()
		{
			// Get XML from Cache or From Storage
			GetOrCreateXml();

			// Get The last product id
			var MaxID = (from prod in _Elements.Descendants("Product")
									 select Convert.ToInt32(prod.Attribute("ProductId").Value)).Max();

			// Retrieve just a Single value
			// If not found then 'products' variable will be null
			var products = (from prod in _Elements.Descendants("Product")
											orderby prod.Attribute("ProductName").Value
											where prod.Attribute("ProductId").Value == MaxID.ToString()
											select prod).SingleOrDefault();

			if (products != null)
			{
				products.Remove();
				
				// Redisplay Products
				var allproducts = from prod in _Elements.Descendants("Product")
													orderby prod.Attribute("ProductName").Value
													select prod;

				lstSimple.Items.Clear();
				foreach (var prod in allproducts)
				{
					lstSimple.Items.Add(prod.Attribute("ProductName").Value);
				}
			}
		}
	}
}
