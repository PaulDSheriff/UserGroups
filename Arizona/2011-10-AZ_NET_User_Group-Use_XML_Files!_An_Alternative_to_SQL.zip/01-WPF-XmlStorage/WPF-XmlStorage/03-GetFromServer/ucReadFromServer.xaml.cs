﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

using Common.Library;
using XMLDataClasses;
using WPF_XmlStorage.ProductServiceReference;

namespace WPF_XmlStorage
{
	public partial class ucReadFromServer : UserControl
	{
		public ucReadFromServer()
		{
			InitializeComponent();
		}

		ProductManager _Manager = new ProductManager();

		#region Get Xml From Server
		private void btnRead_Click(object sender, RoutedEventArgs e)
		{
			// Set DataContext of User Control to Manager object
			this.DataContext = _Manager;

			// Tell Manager to get data from Server
			_Manager.FileLocation = Common.Library.XmlFileLocation.Server;

			// Load data
			_Manager.LoadAll();

			btnSave.IsEnabled = true;
		}
    #endregion

		#region Save Methods
		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			SaveToUsersLocalFile();
		}

		private void SaveToUsersLocalFile()
		{
			// Send to clipboard so you can open the file after it is written
			Clipboard.SetText(_Manager.FullFileName);

			// Save XML to User's Local Storage Area
			_Manager.Save();
		}
		#endregion
	}
}