﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

using Common.Library;
using XMLDataClasses;

namespace WPF_XmlStorage
{
	public partial class ucReadFromLocal : UserControl
	{
		public ucReadFromLocal()
		{
			InitializeComponent();
		}

		ProductManager _Manager = null;

		private void btnReadProject_Click(object sender, RoutedEventArgs e)
		{
			_Manager = new ProductManager();
			// The above is the same as the following
			//_Manager = new ProductManager(@"Xml", "Product.xml");
			// Which is also the same as...
			//_Manager = new ProductManager(ProductManager.FOLDER_NAME, ProductManager.FILE_NAME);

			// Load DataCollection
			_Manager.LoadAll();

			// Set DataContext of User Control to Manager object
			this.DataContext = _Manager;

			btnSaveToUserStorage.IsEnabled = true;
		}

		private void btnSaveToUserStorage_Click(object sender, RoutedEventArgs e)
		{
			SaveToUsersLocalFile();
		}

		private void SaveToUsersLocalFile()
		{
			// We assume you have already loaded the data from the project
			// And you now want to store into the User's Local Storage
			// Setting FileLocation changes where Product.xml will be stored
			_Manager.FileLocation = XmlFileLocation.LocalStorage;

			// Send to clipboard so you can open the file after it is written
			Clipboard.SetText(_Manager.FullFileName);

			// Save XML file
			_Manager.Save();
		}

		private void btnReadUserStorage_Click(object sender, RoutedEventArgs e)
		{
			_Manager = new ProductManager(ProductManager.FILE_NAME);

			// Set DataContext of User Control to Manager object
			this.DataContext = _Manager;

			// Fill list box with data
			_Manager.LoadAll();
		}

		private void btnDelete_Click(object sender, RoutedEventArgs e)
		{
			_Manager = new ProductManager(ProductManager.FILE_NAME);

			if (File.Exists(_Manager.FullFileName))
				File.Delete(_Manager.FullFileName);

			btnSaveToUserStorage.IsEnabled = false;
		}
	}
}
