﻿using System.Windows;
using System.Windows.Controls;

namespace WPF_XmlStorage
{
  public partial class ucMainMenu : UserControl
  {
    public ucMainMenu()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      // Set DataContext of UserControl to itself
      // This is needed to bind 'Text' property to the TextBlock Text property
      this.DataContext = this;
    }

    #region Text Dependency Property
    public string Text
    {
      get { return (string)GetValue(TextProperty); }
      set { SetValue(TextProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty TextProperty =
        DependencyProperty.Register("Text", typeof(string), typeof(ucMainMenu), null);
    #endregion
  }
}
