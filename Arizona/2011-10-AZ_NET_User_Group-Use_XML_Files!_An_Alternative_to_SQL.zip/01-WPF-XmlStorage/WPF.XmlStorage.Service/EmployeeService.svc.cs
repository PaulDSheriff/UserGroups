﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace WPF.XmlStorage.Service
{
  public class EmployeeService : IEmployeeService
  {
    public string GetEmployeeXml()
    {
      string ret = string.Empty;
      string sql = string.Empty;
      SqlDataAdapter da;
      DataSet ds = new DataSet();

      sql = "SELECT EmployeeID, FirstName, ";
      sql += " LastName, SSN ";
      sql += " FROM Employee";

      da = new SqlDataAdapter(sql,
        ConfigurationManager.ConnectionStrings["Sandbox"].
          ConnectionString);

      da.Fill(ds);

      // Create Attribute based XML
      foreach (DataColumn item in ds.Tables[0].Columns)
        item.ColumnMapping = MappingType.Attribute;

      ds.DataSetName = "Employees";
      ds.Tables[0].TableName = "Employee";
      ret = ds.GetXml();

      return ret;
    }
  }
}
