﻿using System.ServiceModel;

namespace WPF.XmlStorage.Service
{
	[ServiceContract]
	public interface IProductService
	{
		[OperationContract]
		string GetProductXml();
	}
}
