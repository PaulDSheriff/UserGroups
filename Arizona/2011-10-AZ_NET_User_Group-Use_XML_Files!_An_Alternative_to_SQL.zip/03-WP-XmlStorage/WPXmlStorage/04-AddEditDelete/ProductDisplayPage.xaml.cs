﻿using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Phone.Controls;

using Microsoft.Phone.Shell;
using XMLDataClasses;

namespace WPXmlStorage
{
  public partial class ProductDisplayPage : PhoneApplicationPage
  {
		private const string EDIT_PAGE = @"/04-AddEditDelete/ProductUpdatePage.xaml";
    ProductViewModel _ViewModel;

    #region Constructor
    public ProductDisplayPage()
    {
      InitializeComponent();

      // Grab View Model Instance from XAML
      _ViewModel = (ProductViewModel)this.Resources["viewModel"];
    }
    #endregion

    #region Loaded Event Procedure
    private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
    {
      if(_ViewModel.DataCollection.Count == 0)
        _ViewModel.LoadAll();      
    }
    #endregion

    #region Edit Click Event Procedure
    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Get the current Product and put into ViewModel      
      _ViewModel.DetailData = (Product)((Button)sender).DataContext;
      // Set Edit Mode
      _ViewModel.IsAddMode = false;

        // Store ViewModel object in State Bag
      PhoneApplicationService.Current.State["ProductViewModel"] = _ViewModel;

      // Navigate to Edit Page
      NavigationService.Navigate(new Uri(EDIT_PAGE, UriKind.Relative));
    }
    #endregion

    #region Add Click Event Procedure
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Create New Product and put into ViewModel
      _ViewModel.AddData();

      // Store ViewModel object in State Bag
      PhoneApplicationService.Current.State["ProductViewModel"] = _ViewModel;

      // Navigate to Edit Page
			NavigationService.Navigate(new Uri(EDIT_PAGE, UriKind.Relative));
    }
    #endregion

    #region Delete Click Event Procedure
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      // Get the current Product and put into ViewModel
      _ViewModel.DetailData = (Product)((Button)sender).DataContext;
      
      if (MessageBox.Show("Delete this Product?", "Delete", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
        _ViewModel.Delete();
    }
    #endregion
  }
}