﻿using System;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Windows;
using System.Xml.Linq;
using Microsoft.Phone.Controls;

using Common.Library;
using XMLDataClasses;

namespace WPXmlStorage
{
	public partial class LocalFiles : PhoneApplicationPage
	{
		#region Constructor
		public LocalFiles()
		{
			InitializeComponent();
		}
		#endregion

		ProductManager _Manager = null;

		private void btnReadProject_Click(object sender, RoutedEventArgs e)
		{
			_Manager = new ProductManager();
			// The above is the same as the following
			//mgr = new ProductManager(@"Xml", "Product.xml");
			// Which is also the same as...
			//mgr = new ProductManager(ProductManager.FOLDER_NAME, ProductManager.FILE_NAME);

			// Get all Products
			_Manager.LoadAll();

			// Set DataContext of User Control to Manager object
			this.DataContext = _Manager;

			btnSaveToUserStorage.IsEnabled = true;
		}

		private void btnSaveToUserStorage_Click(object sender, RoutedEventArgs e)
		{
			SaveToUsersLocalFile();
		}

		private void SaveToUsersLocalFile()
		{
			// We assume you have already loaded the data from the project
			// And you now want to store into the User's Local Storage
			// Setting FileLocation changes where Product.xml will be stored
			_Manager.FileLocation = XmlFileLocation.LocalStorage;

			// Save XML file
			_Manager.Save();
		}

		private void btnReadFromIS_Click(object sender, RoutedEventArgs e)
		{
			_Manager = new ProductManager(ProductManager.FILE_NAME);

			// Get all Products
			_Manager.LoadAll();

			// Set DataContext of User Control to Manager object
			this.DataContext = _Manager;
		}

		private void btnDelete_Click(object sender, RoutedEventArgs e)
		{
			_Manager = new ProductManager(ProductManager.FILE_NAME);

			IsolatedStorageSettings.ApplicationSettings.Remove(_Manager.FullFileName);
			btnSaveToUserStorage.IsEnabled = false;
		}
	}
}