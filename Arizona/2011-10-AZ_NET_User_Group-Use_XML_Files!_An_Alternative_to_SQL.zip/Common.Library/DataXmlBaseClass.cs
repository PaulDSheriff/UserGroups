﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Xml.Linq;

namespace Common.Library
{
	public enum XmlFileLocation
	{
		Unknown,
		Project,
		LocalStorage,
		Server
	}

	public class DataXmlBaseClass : CommonBase
	{
		#region Constructors
		public DataXmlBaseClass()
		{
			FileName = string.Empty;
			TopElementName = string.Empty;
			FullFileName = string.Empty;
			FileLocation = XmlFileLocation.Unknown;
		}

		/// <summary>
		/// Call this Constructor to use and XML file in local storage (Isolated, or User App Data Path)
		/// </summary>
		/// <param name="fileName">The XML File Name (no path)</param>
		public DataXmlBaseClass(string fileName)
		{
			FileName = fileName;
			FileLocation = XmlFileLocation.LocalStorage;
			BuildXmlFullFileName();
		}

		/// <summary>
		/// Call this constructor to use an XML file in your Project (.exe) folder
		/// </summary>
		/// <param name="folderName">Optional folder name</param>
		/// <param name="fileName">The XML File Name (no path)</param>
		public DataXmlBaseClass(string folderName, string fileName)
		{
			FileName = fileName;
			FolderName = folderName;
			FileLocation = XmlFileLocation.Project;
			BuildXmlFullFileName();
		}
		#endregion

		#region Private Properties
		private XmlFileLocation _FileLocation = XmlFileLocation.Unknown;
		#endregion

		#region Public Properties
		public string FileName { get; set; }
		public string FolderName { get; set; }
		public string TopElementName { get; set; }
		public string FullFileName { get; set; }

		public XmlFileLocation FileLocation
		{
			get { return _FileLocation; }
			set
			{
				_FileLocation = value;
				BuildXmlFullFileName();
			}
		}
		#endregion

		#region XmlObject Property (XElement object)
		private XElement _XmlObject = null;

		public XElement XmlObject
		{
			get { return _XmlObject; }
			set
			{
				_XmlObject = value;
				RaisePropertyChanged("XmlObject");
			}
		}
		#endregion

		#region BuildXmlFullFileName Method
		public virtual void BuildXmlFullFileName()
		{
			switch (FileLocation)
			{
				case XmlFileLocation.Project:
#if SILVERLIGHT
					// Use Local XML File in Project
					FullFileName = FolderName + @"/" + FileName;
#else
					// Use Local XML File in Project
    			FullFileName = FileCommon.GetCurrentDirectory() + @"\" +
		          					 FolderName + @"\" + FileName;
#endif
					break;
				case XmlFileLocation.LocalStorage:
#if SILVERLIGHT
					// Use Isolated Storage
					FullFileName = FileName;
#else
					// Use User' Local Storage Area
    			FullFileName = FileCommon.GetUserAppDataPath() + @"\" + FileName;
#endif
					break;
			}
		}
		#endregion

		#region Delete Method
		public virtual bool Delete(int id, string keyName)
		{
			// Find the Song element
			var XElem = (from elem in XmlObject.Descendants(TopElementName)
									 where elem.Attribute(keyName).Value == id.ToString()
									 select elem).SingleOrDefault();
			// Delete the element
			XElem.Remove();

			// Save the file
			Save(XmlObject);

			return true;
		}
		#endregion

		#region DeleteLocalStorage Method
		public virtual void DeleteLocalStorage()
		{
#if SILVERLIGHT
			IsolatedStorageSettings.ApplicationSettings.Remove(FileName);
#else
			File.Delete(FullFileName);
#endif
		}
		#endregion

		#region Save Methods
		public void Save(XElement xmlToWrite)
		{
			if (xmlToWrite != null)
			{
#if SILVERLIGHT
        // First delete old data
        IsolatedStorageSettings.ApplicationSettings.Remove(FileName);
        // Now save new data
				IsolatedStorageSettings.ApplicationSettings[FileName] = xmlToWrite.ToString();
#else
				// Make sure the directory exists
				if (!Directory.Exists(Path.GetDirectoryName(FullFileName)))
					Directory.CreateDirectory(Path.GetDirectoryName(FullFileName));

				File.WriteAllText(FullFileName, xmlToWrite.ToString());
#endif
			}
		}

		public void Save()
		{
			Save(XmlObject);
		}
		#endregion

		#region DoesLocalDataExist Method
		public virtual bool DoesLocalDataExist()
		{
			bool ret = false;

#if SILVERLIGHT
			// Always get from Isolated Storage if exists
			ret = IsolatedStorageSettings.ApplicationSettings.Contains(FileName);
			if (!ret)
			{
				try
				{
					// Get from Project if Isolated Storage is not there
					XmlObject = XElement.Load(FullFileName);					
					ret = true;
			  }
				catch
				{
					// Ignore exception and get data from server
				}
			}
#else
			// Get from User's Data Storage if exists
			ret = File.Exists(FullFileName);
#endif

			return ret;
		}
		#endregion

		#region LoadAll Method
		public void LoadAll()
		{
#if SILVERLIGHT
			// Always get from Isolated Storage if exists
      if (IsolatedStorageSettings.ApplicationSettings.Contains(FileName))
      {
        XmlObject = XElement.Parse(IsolatedStorageSettings.ApplicationSettings[FileName].ToString());
        BuildDataCollection();
      }
      else
      {
        if (FileLocation == XmlFileLocation.Project)
        {
          try
          {
            XmlObject = XElement.Load(FullFileName);
            BuildDataCollection();
          }
          catch
          {
            // Ignore exception and get data from server
          }
        }
      }
#else
			if (File.Exists(FullFileName))
			{
				XmlObject = XElement.Load(FullFileName);
			  BuildDataCollection();
			}
#endif

			// If data is not available locally
			// Get Data from WCF Service
			if (XmlObject == null)
				GetDataFromService();
		}
		#endregion

		#region LoadAllIfNewerData
		public virtual void LoadAllIfNewerData()
		{
		}
		#endregion

		#region GetDataFromService Method
		protected virtual void GetDataFromService()
		{
		}
		#endregion

		#region BuildDataCollection Method
		public virtual void BuildDataCollection()
		{
		}
		#endregion

		#region SetValue Method
		public void SetValue(XElement elem, XAttribute attr, string key, object value)
		{
			if (attr != null)
				attr.Value = value.ToString();
			else
				elem.SetAttributeValue(key, value);
		}
		#endregion

		#region GetValue Method
		public object GetValue(XAttribute attr, object defaultValue)
		{
			if (attr == null)
				return defaultValue;
			else
				if (string.IsNullOrEmpty(attr.Value))
					return defaultValue;
				else
					return attr.Value;
		}
		#endregion

		#region GetNextId Method
		public virtual int GetNextId()
		{
			return default(int);
		}

		public virtual int GetNextId(string keyName)
		{
			// Get The last id
			var MaxID = (from elem in XmlObject.Descendants(TopElementName)
									 select Convert.ToInt32(elem.Attribute(keyName).Value)).Max();

			return MaxID + 1;
		}
		#endregion

		#region GetLastUpdateDate Method
		public virtual DateTime GetLastUpdateDate()
		{
			return default(DateTime);
		}

		public virtual DateTime GetLastUpdateDate(string keyName)
		{
			// Get The last Date Updated
			var MaxDate = (from elem in XmlObject.Descendants(TopElementName)
										 select Convert.ToDateTime(elem.Attribute(keyName).Value)).Max();

			return Convert.ToDateTime(MaxDate);
		}
		#endregion

		#region GetCount Method
		public virtual int GetCount()
		{
			// Get The last Date Updated
			var count = (from elem in XmlObject.Descendants(TopElementName)
									 select elem).Count();

			return Convert.ToInt32(count);
		}
		#endregion
	}
}