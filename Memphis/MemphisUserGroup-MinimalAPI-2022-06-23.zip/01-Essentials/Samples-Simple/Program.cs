using AdvWorksAPI;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
  app.UseSwagger();
  app.UseSwaggerUI();
}

app.MapGet("/hello", () => Results.Ok("Hello Everyone"));

app.MapGet("/person", (string name) => Results.Ok($"Hello {name}"));

app.MapGet("/people/{id:int}", (int id) =>
{
  return Results.Ok(new Person
  {
    PersonId = id,
    FirstName = "John",
    LastName = "Smith"
  });
});

app.MapGet("/people", () =>
{
  return Results.Ok(
    new List<Person>
      {
        new Person
        {
          PersonId = 1,
          FirstName = "John",
          LastName = "Smith"
        },
        new Person{
          PersonId = 2,
          FirstName = "Sally",
          LastName = "Jones"
        }
      });
});

app.Run();
