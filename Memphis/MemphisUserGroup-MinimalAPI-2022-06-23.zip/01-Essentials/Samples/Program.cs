using AdvWorksAPI;

var builder = WebApplication.CreateBuilder(args);

// Add Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// Add Services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Build the Web Application
var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment()) {
  app.UseSwagger();
  app.UseSwaggerUI();
}

//*************************************
// Add Web API's
//*************************************

//*************************************
// GET a collection of data
//*************************************
app.MapGet("/product", () =>
{
  return Results.Ok(new List<Product>
      {
        new Product {
           ProductID = 706,
           Name = "HL Road Frame - Red, 58",
           Color = "Red",
           ListPrice = 1500.0000m
        },
        new Product {
           ProductID = 707,
           Name = "Sport-100 Helmet, Red",
           Color = "Red",
           ListPrice = 34.9900m
        },
        new Product {
           ProductID = 708,
           Name = "Sport-100 Helmet, Black",
           Color = "Black",
           ListPrice = 34.9900m
        },
        new Product {
           ProductID = 709,
           Name = "Mountain Bike Socks, M",
           Color = "White",
           ListPrice = 9.5000m
        },
        new Product {
           ProductID = 710,
           Name = "Mountain Bike Socks, L",
           Color = "White",
           ListPrice = 9.5000m
        }
      });
});

//*************************************
// GET a single row of data
//*************************************
app.MapGet("/product/{id:int}", (int id) =>
{
  // Simulate returning data from the data store with the specified ID
  return Results.Ok(new Product {
    ProductID = id,
    Name = "HL Road Frame - Red, 58",
    Color = "Red",
    ListPrice = 1500.0000m
  });
});

//*************************************
// INSERT new data
//*************************************
app.MapPost("/product", (Product prod, ILogger<Product> logger) =>
{
  // TODO: Insert into data store
  // The 'id' field is updated by the data store
  prod.ProductID = 9999;

  // Write a log entry
  logger.LogInformation("Inserted a new product");

  // Simulate returning the new object created in the data store
  return Results.Created($"/product/{prod.ProductID}", prod);
});

//*************************************
// UPDATE existing data
//*************************************
app.MapPut("/product/{id:int}", (int id, Product entity) =>
{
  IResult ret;

  // Simulate looking up the data by the specified id
  Product current = new() {
    ProductID = id,
    Name = "HL Road Frame - Red, 58",
    Color = "Red",
    ListPrice = 1500.0000m
  };

  if (current != null) {
    // Update the entity with new data
    current.Name = entity.Name;
    current.Color = entity.Color;
    current.ListPrice = entity.ListPrice;

    // TODO: Update data store

    // Return the updated entity
    ret = Results.Ok(current);
  }
  else {
    ret = Results.NotFound();
  }

  return ret;
});

//*************************************
// DELETE a single row
//*************************************
app.MapDelete("/product/{id:int}", (int id) =>
{
  IResult ret;

  // Simulate looking up the data by the specified id
  Product entity = new() { ProductID = id };
  if (entity != null) {
    // TODO: Delete data from the data store here

    // Return NoContent
    ret = Results.NoContent();
  }
  else {
    ret = Results.NotFound();
  }

  return ret;
});

app.Run();