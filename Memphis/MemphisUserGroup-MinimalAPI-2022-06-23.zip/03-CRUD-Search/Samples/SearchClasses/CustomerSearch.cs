#nullable disable

using System.Reflection;

namespace AdvWorksAPI;

public class CustomerSearch {
  public string CompanyName { get; set; }
  public string LastName { get; set; }

  /// <summary>
  /// The following allows us to bind the CustomerSearch on the query line
  /// </summary>
  /// <param name="httpContext"></param>
  /// <param name="parameter"></param>
  /// <returns></returns>
  public static ValueTask<CustomerSearch> BindAsync(HttpContext httpContext, ParameterInfo parameter)
  {     
    return ValueTask.FromResult<CustomerSearch>(
        new CustomerSearch
        {
          CompanyName = httpContext.Request.Query["companyname"],
          LastName = httpContext.Request.Query["lastname"]
        }
      );
  }
}
