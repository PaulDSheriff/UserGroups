#nullable disable

using System.Reflection;

namespace AdvWorksAPI;

public class ProductSearch
{
  public string Name { get; set; }
  public decimal ListPrice { get; set; }

  /// <summary>
  /// The following allows us to bind the ProductSearch on the query line
  /// </summary>
  /// <param name="httpContext"></param>
  /// <param name="parameter"></param>
  /// <returns></returns>
  public static ValueTask<ProductSearch> BindAsync(HttpContext httpContext, ParameterInfo parameter)
  {
    decimal.TryParse(httpContext.Request.Query["listPrice"], out var listPrice);

    return ValueTask.FromResult<ProductSearch>(
        new ProductSearch
        {
          Name = httpContext.Request.Query["name"],
          ListPrice = listPrice
        }
      );
  }
}
