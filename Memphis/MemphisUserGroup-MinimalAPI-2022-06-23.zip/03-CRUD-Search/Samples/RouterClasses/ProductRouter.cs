﻿using Microsoft.AspNetCore.Mvc;

namespace AdvWorksAPI;

public class ProductRouter : RouterBase {

  public ProductRouter(ILogger<ProductRouter> logger, IRepository<Product> repo) {
    UrlFragment = "product";
    Logger = logger;
    _Repo = repo;
  }

  private readonly IRepository<Product> _Repo;

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app) {
    //****************
    // CRUD APIs
    //****************
    app.MapGet($"/{UrlFragment}", () => Get());
    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id));
    app.MapPost($"/{UrlFragment}", (Product entity) => Post(entity));
    app.MapPut($"/{UrlFragment}/{{id:int}}", (int id, Product entity) => Put(id, entity));
    app.MapDelete($"/{UrlFragment}/{{id:int}}", (int id) => Delete(id));

    //***************
    // Searching APIs
    //***************
    // Maps to http://localhost:5278/product/ProductsByCategoryId/27
    app.MapGet($"/{UrlFragment}/ProductsByCategoryId/{{categoryId:int}}", (int categoryId) => ProductsByCategoryId(categoryId));

    // The next two map to http://localhost:5278/product/ProductsByCategoryId?categoryId=27
    //app.MapGet($"/{UrlFragment}/ProductsByCategoryId", ([FromQuery(Name = "categoryId")] int categoryId) => ProductsByCategoryId(categoryId));
    app.MapGet($"/{UrlFragment}/ProductsByCategoryId", (int categoryId) => ProductsByCategoryId(categoryId));


    // Maps to http://localhost:5278/product/ProductsSearch?name=a&listprice=3500
    // This relies on the BindAsync() method on the ProductSearch method
    app.MapGet($"/{UrlFragment}/ProductsSearch", (ProductSearch search) => ProductsSearch(search));
  }

  /// <summary>
  /// GET a collection of data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Get() {
    IResult ret;
    List<Product> list;

    try {
      // Get all data
      list = _Repo.Get().OrderBy(p => p.Name).ToList();
      if (list.Count > 0) {
        // Found data, return '200 OK'
        ret = Results.Ok(list);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound("No products exist in the system.");
      }
    }
    catch (Exception ex) {
      // Return a '500 Internal Server Error'
      ret = HandleException(ex, "Error retrieving all products");
    }

    return ret;
  }

  /// <summary>
  /// GET a single row of data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Get(int id) {
    IResult ret;
    Product entity;

    try {
      entity = _Repo.Get(id);
      if (entity != null) {
        // Return '200 OK'
        ret = Results.Ok(entity);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"Can't find product with a productID of '{id}'.");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Error retrieving product with a productID of '{id}'");
    }

    return ret;
  }

  /// <summary>
  /// INSERT new data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Post(Product entity) {
    IResult ret;

    try {
      // Serialize entity
      SerializeEntity<Product>(entity);

      if (entity != null) {
        // Attempt to insert row into the database
        entity = _Repo.Insert(entity);

        // Return '201 Created'
        ret = Results.Created($"/{UrlFragment}/{entity.ProductID}", entity);
      }
      else {
        // Return '400 Bad Request'
        ret = BadRequest($"Invalid product object passed to POST method: {EntityAsJson}");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Exception trying to insert a new product: {EntityAsJson}");
    }

    return ret;
  }

  /// <summary>
  /// UPDATE existing data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Put(int id, Product entity) {
    IResult ret;

    try {
      // Serialize entity
      SerializeEntity<Product>(entity);

      if (entity != null) {
        // Attempt to update data in data store
        entity = _Repo.Update(entity);

        if (entity != null) {
          // Return '200 Ok'
          ret = Results.Ok(entity);
        }
        else {
          // Return '404 Not Found'
          ret = NotFound($"Can't find ProductID: '{id}' to update.");
        }
      }
      else {
        // Return '400 Bad Request'
        ret = BadRequest($"Invalid product object passed to PUT method: {EntityAsJson}");
      }
    }
    catch (Exception ex) {
      // Return a '500 Internal Server Error'
      ret = HandleException(ex, $"Exception trying to update Product: {EntityAsJson}");
    }

    return ret;
  }

  /// <summary>
  /// DELETE a single row
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Delete(int id) {
    IResult ret;

    try {
      // Attempt to delete data in data store        
      if (_Repo.Delete(id)) {
        // Return '204 No Content'
        ret = Results.NoContent();
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"Can't find ProductID: '{id}' to delete.");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Exception trying to delete ProductID: '{id}'.");
    }

    return ret;
  }

  /// <summary>
  /// Search for products by category
  /// </summary>
  /// <param name="categoryId">The CategoryId value to locate</param>
  /// <returns>An IResult object</returns>
  protected virtual IResult ProductsByCategoryId(int categoryId) {
    IResult ret;
    List<Product> list;

    try {
      // Attempt to locate data
      list = ((ProductRepository)_Repo).GetByCategoryId(categoryId);
      if (list.Count > 0) {
        // Return '200 OK'
        ret = Results.Ok(list);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"No products with categoryId of '{categoryId}' exist in the system.");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Error retrieving products with categoryId of '{categoryId}'");
    }

    return ret;
  }

  /// <summary>
  /// Search for products using the properties in a ProductSearch object
  /// </summary>
  /// <param name="search">A ProductSearch object</param>
  /// <returns>An IResult object</returns>
  protected virtual IResult ProductsSearch(ProductSearch search) {
    IResult ret;
    List<Product> list;

    try {
      // Serialize entity
      SerializeEntity<ProductSearch>(search);

      // Attempt to locate data
      list = ((ProductRepository)_Repo).Search(search);
      if (list.Count > 0) {
        // Return '200 OK'
        ret = Results.Ok(list);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"Can't find products matching the criteria: {EntityAsJson}");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Error searching for products with criteria: {EntityAsJson}");
    }

    return ret;
  }
}
