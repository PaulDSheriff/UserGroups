﻿namespace AdvWorksAPI;

public class CustomerRouter : RouterBase {
  public CustomerRouter(ILogger<CustomerRouter> logger, IRepository<Customer> repo) {
    UrlFragment = "customer";
    Logger = logger;
    _Repo = repo;
  }

  private readonly IRepository<Customer> _Repo;

  /// <summary>
  /// Add routes
  /// </summary>
  /// <param name="app">A WebApplication object</param>
  public override void AddRoutes(WebApplication app) {
    //****************
    // CRUD APIs
    //****************
    app.MapGet($"/{UrlFragment}", () => Get());
    app.MapGet($"/{UrlFragment}/{{id:int}}", (int id) => Get(id));
    app.MapPost($"/{UrlFragment}", (Customer entity) => Post(entity));
    app.MapPut($"/{UrlFragment}/{{id:int}}", (int id, Customer entity) => Put(id, entity));
    app.MapDelete($"/{UrlFragment}/{{id:int}}", (int id) => Delete(id));

    //***************
    // Searching APIs
    //***************
    // Maps to http://localhost:5278/Customer/CustomersSearch?companyname=a&lastname=a
    // This relies on the BindAsync() method on the CustomerSearch method
    app.MapGet($"/{UrlFragment}/CustomersSearch", (CustomerSearch search) => CustomersSearch(search));
  }

  /// <summary>
  /// GET a collection of data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Get() {
    IResult ret;
    List<Customer> list;

    try {
      // Get all data
      list = _Repo.Get().OrderBy(c => c.CompanyName).ToList();
      if (list.Count > 0) {
        // Return '200 OK'
        ret = Results.Ok(list);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound("No customers exist in the system.");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, "Error retrieving all customers");
    }

    return ret;
  }

  /// <summary>
  /// GET a single row of data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Get(int id) {
    IResult ret;
    Customer entity;

    try {
      entity = _Repo.Get(id);
      if (entity != null) {
        // Return '200 OK'
        ret = Results.Ok(entity);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"Can't find customer with a CustomerID of '{id}'.");
      }
    }
    catch (Exception ex) {
      // Return a '500 Internal Server Error'
      ret = HandleException(ex, $"Error retrieving customer with a CustomerID of '{id}'");
    }

    return ret;
  }

  /// <summary>
  /// INSERT new data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Post(Customer entity) {
    IResult ret;

    try {
      // Serialize entity
      SerializeEntity<Customer>(entity);

      if (entity != null) {
        // Attempt to insert row into the database
        entity = _Repo.Insert(entity);

        // Return '201 Created'
        ret = Results.Created($"/{UrlFragment}/{entity.CustomerID}", entity);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"Invalid customer object passed to POST method: {EntityAsJson}");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Exception trying to insert a new customer: {EntityAsJson}");
    }

    return ret;
  }

  /// <summary>
  /// UPDATE existing data
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Put(int id, Customer entity) {
    IResult ret;

    try {
      // Serialize entity
      SerializeEntity<Customer>(entity);

      if (entity != null) {
        // Attempt to update data in data store
        entity = _Repo.Update(entity);

        if (entity != null) {
          // Return '200 Ok'
          ret = Results.Ok(entity);
        }
        else {
          // Return '404 Not Found'
          ret = NotFound($"Can't find CustomerID: '{id}' to update.");
        }
      }
      else {
        // Return '400 Bad Request'
        ret = BadRequest($"Invalid customer object passed to PUT method: {EntityAsJson}");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Exception trying to update customer: {EntityAsJson}");
    }

    return ret;
  }

  /// <summary>
  /// DELETE a single row
  /// </summary>
  /// <returns>An IResult object</returns>
  protected virtual IResult Delete(int id) {
    IResult ret;

    try {
      // Attempt to delete data in data store        
      if (_Repo.Delete(id)) {
        // Return '204 No Content'
        ret = Results.NoContent();
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"Can't find CustomerID: '{id}' to delete.");
      }
    }
    catch (Exception ex) {
      // Return a '500 Internal Server Error'
      ret = HandleException(ex, $"Exception trying to delete CustomerID: '{id}'.");
    }

    return ret;
  }

  /// <summary>
  /// Search for customers using the properties in a CustomerSearch object
  /// </summary>
  /// <param name="search">A CustomerSearch object</param>
  /// <returns>An IResult object</returns>
  protected virtual IResult CustomersSearch(CustomerSearch search) {
    IResult ret;
    List<Customer> list;

    try {
      // Serialize entity
      SerializeEntity<CustomerSearch>(search);

      // Attempt to locate data
      list = ((CustomerRepository)_Repo).Search(search);
      if (list.Count > 0) {
        // Return '200 OK'
        ret = Results.Ok(list);
      }
      else {
        // Return '404 Not Found'
        ret = NotFound($"Can't find customers matching the criteria: {EntityAsJson}");
      }
    }
    catch (Exception ex) {
      // Return '500 Internal Server Error'
      ret = HandleException(ex, $"Error searching for Customers with criteria: {EntityAsJson}");
    }

    return ret;
  }
}
