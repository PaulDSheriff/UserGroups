using AdvWorksAPI;
using Microsoft.EntityFrameworkCore;

// Create the WebApplicationBuilder object
var builder = WebApplication.CreateBuilder(args);

// Add Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// Setup the DbContext object
// Read in the connection string from the appSettings.json file
builder.Services.AddDbContext<AdvWorksLTDbContext>(
  options =>
  options.UseSqlServer(
    builder.Configuration
     .GetConnectionString("DefaultConnection")));

// Add your "Router" classes as services
builder.Services.AddScoped<RouterBase, ProductRouter>();
builder.Services.AddScoped<RouterBase, CustomerRouter>();

// Add your "Repository" classes as services
builder.Services.AddScoped<IRepository<Product>, ProductRepository>();
builder.Services.AddScoped<IRepository<Customer>, CustomerRepository>();

// Add Services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Build the Web Application
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
  app.UseSwagger();
  app.UseSwaggerUI();
}

//*********************************************
// Add Routes from all "Router Classes"
//*********************************************
using (var scope = app.Services.CreateScope()) {
  // Build collection of all RouterBase classes
  var services = scope.ServiceProvider.GetServices<RouterBase>();
  // Loop through each RouterBase class
  foreach (var item in services) {
    // Invoke the AddRoutes() method to add the routes
    item.AddRoutes(app);
  }

  // Make sure this is called within the application scope
  app.Run();
}
