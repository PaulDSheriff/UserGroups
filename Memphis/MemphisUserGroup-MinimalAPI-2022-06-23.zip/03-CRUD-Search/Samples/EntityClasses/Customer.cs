#nullable disable

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdvWorksAPI;

/// <summary>
/// This class contains properties that map to each field in the Customer table.
/// </summary>
[Table("Customer", Schema = "SalesLT")]
public partial class Customer {
  [Key]
  [Display(Name = "Customer ID")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  public int CustomerID { get; set; }

  [Display(Name = "Name Style")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  public bool NameStyle { get; set; }

  [Display(Name = "Title")]
  [StringLength(8, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string Title { get; set; }

  [Display(Name = "First Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string FirstName { get; set; }

  [Display(Name = "Middle Name")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string MiddleName { get; set; }

  [Display(Name = "Last Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string LastName { get; set; }

  [Display(Name = "Suffix")]
  [StringLength(10, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string Suffix { get; set; }

  [Display(Name = "Company Name")]
  [StringLength(128, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string CompanyName { get; set; }

  [Display(Name = "Sales Person")]
  [StringLength(256, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string SalesPerson { get; set; }

  [Display(Name = "Email Address")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [EmailAddress()]
  public string EmailAddress { get; set; }

  [Display(Name = "Phone")]
  [StringLength(25, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [Phone()]
  public string Phone { get; set; }

  [Display(Name = "Password Hash")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(128, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string PasswordHash { get; set; }

  [Display(Name = "Password Salt")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(10, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string PasswordSalt { get; set; }

  [Display(Name = "rowguid")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  public Guid rowguid { get; set; }

  [Display(Name = "Modified Date")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "{0} must be between {1} and {2}")]
  [DisplayFormat(DataFormatString = "{0:d}")]
  public DateTime ModifiedDate { get; set; }
}
