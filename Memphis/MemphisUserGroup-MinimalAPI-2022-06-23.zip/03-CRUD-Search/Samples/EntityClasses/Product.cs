#nullable disable

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdvWorksAPI;

/// <summary>
/// This class contains properties that map to each field in the Product table.
/// </summary>
[Table("Product", Schema = "SalesLT")]
public partial class Product {
  [Key]
  [Display(Name = "Product ID")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  public int ProductID { get; set; }

  [Display(Name = "Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string Name { get; set; }

  [Display(Name = "Product Number")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(25, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string ProductNumber { get; set; }

  [Display(Name = "Color")]
  [StringLength(15, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string Color { get; set; }

  [Display(Name = "Standard Cost")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [DataType(DataType.Currency)]
  [Column(TypeName = "decimal(18, 2)")]
  public decimal StandardCost { get; set; }

  [Display(Name = "List Price")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [DataType(DataType.Currency)]
  [Column(TypeName = "decimal(18, 2)")]
  public decimal ListPrice { get; set; }

  [Display(Name = "Size")]
  [StringLength(5, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string Size { get; set; }

  [Display(Name = "Weight")]
  [Column(TypeName = "decimal(8, 2)")]
  public decimal? Weight { get; set; }

  [Display(Name = "Product Category ID")]
  public int? ProductCategoryID { get; set; }

  [Display(Name = "Product Model ID")]
  public int? ProductModelID { get; set; }

  [Display(Name = "Sell Start Date")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "{0} must be between {1} and {2}")]
  [DisplayFormat(DataFormatString = "{0:d}")]
  public DateTime SellStartDate { get; set; }

  [Display(Name = "Sell End Date")]
  [Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "{0} must be between {1} and {2}")]
  [DisplayFormat(DataFormatString = "{0:d}")]
  public DateTime? SellEndDate { get; set; }

  [Display(Name = "Discontinued Date")]
  [Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "{0} must be between {1} and {2}")]
  [DisplayFormat(DataFormatString = "{0:d}")]
  public DateTime? DiscontinuedDate { get; set; }

  [Display(Name = "Thumbnail Photo File Name")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string ThumbnailPhotoFileName { get; set; }

  [Display(Name = "rowguid")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  public Guid rowguid { get; set; }

  [Display(Name = "Modified Date")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [Range(typeof(DateTime), "1753-01-01 00:00:00", "9999-12-31 23:59:59", ErrorMessage = "{0} must be between {1} and {2}")]
  [DisplayFormat(DataFormatString = "{0:d}")]
  public DateTime ModifiedDate { get; set; }
}
