﻿namespace AdvWorksAPI;

public class CustomerRepository : IRepository<Customer> {
  public CustomerRepository(AdvWorksLTDbContext dbContext) {
    _DbContext = dbContext;
  }

  private readonly AdvWorksLTDbContext _DbContext;

  /// <summary>
  /// Get all customers
  /// </summary>
  /// <returns>A list of Customer objects</returns>
  public List<Customer> Get() {
    // Return all items in collection
    return _DbContext.Customers.ToList();
  }

  /// <summary>
  /// Get a single customer
  /// </summary>
  /// <param name="id">The CustomerId value to locate</param>
  /// <returns>A valid Customer object, or null if not found</returns>
  public Customer Get(int id) {
    // Return a single row or null
    return _DbContext.Customers.Find(id);
  }

  /// <summary>
  /// Insert a new customer
  /// </summary>
  /// <param name="entity">The customer data to insert</param>
  /// <returns>The inserted Customer object</returns>
  public Customer Insert(Customer entity) {
    // Add new object to collection
    _DbContext.Customers.Add(entity);

    // Save changes into data store
    _DbContext.SaveChanges();

    return entity;
  }

  /// <summary>
  /// Update existing customer data
  /// </summary>
  /// <param name="entity">The customer data to update</param>
  /// <returns>The updated Customer object</returns>
  public Customer Update(Customer entity) {
    // Look up the data by the specified id
    Customer current = Get(entity.CustomerID);

    if (current != null) {
      // Update data in collection
      _DbContext.Entry(current).CurrentValues.SetValues(entity);

      // Save changes in data store
      _DbContext.SaveChanges();
    }

    return current;
  }

  /// <summary>
  /// Delete a customer
  /// </summary>
  /// <param name="id">The CustomerId value to delete</param>
  /// <returns>True if delete, false if not found</returns>
  public bool Delete(int id) {
    bool ret = false;

    Customer current = Get(id);

    if (current != null) {
      // Update data in collection
      _DbContext.Customers.Remove(current);

      // Save changes in data store
      _DbContext.SaveChanges();

      ret = true;
    }

    return ret;
  }

  /// <summary>
  /// Get a list of customers that meet the criteria passed in
  /// </summary>
  /// <param name="search">The search data to locate</param>
  /// <returns>A list of Customer objects</returns>
  public List<Customer> Search(CustomerSearch search) {
    return _DbContext.Customers.Where(c =>
          (string.IsNullOrEmpty(search.CompanyName) ? true : c.CompanyName.Contains(search.CompanyName)) &&
          (string.IsNullOrEmpty(search.LastName) ? true : c.LastName.Contains(search.LastName))).ToList();
  }
}
