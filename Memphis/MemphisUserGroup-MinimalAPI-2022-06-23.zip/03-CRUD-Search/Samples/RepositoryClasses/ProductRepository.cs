﻿namespace AdvWorksAPI;

public class ProductRepository : IRepository<Product> {
  public ProductRepository(AdvWorksLTDbContext dbContext) {
    _DbContext = dbContext;
  }

  private readonly AdvWorksLTDbContext _DbContext;

  /// <summary>
  /// Get all products
  /// </summary>
  /// <returns>A list of Product objects</returns>
  public List<Product> Get() {
    // Return all items in collection
    return _DbContext.Products.ToList();
  }

  /// <summary>
  /// Get a single product
  /// </summary>
  /// <param name="id">The ProductId value to locate</param>
  /// <returns>A valid Product object, or null if not found</returns>
  public Product Get(int id) {
    // Return a single row or null
    return _DbContext.Products.Find(id);
  }

  /// <summary>
  /// Insert a new product
  /// </summary>
  /// <param name="entity">The product data to insert</param>
  /// <returns>The inserted Product object</returns>
  public Product Insert(Product entity) {
    // Add new object to collection
    _DbContext.Products.Add(entity);

    // Save changes into data store
    _DbContext.SaveChanges();

    return entity;
  }

  /// <summary>
  /// Update existing product data
  /// </summary>
  /// <param name="entity">The product data to update</param>
  /// <returns>The updated Product object</returns>
  public Product Update(Product entity) {
    // Look up the data by the specified id
    Product current = Get(entity.ProductID);

    if (current != null) {
      // Update data in collection
      _DbContext.Entry(current).CurrentValues.SetValues(entity);

      // Save changes in data store
      _DbContext.SaveChanges();
    }

    return current;
  }

  /// <summary>
  /// Delete a product
  /// </summary>
  /// <param name="id">The ProductId value to delete</param>
  /// <returns>True if delete, false if not found</returns>
  public bool Delete(int id) {
    bool ret = false;

    // Look up the data by the specified id
    Product current = Get(id);

    if (current != null) {
      // Update data in collection
      _DbContext.Products.Remove(current);

      // Save changes in data store
      _DbContext.SaveChanges();

      ret = true;
    }

    return ret;
  }

  /// <summary>
  /// Get a list of products that have a common ProductCategoryId
  /// </summary>
  /// <param name="categoryId">The ProductCategoryId value to search for</param>
  /// <returns>A list of Product objects</returns>
  public List<Product> GetByCategoryId(int categoryId) {
    return _DbContext.Products.Where(p => p.ProductCategoryID == categoryId).ToList();
  }

  /// <summary>
  /// Get a list of products that meet the criteria passed in
  /// </summary>
  /// <param name="search">The search data to locate</param>
  /// <returns>A list of Product objects</returns>
  public List<Product> Search(ProductSearch search) {
    return _DbContext.Products.Where(p =>
          (string.IsNullOrEmpty(search.Name) ? true : p.Name.Contains(search.Name)) &&
          (p.ListPrice > search.ListPrice)).ToList();
  }
}
