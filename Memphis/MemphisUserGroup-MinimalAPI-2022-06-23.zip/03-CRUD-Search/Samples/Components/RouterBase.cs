﻿using System.Text.Json;

namespace AdvWorksAPI;

public class RouterBase
{
  #region Protected Fields
  protected string UrlFragment;
  protected ILogger Logger;
  protected string LastMessage;
  protected string EntityAsJson;
  #endregion

  #region AddRoutes Method
  public virtual void AddRoutes(WebApplication app)
  {
  }
  #endregion

  #region NotFound Method
  protected virtual IResult NotFound(string msg)
  {
    IResult ret;

    // Set the LastMessage property
    LastMessage = msg;

    // Did not find data, return '404 Not Found'
    ret = Results.NotFound(LastMessage);
    // Log an informational message
    Logger.LogInformation(LastMessage);

    return ret;
  }
  #endregion

  #region BadRequest Method
  protected virtual IResult BadRequest(string msg)
  {
    IResult ret;

    // Set the LastMessage property
    LastMessage = msg;

    // Return '400 Bad Request'
    ret = Results.BadRequest(LastMessage);
    // Log an informational message
    Logger.LogInformation(LastMessage);

    return ret;
  }
  #endregion

  #region HandleException Method
  /// <summary>
  /// Call this method to return a '500 Internal Server Error'
  /// with the exception and a custom message
  /// This method also logs the error
  /// </summary>
  protected virtual IResult HandleException(Exception ex, string msg)
  {
    IResult ret;

    // Set the LastMessage property
    LastMessage = $"{msg}{Environment.NewLine}{ex.Message}";

    // Create new exception with message        
    ret = Results.Problem(LastMessage);

    // Log the exception
    Logger.LogError(ex, LastMessage);

    return ret;
  }
  #endregion

  #region SerializeEntity<T> Method
  /// <summary>
  /// Call this method to serialize a class
  /// This can be used to log an object
  /// </summary>
  protected virtual string SerializeEntity<T>(T entity)
  {
    EntityAsJson = "Nothing serialized";

    try
    {
      // Attempt to serialize entity
      EntityAsJson = JsonSerializer.Serialize(entity);
    }
    catch
    {
      // Ignore the error
    }
    return EntityAsJson;
  }
  #endregion
}
