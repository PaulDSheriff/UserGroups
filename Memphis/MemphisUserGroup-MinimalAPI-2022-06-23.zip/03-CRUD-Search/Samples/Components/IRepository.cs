namespace AdvWorksAPI;

public interface IRepository<TEntity> {
  List<TEntity> Get();
  TEntity Get(int id);
  TEntity Insert(TEntity entity);
  TEntity Update(TEntity entity);
  bool Delete(int id);
}