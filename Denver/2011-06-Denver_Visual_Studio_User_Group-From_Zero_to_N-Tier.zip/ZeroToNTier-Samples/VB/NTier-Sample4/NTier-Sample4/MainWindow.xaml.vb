﻿Imports System.Windows

Imports NTier.EntityClasses
Imports NTier_Sample4.PersonServiceReference

''' <summary>
''' Interaction logic for MainWindow.xaml
''' </summary>
Partial Public Class MainWindow
  Inherits Window

  Public Sub New()
    InitializeComponent()
  End Sub

  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim client As PersonServicesClient = Nothing
    Dim resp As PersonResponse

    Try
      client = New PersonServicesClient()

      resp = client.GetPersons()
      If resp.Status = NTier.Common.OperationResult.Success Then
        lstData.DataContext = resp.DataCollection
      Else
        tbMessage.Text = resp.ErrorMessage
      End If
    Catch ex As Exception
      tbMessage.Text = ex.Message
    End Try
  End Sub

  Private Sub btnUpdate_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim client As PersonServicesClient = Nothing
    Dim resp As PersonResponse

    If lstData.SelectedIndex >= 0 Then
      Try
        client = New PersonServicesClient()

        resp = client.Update(DirectCast(lstData.SelectedItem, Person))
        If resp.Status = NTier.Common.OperationResult.Success Then
          MessageBox.Show("Person Updated")
        Else
          tbMessage.Text = resp.ErrorMessage
        End If
      Catch ex As Exception
        tbMessage.Text = ex.Message

      End Try
    End If
  End Sub
End Class