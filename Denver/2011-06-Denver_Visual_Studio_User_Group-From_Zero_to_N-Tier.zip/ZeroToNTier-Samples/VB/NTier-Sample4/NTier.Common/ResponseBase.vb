﻿Imports System.Runtime.Serialization

Public Enum OperationResult
  Unknown
  Success
  Exception
  Failure
  NoRecords
End Enum

<DataContract()> _
Public Class ResponseBase
  Public Sub New()
    Status = OperationResult.Unknown
    RowsAffected = 0
    FriendlyErrorMessage = String.Empty
    ErrorMessage = String.Empty
    ErrorMessageExtended = String.Empty
  End Sub

  <DataMember()> _
  Public Property Status() As OperationResult
    Get
      Return m_Status
    End Get
    Set(ByVal value As OperationResult)
      m_Status = value
    End Set
  End Property
  Private m_Status As OperationResult

  <DataMember()> _
  Public Property RowsAffected() As Integer
    Get
      Return m_RowsAffected
    End Get
    Set(ByVal value As Integer)
      m_RowsAffected = value
    End Set
  End Property
  Private m_RowsAffected As Integer

  <DataMember()> _
  Public Property FriendlyErrorMessage() As String
    Get
      Return m_FriendlyErrorMessage
    End Get
    Set(ByVal value As String)
      m_FriendlyErrorMessage = value
    End Set
  End Property
  Private m_FriendlyErrorMessage As String

  <DataMember()> _
  Public Property ErrorMessage() As String
    Get
      Return m_ErrorMessage
    End Get
    Set(ByVal value As String)
      m_ErrorMessage = value
    End Set
  End Property
  Private m_ErrorMessage As String

  <DataMember()> _
  Public Property ErrorMessageExtended() As String
    Get
      Return m_ErrorMessageExtended
    End Get
    Set(ByVal value As String)
      m_ErrorMessageExtended = value
    End Set
  End Property
  Private m_ErrorMessageExtended As String
End Class