Imports System.ServiceModel

Imports NTier.EntityClasses

<ServiceContract([Namespace]:="http://NTier.Services")> _
  Public Interface IPersonServices
  <OperationContract()> _
  Function GetPerson(ByVal entity As Person) As PersonResponse

  <OperationContract()> _
  Function GetPersons() As PersonResponse

  <OperationContract()> _
  Function Update(ByVal entity As Person) As PersonResponse
End Interface
