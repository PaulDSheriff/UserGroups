﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using NTier.EntityClasses;
using NTier_Web.PersonServiceReference;

namespace NTier_Web
{
  public partial class Default : System.Web.UI.Page
  {
    #region Page Load Event
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
        GetPersons();
    }
    #endregion

    #region GetPersons Method
    private void GetPersons()
    {
      PersonServicesClient client = null;
      PersonResponse resp;

      try
      {
        client = new PersonServicesClient();

        resp = client.GetPersons();
        if (resp.Status == NTier.Common.OperationResult.Success)
        {
          grdData.DataSource = resp.DataCollection;
          grdData.DataBind();
        }
        else
          lblExceptions.Text = resp.ErrorMessage;
      }
      catch (Exception ex)
      {
        lblExceptions.Text = ex.Message;
      }
    }
    #endregion

    #region Grid RowCommand Event
    protected void grdData_RowCommand(Object sender, GridViewCommandEventArgs e)
    {
      if (e.CommandName == "Select")
      {
        ImageButton btn;

        btn = (ImageButton)e.CommandSource;
        pnlEdit.Visible = true;
        divActionBar.Visible = true;
        grdData.Enabled = false;
        ShowData(GetPerson(Convert.ToInt32(btn.Attributes["PersonId"])));
      }
    }
    #endregion

    #region GetPerson Method
    private Person GetPerson(int personId)
    {
      PersonServicesClient client = null;
      PersonResponse resp;
      Person entity = new Person();

      try
      {
        client = new PersonServicesClient();

        entity.PersonId = personId;
        resp = client.GetPerson(entity);
        if (resp.Status == NTier.Common.OperationResult.Success)
        {
          entity = resp.DetailData;
          ShowData(entity);
        }
        else
          lblExceptions.Text = resp.ErrorMessage;
      }
      catch (Exception ex)
      {
        lblExceptions.Text = ex.Message;
      }

      return entity;
    }
    #endregion

    #region ShowData Method
    private void ShowData(Person entity)
    {
      txtPersonId.Text = entity.PersonId.ToString();
      txtFirstName.Text = entity.FirstName.Trim();
      txtLastName.Text = entity.LastName.Trim();
      txtEmailAddress.Text = entity.EmailAddress.Trim();
    }
    #endregion

    #region GetData Method
    private Person GetData()
    {
      Person entity = new Person();

      entity.PersonId = Convert.ToInt32(txtPersonId.Text);
      entity.FirstName = txtFirstName.Text.Trim();
      entity.LastName = txtLastName.Text.Trim();
      entity.EmailAddress = txtEmailAddress.Text.Trim();

      return entity;
    }
    #endregion

    #region Save Click Event
    protected void btnSave_Click(object sender, ImageClickEventArgs e)
    {
      PersonServicesClient client = null;
      PersonResponse resp;

      try
      {
        client = new PersonServicesClient();

        resp = client.Update(GetData());
        if (resp.Status == NTier.Common.OperationResult.Success)
        {
          pnlEdit.Visible = false;
          divActionBar.Visible = false;
          grdData.Enabled = true;
          // Resync Data
          GetPersons();
        }
        else
          lblExceptions.Text = resp.ErrorMessage.Replace(Environment.NewLine, "<br />");
      }
      catch (Exception ex)
      {
        lblExceptions.Text = ex.Message;
      }

    }
    #endregion

    #region Cancel Click Event
    protected void btnCancel_Click(object sender, ImageClickEventArgs e)
    {
      divActionBar.Visible = false;
      pnlEdit.Visible = false;
      grdData.Enabled = true;
    }
    #endregion
  }
}