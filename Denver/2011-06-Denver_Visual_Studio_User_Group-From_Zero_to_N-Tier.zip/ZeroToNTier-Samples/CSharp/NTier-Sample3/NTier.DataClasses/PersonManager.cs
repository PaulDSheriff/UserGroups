﻿using System;
using System.Collections.Generic;
using System.Data;
using NTier.Data.Library;
using NTier.EntityClasses;
using NTier.Common;

namespace NTier.DataClasses
{
  public class PersonManager
  {
    #region Constructors
    public PersonManager()
    {
    }

    public PersonManager(string connectString)
    {
      ConnectString = connectString;
    }
    #endregion

    #region Public Properties
    public string ConnectString { get; set; }
    public string Message { get; set; }
    #endregion

    #region GetPersons Method
    public List<Person> GetPersons()
    {
      List<Person> ret = new List<Person>();
      Person entity;
      DataTable dt;
      string sql = string.Empty;

      Message = string.Empty;

      sql = "SELECT PersonId, FirstName, LastName, EmailAddress ";
      sql += " FROM Person ";
      sql += " ORDER BY LastName ";
      try
      {
        dt = DataLayer.GetDataTable(sql, ConnectString);

        foreach (DataRow dr in dt.Rows)
        {
          entity = new Person();

          entity.PersonId = Convert.ToInt32(dr["PersonId"]);
          entity.FirstName = dr["FirstName"].ToString();
          entity.LastName = dr["LastName"].ToString();
          entity.EmailAddress = dr["EmailAddress"].ToString();

          ret.Add(entity);
        }
      }
      catch (Exception ex)
      {
        Message = ex.Message;        
      }

      return ret;
    }
    #endregion

    #region GetPerson Method
    public Person GetPerson(int personId)
    {
      Person entity = new Person();
      DataTable dt = new DataTable();
      string sql = string.Empty;
      IDbCommand cmd = null;
      DataRow dr;

      Message = string.Empty;

      sql = "SELECT PersonId, FirstName, LastName, EmailAddress ";
      sql += " FROM Person ";
      sql += " WHERE PersonId = @PersonId";
      try
      {
        cmd = DataLayer.CreateCommand(sql);
        cmd.Connection = DataLayer.CreateConnection(ConnectString);
        cmd.Parameters.Add(DataLayer.CreateParameter("@PersonId", personId));
        dt = DataLayer.GetDataTable(cmd);
        if (dt.Rows.Count > 0)
        {
          dr = dt.Rows[0];

          entity.PersonId = Convert.ToInt32(dr["PersonId"]);
          entity.FirstName = dr["FirstName"].ToString();
          entity.LastName = dr["LastName"].ToString();
          entity.EmailAddress = dr["EmailAddress"].ToString();
        }
      }
      catch (Exception ex)
      {
        Message = ex.Message;
        entity.Message = Message;
      }

      return entity;
    }
    #endregion

    #region UpdatePerson Method
    public int UpdatePerson(Person entity)
    {
      int ret = 0;
      string sql = string.Empty;
      IDbCommand cmd = null;

      Message = string.Empty;
      entity.Message = string.Empty;

      sql = "UPDATE Person ";
      sql += " SET FirstName = @FirstName, ";
      sql += "     LastName = @LastName, ";
      sql += "     EmailAddress = @EmailAddress";
      sql += " WHERE PersonId = @PersonId";
      try
      {
        // Validate the Data
        // Raises an exception if there are errors.
        Validate(entity);

        cmd = DataLayer.CreateCommand(sql);
        cmd.Connection = DataLayer.CreateConnection(ConnectString);
        cmd.Parameters.Add(DataLayer.CreateParameter("@FirstName", entity.FirstName));
        cmd.Parameters.Add(DataLayer.CreateParameter("@LastName", entity.LastName));
        cmd.Parameters.Add(DataLayer.CreateParameter("@EmailAddress", entity.EmailAddress));
        cmd.Parameters.Add(DataLayer.CreateParameter("@PersonId", entity.PersonId));

        ret = DataLayer.ExecuteSQL(cmd);
      }
      catch (ValidationException ex)
      {
        Message = ex.Message;
        entity.Message = Message;
      }
      catch (Exception ex)
      {
        Message = ex.Message;
        entity.Message = Message;
      }
      finally
      {
        if (cmd != null)
          if (cmd.Connection != null)
          {
            cmd.Connection.Close();
            cmd.Connection.Dispose();
            cmd.Dispose();
          }
      }

      return ret;
    }
    #endregion

    #region Validate Method
    private void Validate(Person entity)
    {
      string msg = string.Empty;

      if (entity.FirstName.Trim() == string.Empty)
        msg += "First Name must be filled in." + Environment.NewLine;
      if (entity.LastName.Trim() == string.Empty)
        msg += "Last Name must be filled in." + Environment.NewLine;
      if (entity.EmailAddress.Trim() == string.Empty)
        msg += "Email Address must be filled in." + Environment.NewLine;

      if (msg != string.Empty)
        throw new ValidationException(msg);
    }
    #endregion
  }
}
