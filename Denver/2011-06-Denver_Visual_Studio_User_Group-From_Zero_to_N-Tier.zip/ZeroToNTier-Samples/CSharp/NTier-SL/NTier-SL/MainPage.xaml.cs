﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using NTier_SL.PersonServiceReference;

namespace NTier_SL
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      GetPersons();
    }

    public void GetPersons()
    {
      PersonServicesClient client = new PersonServicesClient();

      client.GetPersonsCompleted += new EventHandler<GetPersonsCompletedEventArgs>(client_GetPersonsCompleted);
      client.GetPersonsAsync();
      client.CloseAsync();
    }

    void client_GetPersonsCompleted(object sender, GetPersonsCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Success)
        lstData.DataContext = e.Result.DataCollection;
      else
        tbMessage.Text = e.Result.ErrorMessageExtended;
    }

    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      PersonServicesClient client = new PersonServicesClient();
      Person entity;

      entity = (Person)lstData.SelectedItem;
      client.UpdateCompleted += new EventHandler<UpdateCompletedEventArgs>(client_UpdateCompleted);
      client.UpdateAsync(entity);
      client.CloseAsync();
    }

    void client_UpdateCompleted(object sender, UpdateCompletedEventArgs e)
    {
      if (e.Result.Status == OperationResult.Success)
        MessageBox.Show("Person Updated");
      else
        tbMessage.Text = e.Result.ErrorMessageExtended;
    }
  }
}
