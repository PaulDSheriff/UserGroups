﻿using System;
using System.Windows;

namespace NTier_Sample2
{
  public partial class MainWindow : Window
  {
    PersonManager _Manager = new PersonManager();

    public MainWindow()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = _Manager.GetPersons();
      if (_Manager.Message != string.Empty)
        tbMessage.Text = _Manager.Message;
    }

    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      if (lstData.SelectedIndex >= 0)
      {
        _Manager.UpdatePerson(((Person)lstData.SelectedItem));
        if (_Manager.Message != string.Empty)
          tbMessage.Text = _Manager.Message;
      }
    }
  }
}
