﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace NTier_Sample2
{
  public class PersonManager
  {
    #region Public Properties
    public string Message { get; set; }
    #endregion

    #region GetPersons Method
    public List<Person> GetPersons()
    {
      List<Person> ret = new List<Person>();
      Person entity;
      DataTable dt = new DataTable();
      string sql = string.Empty;
      SqlDataAdapter da = null;

      Message = string.Empty;

      sql = "SELECT PersonId, FirstName, LastName, EmailAddress ";
      sql += " FROM Person ";
      sql += " ORDER BY LastName ";

      try
      {
        da = new SqlDataAdapter(sql, AppConfig.ConnectString);
        da.Fill(dt);

        foreach (DataRow dr in dt.Rows)
        {
          entity = new Person();

          entity.PersonId = Convert.ToInt32(dr["PersonId"]);
          entity.FirstName = dr["FirstName"].ToString();
          entity.LastName = dr["LastName"].ToString();
          entity.EmailAddress = dr["EmailAddress"].ToString();

          ret.Add(entity);
        }
      }
      catch (Exception ex)
      {
        Message = ex.Message;
      }

      return ret;
    }
    #endregion

    #region GetPerson Method
    public Person GetPerson(int personId)
    {
      Person entity = new Person();
      DataTable dt = new DataTable();
      string sql = string.Empty;
      SqlDataAdapter da = null;
      SqlCommand cmd = null;
      SqlParameter parm = null;
      DataRow dr;

      Message = string.Empty;

      sql = "SELECT PersonId, FirstName, LastName, EmailAddress ";
      sql += " FROM Person ";
      sql += " WHERE PersonId = @PersonId";
      try
      {
        cmd = new SqlCommand(sql, new SqlConnection(AppConfig.ConnectString));
        parm = new SqlParameter("@PersonId", personId);
        cmd.Parameters.Add(parm);

        da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        dr = dt.Rows[0];

        entity.PersonId = Convert.ToInt32(dr["PersonId"]);
        entity.FirstName = dr["FirstName"].ToString();
        entity.LastName = dr["LastName"].ToString();
        entity.EmailAddress = dr["EmailAddress"].ToString();
      }
      catch (Exception ex)
      {
        Message = ex.Message;
        entity.Message = Message;
      }

      return entity;
    }
    #endregion

    #region UpdatePerson Method
    public int UpdatePerson(Person entity)
    {
      int ret = 0;
      string sql = string.Empty;
      SqlCommand cmd = null;
      SqlParameter parm = null;

      Message = string.Empty;
      entity.Message = string.Empty;

      sql = "UPDATE Person ";
      sql += " SET FirstName = @FirstName, ";
      sql += "     LastName = @LastName, ";
      sql += "     EmailAddress = @EmailAddress";
      sql += " WHERE PersonId = @PersonId";
      try
      {
        // Validate the Data
        // Raises an exception if there are errors.
        Validate(entity);

        cmd = new SqlCommand(sql, new SqlConnection(AppConfig.ConnectString));
        parm = new SqlParameter("@FirstName", entity.FirstName);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@LastName", entity.LastName);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@EmailAddress", entity.EmailAddress);
        cmd.Parameters.Add(parm);
        parm = new SqlParameter("@PersonId", entity.PersonId);
        cmd.Parameters.Add(parm);
        cmd.Connection.Open();
        ret = cmd.ExecuteNonQuery();
      }
      catch (ApplicationException ex)
      {
        Message = ex.Message;
        entity.Message = Message;
      }
      catch (Exception ex)
      {
        Message = ex.Message;
        entity.Message = Message;
      }
      finally
      {
        if (cmd != null)
          if (cmd.Connection != null)
          {
            cmd.Connection.Close();
            cmd.Connection.Dispose();
            cmd.Dispose();
          }
      }

      return ret;
    }
    #endregion

    #region Validate Method
    private void Validate(Person entity)
    {
      string msg = string.Empty;

      if (entity.FirstName.Trim() == string.Empty)
        msg += "First Name must be filled in." + Environment.NewLine;
      if (entity.LastName.Trim() == string.Empty)
        msg += "Last Name must be filled in." + Environment.NewLine;
      if (entity.EmailAddress.Trim() == string.Empty)
        msg += "Email Address must be filled in." + Environment.NewLine;

      if (msg != string.Empty)
        throw new ApplicationException(msg);
    }
    #endregion
  }
}
