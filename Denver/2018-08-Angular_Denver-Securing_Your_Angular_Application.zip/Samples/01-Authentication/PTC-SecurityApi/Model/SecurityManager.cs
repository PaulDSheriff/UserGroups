using System;
using System.Collections.Generic;
using System.Linq;
using PtcApi.Model;

namespace PtcApi.Security
{
  public class SecurityManager
  {
    public AppUserAuth AuthenticateUser(AppUser user)
    {
      AppUserAuth ret = new AppUserAuth();
      AppUser authUser = null;

      using (var db = new PtcDbContext())
      {
        // Attempt to validate user
        authUser = db.Users.Where(
          u => u.UserName.ToLower()
               == user.UserName.ToLower()
            && u.Password
               == user.Password).FirstOrDefault();
      }

      if (authUser != null)
      {
        ret.UserName = authUser.UserName;
        ret.IsAuthenticated = true;
      }

      return ret;
    }
  }
}
