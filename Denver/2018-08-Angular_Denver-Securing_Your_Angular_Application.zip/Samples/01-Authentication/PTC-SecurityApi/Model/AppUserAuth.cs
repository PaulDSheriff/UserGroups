namespace PtcApi.Model
{
  public class AppUserAuth
  {
    public AppUserAuth()
    {
      UserName = "Not authorized";
    }

    public string UserName { get; set; }
    public bool IsAuthenticated { get; set; }
  }
}
