export class AppUserAuth {
  userName: string = "";
  isAuthenticated: boolean = false;
}